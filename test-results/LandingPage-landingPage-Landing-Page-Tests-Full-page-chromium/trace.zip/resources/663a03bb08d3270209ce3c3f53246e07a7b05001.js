(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_1994db._.js", {

"[project]/src/components/HeaderOnboarding/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledHeaderContainer": ()=>StyledHeaderContainer,
    "StyledHeaderNavigation": ()=>StyledHeaderNavigation,
    "StyledHeaderOnboarding": ()=>StyledHeaderOnboarding
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
const StyledHeaderOnboarding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        position: "relative",
        width: "100%",
        padding: "32px 0"
    }));
const StyledHeaderContainer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"])(()=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "10px"
    }));
const StyledHeaderNavigation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        alignItems: "center",
        gap: "10px"
    }));

})()),
"[project]/src/hooks/useResponsive.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>useResponsive
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/material/useMediaQuery/index.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
var _s = __turbopack_refresh__.signature();
"use client";
;
;
function useResponsive(query, start, end) {
    _s();
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    const mediaUp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(theme.breakpoints.up(start));
    const mediaDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(theme.breakpoints.down(start));
    const mediaBetween = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(theme.breakpoints.between(start, end));
    const mediaOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(theme.breakpoints.only(start));
    if (query === "up") {
        return mediaUp;
    }
    if (query === "down") {
        return mediaDown;
    }
    if (query === "between") {
        return mediaBetween;
    }
    return mediaOnly;
}
_s(useResponsive, "w4ujtqeuseK1DL72nj1S+uYue3o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});

})()),
"[project]/src/components/HeaderOnboarding/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "HeaderOnboarding": ()=>HeaderOnboarding
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/HeaderOnboarding/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/nostr.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LanguageTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/LanguageTwoTone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowBackTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/ArrowBackTwoTone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PersonTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/PersonTwoTone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LoginTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/LoginTwoTone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useResponsive$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/useResponsive.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
const HeaderOnboarding = ()=>{
    _s();
    const { isAuth } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthContext"]);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isDesktop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useResponsive$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("up", "sm");
    const isBack = pathname !== "/";
    const handleLogin = ()=>{
        document.dispatchEvent(new Event("nlLaunch"));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledHeaderOnboarding"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledHeaderContainer"], {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    children: isBack && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        LinkComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                        href: "/",
                        color: "primary",
                        variant: "text",
                        startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowBackTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                            lineNumber: 39,
                            columnNumber: 26
                        }, void 0),
                        children: "Back"
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                        lineNumber: 34,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledHeaderNavigation"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            LinkComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                            href: "/sites",
                            color: "primary",
                            variant: "text",
                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LanguageTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                                lineNumber: 51,
                                columnNumber: 24
                            }, void 0),
                            children: "Discover"
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        isAuth ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            LinkComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                            href: "/admin",
                            color: "decorate",
                            variant: "contained",
                            startIcon: isDesktop ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PersonTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                                lineNumber: 61,
                                columnNumber: 38
                            }, void 0) : undefined,
                            children: "My sites"
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                            lineNumber: 56,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                            onClick: handleLogin,
                            color: "primary",
                            variant: "text",
                            startIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LoginTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                                lineNumber: 70,
                                columnNumber: 26
                            }, void 0),
                            children: "Login"
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                            lineNumber: 66,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/HeaderOnboarding/index.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
};
_s(HeaderOnboarding, "P2yAFJZ0vtUD4x8YpK6sWnN1oew=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useResponsive$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = HeaderOnboarding;
var _c;
__turbopack_refresh__.register(_c, "HeaderOnboarding");

})()),
"[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {
"use strict";

__turbopack_esm__({
    "InterDisplay": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/src/components/HeadIntroOnboarding/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledContainerIntro": ()=>StyledContainerIntro,
    "StyledLogo": ()=>StyledLogo,
    "StyledTypographySubtitle": ()=>StyledTypographySubtitle,
    "StyledTypographyTitle": ()=>StyledTypographyTitle
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
const StyledContainerIntro = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"])(({ theme })=>({
        position: "relative",
        width: "100%",
        marginTop: "120px",
        marginBottom: "120px",
        display: "flex",
        flexDirection: "column",
        gap: "32px",
        alignItems: "center",
        textAlign: "center",
        [theme.breakpoints.down("sm")]: {
            marginTop: "70px",
            marginBottom: "70px",
            gap: "22px"
        }
    }));
const StyledLogo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        width: "80px",
        [theme.breakpoints.down("sm")]: {
            width: "64px"
        }
    }));
const StyledTypographyTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: "56px",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        maxWidth: "860px",
        margin: "auto",
        lineHeight: "124%",
        fontWeight: "700",
        [theme.breakpoints.down("sm")]: {
            fontSize: "32px"
        }
    }));
const StyledTypographySubtitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: "21px",
        fontWeight: 400,
        lineHeight: "34px",
        color: "#696F7D",
        [theme.breakpoints.down("sm")]: {
            fontSize: "16px"
        }
    }));

})()),
"[project]/src/components/Logo/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Logo": ()=>Logo
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const Logo = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "100%",
        height: "100%",
        viewBox: "0 0 80 80",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M79.9998 33.2205C79.5517 32.695 79.0439 32.2414 78.4765 31.8595C77.3239 31.0761 75.9887 30.6844 74.4709 30.6844C73.6949 30.6844 72.993 30.7851 72.3653 30.9866C71.7491 31.1768 71.2013 31.4734 70.722 31.8763C70.2427 32.268 69.8091 32.7772 69.421 33.4039H69.4039V23.8016H62.5567V48.8145H69.3355V46.0614H69.3526C69.6265 46.7553 70.0031 47.3373 70.4824 47.8073C70.9731 48.2774 71.5494 48.6299 72.2113 48.8649C72.8732 49.0999 73.6036 49.2174 74.4024 49.2174C75.9887 49.2174 77.3638 48.8369 78.5279 48.0759C79.077 47.7116 79.5678 47.2788 80.0001 46.7774C76.7173 65.641 59.966 80 39.7948 80C20.3563 80 4.09367 66.6651 0 48.8146H4.14996V39.4138C4.14996 38.7311 4.24696 38.1659 4.44097 37.7183C4.63497 37.2594 4.92027 36.9181 5.29687 36.6942C5.67347 36.4704 6.12995 36.3585 6.66631 36.3585C7.47657 36.3585 8.09853 36.5991 8.53218 37.0803C8.96584 37.5616 9.18267 38.2498 9.18267 39.1452V48.8146H16.0299V37.6343C16.0299 36.213 15.8017 34.9819 15.3452 33.9411C14.8887 32.9003 14.2097 32.1001 13.3081 31.5406C12.4066 30.9698 11.2825 30.6844 9.93587 30.6844C8.10994 30.6844 6.66631 31.1824 5.60499 32.1785C5.01346 32.7274 4.49992 33.3632 4.06437 34.086V31.0873H0.0226317C4.15329 13.286 20.3919 0 39.7948 0C59.9652 0 76.7161 14.358 79.9998 33.2205ZM73.9573 43.4594C73.5237 43.784 72.993 43.9463 72.3653 43.9463C71.7491 43.9463 71.1956 43.784 70.7049 43.4594C70.2256 43.1237 69.849 42.6536 69.5751 42.0493C69.3012 41.445 69.1643 40.7343 69.1643 39.9173C69.1643 39.1004 69.3012 38.3953 69.5751 37.8022C69.849 37.209 70.2256 36.7502 70.7049 36.4256C71.1956 36.0899 71.7491 35.922 72.3653 35.922C72.993 35.922 73.5237 36.0899 73.9573 36.4256C74.391 36.7502 74.7219 37.209 74.9502 37.8022C75.1784 38.3953 75.2925 39.1004 75.2925 39.9173C75.2925 40.7343 75.1784 41.445 74.9502 42.0493C74.7219 42.6536 74.391 43.1237 73.9573 43.4594ZM19.0187 46.1958L19.0187 63.8016H20.6244L25.2273 60.5251V59.0564L23.5146 58.1525V57.2486L25.2273 56.3448V55.7234L23.5146 54.8195L25.2273 53.9156L23.5146 53.0118V51.656L25.8696 50.4132V46.1958H25.9341C26.208 46.8449 26.5789 47.3933 27.0467 47.8409C27.5146 48.2886 28.0681 48.6299 28.7072 48.8649C29.3463 49.1 30.0652 49.2175 30.8641 49.2175C32.4503 49.2175 33.8255 48.837 34.9895 48.0759C36.1536 47.3037 37.0551 46.2238 37.6942 44.836C38.3447 43.4371 38.6699 41.7975 38.6699 39.9174C38.6699 38.1044 38.339 36.504 37.6771 35.1162C37.0152 33.7285 36.1022 32.6429 34.9382 31.8595C33.7856 31.0761 32.4503 30.6844 30.9325 30.6844C30.1565 30.6844 29.449 30.7851 28.8099 30.9866C28.1822 31.1768 27.6231 31.4678 27.1323 31.8595C26.653 32.24 26.2365 32.7213 25.8827 33.3032H25.7971V31.0873H19.0184V46.1958H19.0187ZM46.9794 49.2175C45.6442 49.2175 44.5201 48.9377 43.6071 48.3781C42.7056 47.8074 42.0266 47.0016 41.5701 45.9608C41.1136 44.92 40.8854 43.6889 40.8854 42.2676V31.0873H47.7326V40.7567C47.7326 41.6409 47.9494 42.3291 48.3831 42.8216C48.8282 43.3028 49.4501 43.5434 50.249 43.5434C50.7853 43.5434 51.2418 43.4315 51.6184 43.2077C51.995 42.9838 52.2803 42.6481 52.4743 42.2004C52.6683 41.7416 52.7653 41.1708 52.7653 40.4881V31.0873H59.6125V48.8146H52.8509V45.8192C52.4154 46.5447 51.9018 47.1851 51.3103 47.7402C50.2604 48.7251 48.8167 49.2175 46.9794 49.2175ZM30.419 43.4595C29.9853 43.784 29.4547 43.9463 28.827 43.9463C28.2108 43.9463 27.6573 43.784 27.1666 43.4595C26.6873 43.1237 26.3107 42.6537 26.0368 42.0493C25.7629 41.445 25.6259 40.7343 25.6259 39.9174C25.6259 39.1004 25.7629 38.3953 26.0368 37.8022C26.3107 37.209 26.6873 36.7502 27.1666 36.4256C27.6573 36.0899 28.2108 35.922 28.827 35.922C29.4547 35.922 29.9853 36.0899 30.419 36.4256C30.8527 36.7502 31.1836 37.209 31.4119 37.8022C31.6401 38.3953 31.7542 39.1004 31.7542 39.9174C31.7542 40.7343 31.6401 41.445 31.4119 42.0493C31.1836 42.6537 30.8527 43.1237 30.419 43.4595Z",
            fill: "#FF3ED9"
        }, void 0, false, {
            fileName: "[project]/src/components/Logo/index.tsx",
            lineNumber: 9,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Logo/index.tsx",
        lineNumber: 2,
        columnNumber: 3
    }, this);
_c = Logo;
var _c;
__turbopack_refresh__.register(_c, "Logo");

})()),
"[project]/src/components/HeadIntroOnboarding/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "HeadIntroOnboarding": ()=>HeadIntroOnboarding
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/HeadIntroOnboarding/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Logo$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Logo/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
const HeadIntroOnboarding = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledContainerIntro"], {
        maxWidth: "lg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledLogo"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Logo$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                    fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTypographyTitle"], {
                variant: "h1",
                children: "Beautiful nostr-based websites for creators"
            }, void 0, false, {
                fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTypographySubtitle"], {
                variant: "subtitle1",
                children: [
                    "Best way to share your work outside of nostr.",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                size: "large",
                variant: "contained",
                color: "decorate",
                LinkComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                href: "/onboarding",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                    children: "Try now →"
                }, void 0, false, {
                    fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/HeadIntroOnboarding/index.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
};
_c = HeadIntroOnboarding;
var _c;
__turbopack_refresh__.register(_c, "HeadIntroOnboarding");

})()),
"[project]/src/components/ThemesOnboarding/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledButton": ()=>StyledButton,
    "StyledButtonGroup": ()=>StyledButtonGroup,
    "StyledMoreButton": ()=>StyledMoreButton,
    "StyledPreviews": ()=>StyledPreviews,
    "StyledTitle": ()=>StyledTitle,
    "StyledWrap": ()=>StyledWrap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
const StyledButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"])(()=>({
        borderRadius: "1000px",
        textTransform: "none",
        color: "#000"
    }));
const StyledButtonGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        display: "flex",
        width: "100%",
        justifyContent: "center",
        gap: 16,
        marginBottom: 64,
        flexWrap: "wrap",
        zIndex: 2,
        position: "relative",
        [theme.breakpoints.down("sm")]: {
            gap: 10,
            marginBottom: 32
        }
    }));
const StyledPreviews = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        paddingBottom: 48,
        zIndex: 2,
        position: "relative",
        [theme.breakpoints.down("sm")]: {
            paddingBottom: 32
        }
    }));
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        padding: 120,
        [theme.breakpoints.down("sm")]: {
            padding: 40
        }
    }));
const StyledMoreButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        textAlign: "center"
    }));
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 48,
        color: theme.palette.primary.main,
        textAlign: "center",
        fontWeight: "bold",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        marginBottom: 64,
        [theme.breakpoints.down("md")]: {
            fontSize: 32,
            marginBottom: 24
        }
    }));

})()),
"[project]/src/components/ThemePreview/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledButtonPreview": ()=>StyledButtonPreview,
    "StyledWrapPreview": ()=>StyledWrapPreview
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
const StyledWrapPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        height: "280px",
        position: "relative",
        borderRadius: "16px",
        overflow: "hidden",
        boxShadow: "0px 28px 40.1px 0px #00000026",
        img: {
            height: "inherit",
            width: "inherit",
            objectFit: "cover",
            objectPosition: "left top",
            position: "absolute",
            left: 0,
            top: 0
        },
        "&:hover::after": {
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.4)",
            zIndex: 1
        },
        button: {
            display: "none"
        },
        "&:hover": {
            button: {
                display: "block"
            }
        }
    }));
const StyledButtonPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"])(()=>({
        position: "relative",
        zIndex: 2,
        maxWidth: "174px",
        width: "100%"
    }));

})()),
"[project]/src/components/ThemePreview/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "ThemePreview": ()=>ThemePreview
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemePreview$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ThemePreview/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
const ThemePreview = ({ preview, alt = '', handleNavigate })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemePreview$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapPreview"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemePreview$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButtonPreview"], {
                onClick: handleNavigate,
                color: "decorate",
                variant: "contained",
                size: "large",
                children: "Preview"
            }, void 0, false, {
                fileName: "[project]/src/components/ThemePreview/index.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: preview,
                alt: alt,
                width: 500,
                height: 500
            }, void 0, false, {
                fileName: "[project]/src/components/ThemePreview/index.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ThemePreview/index.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
};
_c = ThemePreview;
var _c;
__turbopack_refresh__.register(_c, "ThemePreview");

})()),
"[project]/src/components/ModalAuthor/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledAuthor": ()=>StyledAuthor,
    "StyledDialog": ()=>StyledDialog,
    "StyledDialogContent": ()=>StyledDialogContent,
    "StyledTitle": ()=>StyledTitle
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Dialog/Dialog.js [app-client] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/DialogContent/DialogContent.js [app-client] (ecmascript) <export default as DialogContent>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        fontWeight: "bold"
    }));
const StyledAuthor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        alignItems: "center",
        gap: 10,
        marginBottom: 16
    }));
const StyledDialog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"])(()=>({
        "& .MuiPaper-root": {
            overflow: "visible"
        }
    }));
const StyledDialogContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"])(({ theme })=>({
        width: "400px",
        [theme.breakpoints.down("sm")]: {
            width: "300px"
        }
    }));

})()),
"[project]/src/components/PreviewSite/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "CARD_MEDIA_HEIGHT": ()=>CARD_MEDIA_HEIGHT,
    "StyledAvatarGroup": ()=>StyledAvatarGroup,
    "StyledCard": ()=>StyledCard,
    "StyledCardActionArea": ()=>StyledCardActionArea,
    "StyledCardAuthorName": ()=>StyledCardAuthorName,
    "StyledCardAuthorStatus": ()=>StyledCardAuthorStatus,
    "StyledCardContent": ()=>StyledCardContent,
    "StyledCardDescription": ()=>StyledCardDescription,
    "StyledCardHeader": ()=>StyledCardHeader,
    "StyledCardHeaderWrap": ()=>StyledCardHeaderWrap,
    "StyledCardMedia": ()=>StyledCardMedia,
    "StyledCardNoImage": ()=>StyledCardNoImage,
    "StyledCardSubHeader": ()=>StyledCardSubHeader,
    "StyledCardTitle": ()=>StyledCardTitle,
    "StyledCardWrapAuthors": ()=>StyledCardWrapAuthors,
    "StyledWrapFooter": ()=>StyledWrapFooter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardActionArea$2f$CardActionArea$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardActionArea$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/CardActionArea/CardActionArea.js [app-client] (ecmascript) <export default as CardActionArea>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardHeader$2f$CardHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardHeader$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/CardHeader/CardHeader.js [app-client] (ecmascript) <export default as CardHeader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardMedia$2f$CardMedia$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardMedia$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/CardMedia/CardMedia.js [app-client] (ecmascript) <export default as CardMedia>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/AvatarGroup/AvatarGroup.js [app-client] (ecmascript) <export default as AvatarGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$colors$2f$grey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__grey$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/colors/grey.js [app-client] (ecmascript) <export default as grey>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
const CARD_PADDING = 16;
const CARD_MEDIA_HEIGHT = 160;
const AUTHORS_CONTENT_SPACING = CARD_PADDING;
const StyledCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function StyledCardName(props, ref) {
    const exclude = new Set([
        "isLink"
    ]);
    const omitProps = Object.fromEntries(Object.entries(props).filter((e)=>!exclude.has(e[0])));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
        ref: ref,
        ...omitProps
    }, void 0, false, {
        fileName: "[project]/src/components/PreviewSite/styled.tsx",
        lineNumber: 41,
        columnNumber: 12
    }, this);
}))(({ isLink = false, theme })=>({
        width: "100%",
        height: "100%",
        display: isLink ? "block" : "flex",
        flexDirection: "column",
        boxShadow: theme.shadows[0],
        padding: isLink ? 0 : CARD_PADDING,
        "&:hover": {
            boxShadow: isLink ? theme.shadows[10] : "none"
        }
    }));
const StyledCardActionArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardActionArea$2f$CardActionArea$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardActionArea$3e$__["CardActionArea"])(()=>({
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "baseline",
        padding: CARD_PADDING,
        "&:hover": {
            ".MuiCardActionArea-focusHighlight": {
                opacity: 0
            }
        }
    }));
const StyledCardNoImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        flex: `0 0 ${CARD_MEDIA_HEIGHT}px`,
        background: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$colors$2f$grey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__grey$3e$__["grey"][300],
        display: "flex",
        height: CARD_MEDIA_HEIGHT,
        width: "100%",
        borderTopLeftRadius: theme.shape.borderRadius,
        borderTopRightRadius: theme.shape.borderRadius,
        fontSize: 60,
        color: "#fff"
    }));
const StyledCardMedia = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function StyledCardMediaName(props, ref) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardMedia$2f$CardMedia$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardMedia$3e$__["CardMedia"], {
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/PreviewSite/styled.tsx",
        lineNumber: 84,
        columnNumber: 14
    }, this);
}))(({ theme })=>({
        flex: `0 0 ${CARD_MEDIA_HEIGHT}px`,
        height: CARD_MEDIA_HEIGHT,
        borderTopLeftRadius: theme.shape.borderRadius,
        borderTopRightRadius: theme.shape.borderRadius
    }));
const StyledWrapFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        display: "flex",
        flexDirection: "column",
        height: "100%",
        width: "100%",
        borderBottomLeftRadius: theme.shape.borderRadius,
        borderBottomRightRadius: theme.shape.borderRadius
    }));
const StyledCardHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardHeader$2f$CardHeader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardHeader$3e$__["CardHeader"])(()=>({
        width: "100%",
        span: {
            width: "inherit"
        },
        padding: 0,
        ".MuiCardHeader-avatar": {
            marginRight: AUTHORS_CONTENT_SPACING
        },
        ".MuiCardHeader-content": {
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            height: "100%",
            width: "100%",
            gap: 4
        }
    }));
const StyledCardHeaderWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        justifyContent: "space-between",
        paddingBottom: CARD_PADDING,
        width: "100%",
        alignItems: "center"
    }));
const StyledCardTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        width: "100%",
        overflow: "hidden",
        textOverflow: "ellipsis",
        display: "-webkit-box",
        WebkitLineClamp: 1,
        WebkitBoxOrient: "vertical",
        wordWrap: "break-word",
        fontWeight: "700",
        fontSize: 16,
        lineHeight: "18px",
        height: "18px",
        color: theme.palette.primary.main
    }));
const StyledCardSubHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        width: "100%",
        overflow: "hidden",
        textOverflow: "ellipsis",
        display: "-webkit-box",
        WebkitLineClamp: 1,
        WebkitBoxOrient: "vertical",
        wordWrap: "break-word",
        fontSize: 12,
        lineHeight: "19px",
        height: "18px"
    }));
const StyledCardDescription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        width: "100%",
        overflow: "hidden",
        textOverflow: "ellipsis",
        display: "-webkit-box",
        WebkitLineClamp: "2",
        WebkitBoxOrient: "vertical",
        wordWrap: "break-word",
        fontSize: 12,
        lineHeight: "19px"
    }));
const StyledCardContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"])(()=>({
        paddingBottom: 0
    }));
const StyledCardWrapAuthors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        alignItems: "center",
        gap: AUTHORS_CONTENT_SPACING,
        marginTop: "auto",
        padding: CARD_PADDING
    }));
const StyledCardAuthorName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        width: "100%",
        overflow: "hidden",
        textOverflow: "ellipsis",
        display: "-webkit-box",
        WebkitLineClamp: 1,
        WebkitBoxOrient: "vertical",
        wordWrap: "break-word",
        fontweight: "700",
        fontSize: "14px",
        lineHeight: "18px",
        fontWeight: "700"
    }));
const StyledCardAuthorStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        fontSize: "14px",
        lineHeight: "22px",
        fontWeight: "400",
        paddingTop: "3px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
    }));
const StyledAvatarGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$AvatarGroup$2f$AvatarGroup$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AvatarGroup$3e$__["AvatarGroup"])(()=>({
        "& .MuiAvatar-root": {
            width: 22,
            height: 22,
            fontSize: "10px"
        },
        "& .MuiAvatarGroup-avatar": {
            width: 22,
            height: 22,
            fontSize: "10px"
        }
    }));

})()),
"[project]/src/components/PreviewNavigation/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledButtonHashtagKind": ()=>StyledButtonHashtagKind,
    "StyledIconButton": ()=>StyledIconButton,
    "StyledWrapper": ()=>StyledWrapper
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/IconButton/IconButton.js [app-client] (ecmascript) <export default as IconButton>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
const StyledWrapper = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "12px 32px",
        position: "fixed",
        flexWrap: "wrap",
        bottom: 0,
        gap: 16,
        left: 0,
        width: "100%",
        zIndex: 100,
        background: "#fff",
        boxShadow: "0px -1px 16px 0px rgba(0, 0, 0, 0.1)",
        [theme.breakpoints.down("md")]: {
            gap: 10
        },
        [theme.breakpoints.down("sm")]: {
            padding: "12px 16px"
        }
    }));
const StyledIconButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__IconButton$3e$__["IconButton"])(()=>({
        border: "1px solid rgba(233, 233, 233, 1)"
    }));
const StyledButtonHashtagKind = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"])(()=>({
        span: {
            overflow: "hidden",
            textOverflow: "ellipsis",
            textWrap: "nowrap"
        }
    }));

})()),
"[project]/src/components/shared/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "PageTitle": ()=>PageTitle,
    "StyledAvatarSite": ()=>StyledAvatarSite,
    "StyledCard": ()=>StyledCard,
    "StyledCardTitleFeature": ()=>StyledCardTitleFeature,
    "StyledTitlePage": ()=>StyledTitlePage,
    "StyledWrap": ()=>StyledWrap,
    "StyledWrapOnboardingChildren": ()=>StyledWrapOnboardingChildren
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Avatar/Avatar.js [app-client] (ecmascript) <export default as Avatar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$colors$2f$grey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__grey$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/colors/grey.js [app-client] (ecmascript) <export default as grey>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
const POST_CARD_PADDING = 16;
const StyledAvatarSite = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Avatar$2f$Avatar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Avatar$3e$__["Avatar"])(({ theme })=>({
        borderRadius: theme.shape.borderRadius,
        fontSize: 24,
        background: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$colors$2f$grey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__grey$3e$__["grey"][400]
    }));
const PageTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function TypographyName(props, ref) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
        variant: "h1",
        component: "div",
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/shared/styled.tsx",
        lineNumber: 18,
        columnNumber: 14
    }, this);
}))(({ theme })=>({
        fontWeight: "700",
        fontSize: 24,
        lineHeight: "31px",
        [theme.breakpoints.up("sm")]: {
            fontSize: 30,
            lineHeight: "39px"
        }
    }));
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        maxWidth: 720,
        margin: "0 auto",
        paddingBottom: "24px"
    }));
const StyledCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"])(({ theme })=>({
        width: "100%",
        display: "flex",
        flexDirection: "column",
        boxShadow: theme.shadows[0],
        gap: POST_CARD_PADDING,
        padding: POST_CARD_PADDING
    }));
const StyledCardTitleFeature = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        width: "100%",
        fontWeight: "700",
        fontSize: 20,
        lineHeight: "26px",
        color: theme.palette.primary.main
    }));
const StyledTitlePage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(PageTitle)(({ theme })=>({
        display: "flex",
        alignItems: "center",
        paddingBottom: 24,
        gap: 8,
        paddingTop: 40,
        width: "100%",
        [theme.breakpoints.down("sm")]: {
            paddingTop: 16
        }
    }));
const StyledWrapOnboardingChildren = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        flexDirection: "column",
        gap: "16px",
        maxWidth: 348,
        margin: "0 auto",
        alignItems: "center"
    }));

})()),
"[project]/src/components/ModalSites/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "ModalSites": ()=>ModalSites
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Card/Card.js [app-client] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardMedia$2f$CardMedia$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardMedia$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/CardMedia/CardMedia.js [app-client] (ecmascript) <export default as CardMedia>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/DialogTitle/DialogTitle.js [app-client] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Fab$2f$Fab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Fab$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Fab/Fab.js [app-client] (ecmascript) <export default as Fab>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModalAuthor$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ModalAuthor/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PreviewSite$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/PreviewSite/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$InsertPhotoTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/InsertPhotoTwoTone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PreviewNavigation$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/PreviewNavigation/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowBack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/ArrowBack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/icons-material/esm/ArrowForward.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/shared/styled.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
const ModalSites = ({ isOpen, themeId, handleClose, tag, sites })=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [activeSite, setActiveSite] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const getSite = sites ? sites[activeSite] : null;
    const onNextSite = ()=>{
        if (sites.length === activeSite + 1) {
            setActiveSite(0);
            return;
        }
        setActiveSite((prev)=>prev + 1);
    };
    const onPrevSite = ()=>{
        if (0 === activeSite) {
            setActiveSite(sites.length - 1);
            return;
        }
        setActiveSite((prev)=>prev - 1);
    };
    const handleNavigatePreview = ()=>{
        router.push(`/preview?themeId=${themeId}${tag ? `&tag=${tag}` : ""}`);
    };
    const handleNavigateEdit = ()=>{
        router.push(`/preview?themeId=${themeId}&siteId=${getSite?.id}`);
    };
    if (!getSite) {
        return null;
    }
    // console.log("getSite", getSite);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModalAuthor$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledDialog"], {
        open: isOpen,
        onClose: handleClose,
        "aria-labelledby": "alert-dialog-title",
        "aria-describedby": "alert-dialog-description",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                component: "div",
                id: "alert-dialog-title",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModalAuthor$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                    variant: "body1",
                    children: [
                        "You already have ",
                        sites.length,
                        " site",
                        sites.length > 1 ? "s" : "",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Fab$2f$Fab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Fab$3e$__["Fab"], {
                            onClick: handleClose,
                            size: "small",
                            color: "primary",
                            "aria-label": "close",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/components/ModalSites/index.tsx",
                                lineNumber: 86,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModalSites/index.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ModalSites/index.tsx",
                    lineNumber: 78,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ModalSites/index.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModalAuthor$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledDialogContent"], {
                sx: {
                    p: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                    elevation: 0,
                    sx: {
                        borderTop: "1px solid #ececec",
                        borderRadius: 0,
                        padding: "16px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PreviewSite$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledCardHeader"], {
                            avatar: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledAvatarSite"], {
                                variant: "square",
                                src: getSite?.logo,
                                children: getSite?.name
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModalSites/index.tsx",
                                lineNumber: 101,
                                columnNumber: 15
                            }, void 0),
                            title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: getSite?.title || getSite?.name
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModalSites/index.tsx",
                                lineNumber: 105,
                                columnNumber: 20
                            }, void 0),
                            subheader: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                children: getSite?.url
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModalSites/index.tsx",
                                lineNumber: 106,
                                columnNumber: 24
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModalSites/index.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this),
                        Boolean(getSite?.image) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$CardMedia$2f$CardMedia$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CardMedia$3e$__["CardMedia"], {
                            component: "img",
                            height: "250",
                            image: getSite?.image,
                            alt: getSite?.name,
                            sx: {
                                marginTop: "16px",
                                borderRadius: "8px"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModalSites/index.tsx",
                            lineNumber: 109,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PreviewSite$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledCardNoImage"], {
                            sx: {
                                marginTop: "16px"
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$InsertPhotoTwoTone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                sx: {
                                    margin: "auto"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModalSites/index.tsx",
                                lineNumber: 118,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModalSites/index.tsx",
                            lineNumber: 117,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ModalSites/index.tsx",
                    lineNumber: 91,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ModalSites/index.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    padding: 2,
                    paddingBottom: 0,
                    paddingTop: 0,
                    justifyContent: "space-between"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PreviewNavigation$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconButton"], {
                        color: "primary",
                        size: "small",
                        onClick: onPrevSite,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowBack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/ModalSites/index.tsx",
                            lineNumber: 134,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModalSites/index.tsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PreviewNavigation$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconButton"], {
                        onClick: onNextSite,
                        color: "primary",
                        size: "small",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowForward$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/components/ModalSites/index.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModalSites/index.tsx",
                        lineNumber: 137,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModalSites/index.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                sx: {
                    display: "flex",
                    padding: 2,
                    gap: "10px",
                    flexWrap: "nowrap"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: handleNavigateEdit,
                        color: "primary",
                        variant: "contained",
                        size: "small",
                        fullWidth: true,
                        children: "Edit site"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModalSites/index.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: handleNavigatePreview,
                        color: "decorate",
                        variant: "contained",
                        size: "small",
                        fullWidth: true,
                        children: "Create new site"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModalSites/index.tsx",
                        lineNumber: 154,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModalSites/index.tsx",
                lineNumber: 142,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ModalSites/index.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
};
_s(ModalSites, "8FD5PinPhiAamLHuigsytMOXy9o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ModalSites;
var _c;
__turbopack_refresh__.register(_c, "ModalSites");

})()),
"[project]/src/services/nostr/utils.ts [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Mutex": ()=>Mutex,
    "countItems": ()=>countItems,
    "eventIdToTag": ()=>eventIdToTag,
    "shuffleArray": ()=>shuffleArray
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/lib/esm/index.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
function shuffleArray(array) {
    for(let i = array.length - 1; i >= 0; i--){
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [
            array[j],
            array[i]
        ];
    }
}
function countItems(array) {
    const count = new Map();
    array.forEach(function(i) {
        count.set(i, (count.get(i) || 0) + 1);
    });
    return count;
}
class Mutex {
    queue = [];
    running = false;
    async execute() {
        const { cb, ok, err } = this.queue.shift();
        this.running = true;
        try {
            ok(await cb());
        } catch (e) {
            err(e);
        }
        this.running = false;
        if (this.queue.length > 0) this.execute();
    }
    hasPending() {
        return this.queue.length > 0;
    }
    async run(cb) {
        return new Promise(async (ok, err)=>{
            this.queue.push({
                cb,
                ok,
                err
            });
            if (!this.running && this.queue.length === 1) this.execute();
        });
    }
}
function eventIdToTag(id) {
    const { type, data } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(id);
    switch(type){
        case "note":
            return data;
        case "naddr":
            return `${data.kind}:${data.pubkey}:${data.identifier}`;
        default:
            throw new Error("Invalid related id " + id);
    }
}

})()),
"[project]/src/services/nostr/content.ts [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "fetchPost": ()=>fetchPost,
    "fetchSubmits": ()=>fetchSubmits,
    "filterSitePosts": ()=>filterSitePosts,
    "getSiteContributors": ()=>getSiteContributors,
    "parseNaddr": ()=>parseNaddr,
    "searchPosts": ()=>searchPosts,
    "signSubmitEvent": ()=>signSubmitEvent,
    "submitPost": ()=>submitPost,
    "suggestPosts": ()=>suggestPosts
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/lib/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/nostr.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/libnostrsite/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/marked/lib/marked.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/consts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/utils.ts [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
// site => posts
const submitsCache = new Map();
const cache = new Map();
function createAutoFilters(site) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        limit: 1,
        settings: site
    });
}
const suggestPosts = async (siteId)=>{
    const site = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSiteSettings"])(siteId);
    if (!site) throw new Error("Unknown site");
    const existing = await filterSitePosts(siteId, {});
    const authors = [
        ...new Set(existing.map((e)=>e.event.pubkey))
    ];
    const kinds = [
        ...new Set(existing.map((e)=>e.event.kind))
    ];
    const allHashtags = existing.map((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tags"])(e.event, "t").map((t)=>t[1])).flat();
    const hashtagCounts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["countItems"])(allHashtags);
    const hashtags = [
        ...hashtagCounts.entries()
    ].sort((a, b)=>b[1] - a[1]).map((t)=>t[0]);
    if (hashtags.length > 10) hashtags.length = 10;
    // use existing content to find authors, kinds and hashtags
    const sameAuthorPosts = await searchPosts(siteId, {
        authors,
        kinds,
        hashtags
    }, // onlyNew
    true);
    if (sameAuthorPosts.length) return sameAuthorPosts;
    // everything by these authors is imported, look
    // at other authors for the same hashtags
    const contacts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], {
        kinds: [
            3
        ],
        authors
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OUTBOX_RELAYS"], 3000);
    console.log("contacts", contacts);
    const followed = [
        ...new Set([
            ...contacts
        ].map((c)=>c.tags.filter((t)=>t.length > 1 && t[0] === "p" && t[1].length === 64).map((t)=>t[1])).flat())
    ];
    // throttle,
    // shuffle first to make sure we don't have bias against old followed
    // profiles that are likely to be dead already
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shuffleArray"])(followed);
    if (followed.length > 100) followed.length = 100;
    console.log("followed", followed);
    return await searchPosts(siteId, {
        authors: followed,
        kinds,
        hashtags
    }, // onlyNew
    true);
};
const searchPosts = async (siteId, { authors, kinds, hashtags, since, until, search }, onlyNew)=>{
    console.log("searchPosts", {
        authors,
        kinds,
        hashtags,
        since,
        until,
        search
    });
    const site = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSiteSettings"])(siteId);
    if (!site) throw new Error("Unknown site");
    // to mark search results as 'auto-submitted'
    const autoFilters = createAutoFilters(site);
    // to mark search results as 'submitted'
    const submitted = await fetchSubmits(site);
    // prepare filters
    const limit = 50;
    const filters = [];
    const add = (kind, tag)=>{
        const tagKey = "#" + tag?.tag;
        // reuse filters w/ same tag
        let f = filters.find((f)=>{
            // if (!f.kinds?.includes(kind)) return false;
            if (!tag) return !Object.keys(f).find((k)=>k.startsWith("#"));
            else return tagKey in f;
        });
        if (!f) {
            // first filter for this tag
            f = {
                authors,
                kinds: [
                    kind
                ],
                limit
            };
            if (tag) {
                // @ts-ignore
                f[tagKey] = [
                    tag.value
                ];
            }
            if (since) {
                f.since = since;
            }
            if (until) {
                f.until = until;
            }
            if (search) {
                f.search = search;
            }
            // append new filter
            filters.push(f);
        } else {
            // append tag and kind
            if (tag) {
                // @ts-ignore
                if (!f[tagKey].includes(tag.value)) {
                    // @ts-ignore
                    f[tagKey].push(tag.value);
                }
            }
            if (!f.kinds.includes(kind)) f.kinds.push(kind);
        }
    };
    if (!kinds) {
        kinds = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUPPORTED_KINDS"];
    }
    const addAll = (tag)=>{
        for (const k of kinds)add(k, tag);
    };
    if (hashtags) {
        for (const t of hashtags)addAll({
            tag: "t",
            value: t
        });
    } else {
        addAll();
    }
    console.log("search filters", filters);
    // search
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filters, // NOTE: we are looking for different authors and it's quite
    // hard to fetch relays for all of them, so for now we just opt-in
    // to use search relays for finding posts to submit
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"], 5000);
    console.log("searched events", events);
    const posts = [];
    for (const e of events){
        const post = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseEvent(e);
        if (!post) continue;
        cache.set(post.id, e);
        post.autoSubmitted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(e, autoFilters);
        post.submitterPubkey = submitted.find((s)=>s.id === post.id)?.submitterPubkey || "";
        post.relay = e.relay?.url;
        // skip
        if (onlyNew && (post.autoSubmitted || post.submitterPubkey)) continue;
        // add
        posts.push(post);
    }
    // add authors etc
    await postProcess(posts);
    // repeat the query if everything we've found so far has
    // been filtered out
    if (!posts.length && events.size) {
        const arr = [
            ...events
        ];
        return searchPosts(siteId, {
            authors,
            kinds,
            hashtags,
            since,
            search,
            until: arr.reduce((minCreatedAt, e)=>Math.min(minCreatedAt, e.created_at), arr[0].created_at) - 1
        }, onlyNew);
    }
    return posts;
};
async function getSiteContributors(siteId) {
    const site = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSiteSettings"])(siteId);
    if (!site) throw new Error("Unknown site");
    // cached for each site
    const submittedPosts = await fetchSubmits(site);
    return [
        site.admin_pubkey,
        ...site.contributor_pubkeys,
        ...submittedPosts.map((p)=>p.event.pubkey)
    ];
}
async function filterSitePosts(siteId, { authors, kinds, hashtags, since, until, search }) {
    console.log("filterSitePosts", {
        authors,
        kinds,
        hashtags,
        since,
        until,
        search
    });
    const site = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSiteSettings"])(siteId);
    if (!site) throw new Error("Unknown site");
    // cached for each site
    const submittedPosts = await fetchSubmits(site);
    // filter using search query
    const searchLower = search?.toLocaleLowerCase();
    const posts = [
        ...submittedPosts.filter((p)=>{
            // FIXME parse into words, match with words like relay does
            const tags = p.tags.map((t)=>t.name);
            return (!searchLower || p.title?.toLocaleLowerCase().includes(searchLower) || p.markdown?.toLocaleLowerCase().includes(searchLower) || p.id.toLocaleLowerCase().includes(searchLower)) && (!authors || authors.includes(p.event.pubkey)) && (!kinds || kinds.includes(p.event.kind)) && (!hashtags || hashtags.find((h)=>tags.includes(h))) && (!since || p.event.created_at >= since) && (!until || p.event.created_at <= until);
        })
    ];
    console.log("submitted filtered posts", posts);
    // FIXME soon we'll get rid of auto-filters
    // and will only work with submitted events!
    const filters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        since,
        until,
        authors,
        kinds,
        hashtags,
        limit: 50,
        settings: site
    });
    console.log("filters", site, filters);
    if (filters.length) {
        const relays = [
            ...site.contributor_relays
        ];
        if (search) {
            search += " include:spam";
            // only search relay
            relays.length = 0;
            relays.push(...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]);
        }
        if (!relays.length) relays.push(...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]);
        const autoEvents = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filters.map((f)=>({
                ...f,
                search
            })), relays);
        // used to mark as 'auto-submitted'
        const autoFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
            limit: 1,
            settings: site
        });
        // make sure it matches our other local filters (skip replies etc)
        const valid = [
            ...autoEvents
        ].filter((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(e, autoFilters));
        // convert filtered events to posts
        for (const e of valid){
            // skip ones that are manually submitted
            if (posts.find((p)=>p.id === (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventId"])(e))) continue;
            // parse
            const post = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseEvent(e);
            if (!post) continue;
            cache.set(post.id, e);
            post.submitterPubkey = "";
            post.autoSubmitted = false;
            post.relay = e.relay?.url;
            // status
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(e, autoFilters)) post.autoSubmitted = true;
            posts.push(post);
            console.log("auto post", post);
        }
    }
    await postProcess(posts);
    return posts;
}
async function postProcess(posts) {
    // NOTE: we're searching from nostr.band anyway, so why TF do we
    // mess with adding relay hint?
    // add relay hint to each post id
    // for (const post of posts) {
    //   if (!post.relay) continue;
    //   try {
    //     const { type, data } = nip19.decode(post.id);
    //     if (type === "naddr") {
    //       // FIXME use 'author' field to pass the pubkey
    //       post.id = nip19.naddrEncode({ ...data, relays: [post.relay] });
    //     } else if (type === "note") {
    //       post.id = nip19.neventEncode({ id: data, relays: [post.relay] });
    //     }
    //   } catch (e) {
    //     console.error("error", e, post);
    //   }
    // }
    // add hashtags
    for (const post of posts){
        // FIXME wtf? move to libnostrsite
        // @ts-ignore
        const hashtags = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseHashtags(post.event);
        // @ts-ignore
        post.tags = hashtags.map((t)=>({
                id: t.toLocaleLowerCase(),
                name: t
            }));
        post.primary_tag = post.tags?.[0] || null;
    }
    // add authors
    const pubkeys = [
        ...posts.map((p)=>p.event.pubkey),
        ...posts.filter((p)=>p.submitterPubkey).map((p)=>p.submitterPubkey)
    ];
    const profiles = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProfiles"])(pubkeys);
    const getProfile = (pubkey)=>{
        const event = profiles.find((p)=>p.pubkey === pubkey);
        return event ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseProfile(event) : undefined;
    };
    // add submitter profile
    for (const post of posts){
        const profile = getProfile(post.event.pubkey);
        if (profile) post.primary_author = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseAuthor(profile);
        if (post.submitterPubkey) post.submitterProfile = getProfile(post.submitterPubkey);
    }
    // make html
    for (const post of posts){
        post.html = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["marked"].parse(post.markdown, {
            // FIXME doesn't work!
            breaks: true
        });
    }
    // sort
    posts.sort((a, b)=>b.event.created_at - a.event.created_at);
}
function parseNaddr(naddr) {
    if (!naddr) return undefined;
    try {
        const { type, data } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(naddr);
        if (type === "naddr") return data;
    } catch (e) {
        console.log("Bad naddr", naddr, e);
    }
    return undefined;
}
async function fetchPost(site, id) {
    let event = cache.get(id);
    if (!event) {
        const { type, data } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(id);
        const relayHints = [
            ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_RELAYS"],
            ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]
        ];
        if (type !== "note" && type !== "naddr") throw new Error("Invalid id");
        if (type === "naddr") {
            if (data.relays?.[0]) relayHints.push(data.relays[0]);
            else {
                const relays = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOutboxRelays"])(data.pubkey);
                relayHints.push(...relays);
            }
        }
        const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchByIds"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], [
            id
        ], relayHints);
        if (!events.length) return undefined;
        event = events[0];
    }
    const post = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseEvent(event);
    console.log("fetchPost post", post);
    if (!post) return undefined;
    cache.set(post.id, event);
    const autoFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        limit: 1,
        settings: site
    });
    post.submitterPubkey = "";
    post.autoSubmitted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(event, autoFilters);
    post.relay = event.relay?.url;
    // check if it's submitted
    const addr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAddr"])(site.naddr);
    const s_tag = `${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]}:${addr.pubkey}:${addr.identifier}`;
    const filter = {
        // @ts-ignore
        kinds: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE_SUBMIT"]
        ],
        authors: [
            ...site.contributor_pubkeys,
            site.admin_pubkey
        ],
        "#s": [
            s_tag
        ]
    };
    if (post.id.startsWith("naddr")) {
        const postAddr = parseNaddr(post.id);
        if (!postAddr) throw new Error("Bad post id");
        filter["#a"] = [
            `${postAddr.kind}:${postAddr.pubkey}:${postAddr.identifier}`
        ];
    } else {
        filter["#e"] = [
            post.event.id
        ];
    }
    const submitEvent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filter, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"], 1000);
    if (submitEvent) {
        const submit = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseSubmitEvent(submitEvent);
        if (submit?.eventAddress === post.id && submit.state === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUBMIT_STATE_ADD"]) {
            post.submitterPubkey = submit.authorPubkey;
        }
    }
    await postProcess([
        post
    ]);
    return post;
}
async function fetchSubmits(site) {
    const cached = submitsCache.get(site.id);
    if (cached) return cached;
    const addr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAddr"])(site.naddr);
    const s_tag = `${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]}:${addr.pubkey}:${addr.identifier}`;
    const filter = {
        // @ts-ignore
        kinds: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE_SUBMIT"]
        ],
        authors: [
            ...new Set([
                ...site.contributor_pubkeys,
                site.event.pubkey
            ])
        ],
        "#s": [
            s_tag
        ]
    };
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scanRelays"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filter, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"], 10000, {
        batchSize: 1000,
        threads: 5,
        timeout: 3000
    });
    const relayHints = [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"]
    ];
    const submits = new Map();
    for (const e of events){
        const submit = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseSubmitEvent(e);
        if (!submit) continue;
        const existing = submits.get(submit.eventAddress);
        if (!existing || existing.event.created_at < submit.event.created_at) {
            submits.set(submit.eventAddress, submit);
            relayHints.push(submit.relay);
        }
    }
    const ids = [
        ...submits.values()
    ].filter((s)=>s.state === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUBMIT_STATE_ADD"]).map((s)=>s.eventAddress);
    console.log("submits", site.id, ids, submits);
    const submittedEvents = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchByIds"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], ids, relayHints);
    console.log("submittedEvents", ids, relayHints, submittedEvents);
    const autoFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        limit: 1,
        settings: site
    });
    const posts = [];
    for (const e of submittedEvents){
        const post = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseEvent(e);
        if (!post) continue;
        const submit = submits.get(post.id);
        // hmm...
        if (!submit) continue;
        cache.set(post.id, e);
        post.submitterPubkey = submit.authorPubkey;
        post.autoSubmitted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(post.event, autoFilters);
        post.relay = e.relay?.url;
        posts.push(post);
        console.log("submitted post", post);
    }
    submitsCache.set(site.id, posts);
    return posts;
}
async function getSubmitEvent(pubkey, id) {
    const relays = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOutboxRelays"])(pubkey);
    relays.push(...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]);
    const filter = {
        authors: [
            pubkey
        ]
    };
    const { type, data } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(id);
    switch(type){
        case "note":
            filter.ids = [
                data
            ];
            break;
        case "naddr":
            filter.kinds = [
                data.kind
            ];
            filter.authors = [
                data.pubkey
            ];
            filter["#d"] = [
                data.identifier
            ];
            break;
        default:
            throw new Error("Bad id");
    }
    const event = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filter, relays, 1000);
    if (event) cache.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventId"])(event), event);
    return {
        event,
        relay: event?.relay?.url || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"][0]
    };
}
async function signSubmitEvent(event) {
    let nevent;
    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userIsDelegated"]) {
        // mark current user as author
        event.tags.push([
            "u",
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]
        ]);
        const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/sign`, event);
        if (reply.status !== 200) throw new Error("Failed to sign submit event");
        const r = await reply.json();
        console.log(Date.now(), "signed submit event", r);
        nevent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKEvent"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], r.event);
    } else {
        nevent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKEvent"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], event);
        await nevent.sign(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKNip07Signer"]());
    }
    console.log("submit post event", nevent);
    return nevent;
}
async function submitPost(siteId, { id, author, kind, url, remove }) {
    const site = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSiteSettings"])(siteId);
    if (!site) throw new Error("Unknown site");
    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userIsDelegated"] && site.event.pubkey !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SERVER_PUBKEY"]) throw new Error("Can't submit in delegated mode");
    if (site.admin_pubkey !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"] && !site.contributor_pubkeys.includes(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"])) throw new Error("Only admin or contributor can submit posts");
    // we need event itself and a relay hint
    let submittedEvent = cache.get(id);
    let relayHint = submittedEvent?.relay?.url;
    if (!submittedEvent) {
        const { relay, event } = await getSubmitEvent(author, id);
        if (!event) throw new Error("Failed to fetch submitted event");
        submittedEvent = event;
        relayHint = relay;
    }
    // we also convert the submitted event to a post to cache it
    const post = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parser"].parseEvent(submittedEvent);
    if (!post) throw new Error("Failed to parse submitted event");
    const autoFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        limit: 1,
        settings: site
    });
    post.autoSubmitted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(post.event, autoFilters);
    if (remove) post.submitterPubkey = "";
    else post.submitterPubkey = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"];
    post.relay = relayHint;
    // add authors & tags
    await postProcess([
        post
    ]);
    // now prepare submit event
    const addr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAddr"])(siteId);
    const siteAddress = `${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]}:${addr.pubkey}:${addr.identifier}`;
    const eventIdTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventIdToTag"])(id);
    const pubkey = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userIsDelegated"] ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SERVER_PUBKEY"] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"];
    const event = {
        kind: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE_SUBMIT"],
        pubkey,
        created_at: Math.floor(Date.now() / 1000),
        content: "",
        tags: [
            [
                "d",
                `${siteAddress}_${eventIdTag}`
            ],
            [
                "s",
                siteAddress,
                site.admin_relays.length ? site.admin_relays[0] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SITE_RELAY"]
            ],
            [
                "k",
                "" + kind
            ],
            [
                "p",
                author
            ]
        ]
    };
    if (url) event.tags.push([
        "r",
        url
    ]);
    if (remove) event.tags.push([
        "state",
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUBMIT_STATE_REMOVE"]
    ]);
    else event.tags.push([
        "state",
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUBMIT_STATE_ADD"]
    ]);
    if (eventIdTag.includes(":")) event.tags.push([
        "a",
        eventIdTag,
        relayHint
    ]);
    else event.tags.push([
        "e",
        eventIdTag,
        relayHint
    ]);
    // sign it
    const nevent = await signSubmitEvent(event);
    // publish
    const r = await nevent.publish(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKRelaySet"].fromRelayUrls([
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]
    ], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"]));
    console.log("published submit event to", [
        ...r
    ].map((r)=>r.url));
    if (!r.size) throw new Error("Failed to publish to relays");
    // update cache
    let submitted = submitsCache.get(site.id) || [];
    // remove from submitted
    submitted = submitted.filter((s)=>s.id !== id);
    if (!remove) {
        // add back with current user as submitter
        submitted.push(post);
    }
    console.log("submitted", submitted);
    submitsCache.set(site.id, submitted);
    return post;
}

})()),
"[project]/src/services/nostr/api.ts [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "deleteSite": ()=>deleteSite,
    "editSite": ()=>editSite,
    "fetchAttachDomain": ()=>fetchAttachDomain,
    "fetchAttachDomainStatus": ()=>fetchAttachDomainStatus,
    "fetchCertDomain": ()=>fetchCertDomain,
    "fetchCertDomainStatus": ()=>fetchCertDomainStatus,
    "fetchDomains": ()=>fetchDomains,
    "fetchPins": ()=>fetchPins,
    "fetchProfiles": ()=>fetchProfiles,
    "fetchSites": ()=>fetchSites,
    "findSiteEvent": ()=>findSiteEvent,
    "getSiteSettings": ()=>getSiteSettings,
    "hasSite": ()=>hasSite,
    "parser": ()=>parser,
    "resetSites": ()=>resetSites,
    "savePins": ()=>savePins,
    "searchPosts": ()=>searchPosts,
    "searchProfiles": ()=>searchProfiles,
    "searchSites": ()=>searchSites
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/libnostrsite/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/nostr.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/lib/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/consts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/consts/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$content$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/content.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/utils.ts [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
// FIXME reuse decls from libnostrsite
const KIND_PINNED_ON_SITE = 30516;
const sites = [];
const packageThemes = new Map();
const parser = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NostrParser"]("http://localhost/");
let sitesPromise = undefined;
const profileCache = new Map();
const profileFetchMutex = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mutex"]();
function hasSite(id) {
    return sites.findIndex((s)=>s.id === id) >= 0;
}
function findSiteEvent(id) {
    return sites.find((s)=>s.id === id)?.event;
}
async function editSite(data) {
    const index = sites.findIndex((s)=>s.id === data.id);
    if (index < 0) throw new Error("Unknown site");
    const s = sites[index];
    const oldUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tv"])(s.event, "r");
    // need to re-deploy?
    let domain = "";
    let oldDomain = "";
    try {
        const u = new URL(data.url);
        if (!u.pathname.endsWith("/")) throw new Error("Path must end with /");
        if (u.hostname.endsWith("." + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"])) {
            const sub = u.hostname.split("." + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"])[0];
            if (!sub || sub.includes(".")) throw new Error("Bad sub domain");
            if (u.search) throw new Error("No query string allowed");
            if (u.pathname !== "/") throw new Error("Only / path allowed on " + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"]);
            domain = sub;
        }
        if (oldUrl) {
            const ou = new URL(oldUrl);
            if (ou.hostname.endsWith("." + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"])) oldDomain = ou.hostname.split("." + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"])[0];
        }
    } catch (e) {
        console.log("url error", data.url, e);
        throw e;
    }
    const e = s.event;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "name", data.name);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "title", data.title);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "summary", data.description);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "r", data.url);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "icon", data.icon);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "logo", data.logo);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "image", data.image);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "color", data.accentColor);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "lang", data.language);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "meta_description", data.metaDescription);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "meta_title", data.metaTitle);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "og_description", data.ogDescription);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "og_title", data.ogTitle);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "og_image", data.ogImage);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "twitter_title", data.xTitle);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "twitter_description", data.xDescription);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "twitter_image", data.xImage);
    // DEPRECATED
    // stv2(e, "config", "codeinjection_head", data.codeinjection_head);
    // stv2(e, "config", "codeinjection_foot", data.codeinjection_foot);
    // DEPRECATED
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["srm"])(e, "config");
    // new way
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["srm"])(e, "settings", "core");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "codeinjection_head", data.codeinjection_head);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "codeinjection_foot", data.codeinjection_foot);
    // ensure it's string!
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "posts_per_page", "" + data.postsPerPage);
    if (data.signupStartNjump) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "nostr_login.signup_start_njump", "true");
    if (data.sendStats) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "send_stats", "true");
    if (data.sendStatsDev) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "send_stats_dev", "true");
    // FIXME move to plugin settings later
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "content_cta_main", data.contentActionMain);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv3"])(e, "settings", "core", "content_cta_list", data.contentActions.join(","));
    // nav
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["srm"])(e, "nav");
    for (const n of data.navigation.primary)e.tags.push([
        "nav",
        n.link,
        n.title
    ]);
    // p tags
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["srm"])(e, "p");
    for (const p of [
        ...new Set(data.contributors)
    ])e.tags.push([
        "p",
        p
    ]);
    // edit tags
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["srm"])(e, "include");
    if (data.autoSubmit) {
        for (const t of [
            ...new Set(data.hashtags)
        ])e.tags.push([
            "include",
            "t",
            t.replace("#", "")
        ]);
        if (!data.hashtags.length) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stv"])(e, "include", "*");
    }
    for (const t of [
        ...new Set(data.hashtags_homepage)
    ])e.tags.push([
        "include",
        "t",
        t.replace("#", ""),
        "",
        "homepage"
    ]);
    // edit kinds
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["srm"])(e, "kind");
    for (const k of [
        ...new Set(data.kinds)
    ])e.tags.push([
        "kind",
        k + ""
    ]);
    for (const k of [
        ...new Set(data.kinds_homepage)
    ])e.tags.push([
        "kind",
        k + "",
        "",
        "homepage"
    ]);
    // const relays = [...userRelays, SITE_RELAY];
    const naddr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].naddrEncode({
        identifier: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tv"])(e, "d") || "",
        pubkey: e.pubkey,
        kind: e.kind
    });
    // ensure new domain is reserved
    // console.log("domain", domain, "oldDomain", oldDomain);
    if (domain && domain !== oldDomain) {
        const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/reserve?domain=${domain}&site=${naddr}&no_retry=true`);
        if (reply.status !== 200) throw new Error("Failed to reserve");
        const r = await reply.json();
        console.log(Date.now(), "reserved", r);
    }
    console.log("Signing", e);
    // publish new site event
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["publishSiteEvent"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKEvent"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], e));
    // redeploy if domain changed, also release the old domain
    // if (oldDomain && oldDomain !== domain)
    {
        const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(// from=oldDomain - delete the old site after 7 days
        `/deploy?domain=${domain}&site=${naddr}&from=${oldDomain}`);
        if (reply.status !== 200) throw new Error("Failed to deploy");
        const r = await reply.json();
        console.log(Date.now(), "deployed", r);
    }
    // parse updated site back
    sites[index] = parseSite(e);
    // clear the temporary store
    window.localStorage.removeItem((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventId"])(e));
}
async function deleteSite(siteId) {
    const index = sites.findIndex((s)=>s.id === siteId);
    if (index < 0) throw new Error("Unknown site");
    const site = sites[index];
    // delete from relays first
    const relays = [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SITE_RELAY"]
    ];
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteSiteEvent"])(site.event, relays);
    // delete site from npub.pro database
    let domain = "";
    try {
        const u = new URL(site.origin || "");
        if (u.hostname.endsWith("." + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"])) {
            domain = u.hostname.split("." + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NPUB_PRO_DOMAIN"])[0];
        }
    } catch (e) {
        console.log("Bad site url", site.url);
    }
    const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/delete?domain=${domain}&site=${siteId}`);
    if (reply.status !== 200) throw new Error("Failed to delete domain");
    const r = await reply.json();
    console.log(Date.now(), "deleted domain", r);
    // delete from local cache
    sites.splice(index, 1);
}
function convertSites(sites) {
    return sites.map((s)=>({
            id: s.id,
            adminPubkey: s.admin_pubkey,
            themeId: packageThemes.get(s.extensions?.[0].event_id || "") || "",
            themeName: s.extensions?.[0].petname || "",
            contributors: s.contributor_pubkeys,
            autoSubmit: Boolean(s.include_all) || Boolean(s.include_tags?.length),
            hashtags: s.include_tags?.filter((t)=>t.tag === "t").map((t)=>"#" + t.value) || [],
            kinds: s.include_kinds?.map((k)=>parseInt(k)) || [
                1
            ],
            hashtags_homepage: s.homepage_tags?.filter((t)=>t.tag === "t").map((t)=>"#" + t.value) || [],
            kinds_homepage: s.homepage_kinds?.map((k)=>parseInt(k)) || [],
            accentColor: s.accent_color || "",
            name: s.name,
            title: s.title || "",
            description: s.description || "",
            // @ts-ignore
            url: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tv"])(s.event, "r") || "",
            icon: s.icon || "",
            logo: s.logo || "",
            image: s.cover_image || "",
            language: s.lang || "",
            timezone: {
                name: "",
                label: ""
            },
            metaDescription: s.meta_description || "",
            metaTitle: s.meta_title || "",
            ogDescription: s.og_description || "",
            ogTitle: s.og_title || "",
            ogImage: s.og_image || "",
            xTitle: s.twitter_title || "",
            xImage: s.twitter_image || "",
            xDescription: s.twitter_description || "",
            fTitle: "",
            fDescription: "",
            socialAccountFaceBook: "",
            socialAccountX: "",
            codeinjection_head: s.codeinjection_head || "",
            codeinjection_foot: s.codeinjection_foot || "",
            navigation: {
                primary: s.navigation?.map((n, i)=>({
                        title: n.label,
                        link: n.url,
                        id: "" + i
                    })) || [],
                secondary: s.secondary_navigation?.map((n, i)=>({
                        title: n.label,
                        link: n.url,
                        id: "" + i
                    })) || []
            },
            signupStartNjump: s.config.get("nostr_login.signup_start_njump") === "true",
            sendStats: s.config.get("send_stats") === "true",
            sendStatsDev: s.config.get("send_stats_dev") === "true",
            postsPerPage: s.config.get("posts_per_page") || "",
            contentActionMain: s.config.get("content_cta_main") || "",
            contentActions: (s.config.get("content_cta_list") || "").split(",").map((s)=>s.trim()).filter((s)=>!!s)
        }));
}
async function fetchSiteThemes() {
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], {
        // @ts-ignore
        kinds: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_PACKAGE"]
        ],
        ids: sites.map((s)=>s.extensions?.[0].event_id || "").filter((id)=>!!id)
    }, [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SITE_RELAY"]
    ]);
    for (const e of events){
        const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseATag"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tv"])(e, "a"));
        if (!a || !a.pubkey) continue;
        const naddr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].naddrEncode(a);
        packageThemes.set(e.id, naddr);
    }
}
function parseSite(ne) {
    const e = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKEvent"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], ne);
    const addr = {
        identifier: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tv"])(e, "d") || "",
        pubkey: e.pubkey,
        relays: [
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SITE_RELAY"],
            ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"]
        ]
    };
    return parser.parseSite(addr, e);
}
async function getSiteSettings(siteId) {
    await fetchSites();
    return sites.find((s)=>s.id === siteId);
}
async function fetchSites() {
    console.log("fetchSites", __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]);
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]) throw new Error("Auth please");
    if (sitesPromise) await sitesPromise;
    if (!sites.length) {
        sitesPromise = new Promise(async (ok)=>{
            const relays = [
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SITE_RELAY"],
                ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"]
            ];
            const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], [
                // owned
                {
                    // @ts-ignore
                    kinds: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]
                    ],
                    authors: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]
                    ]
                },
                // delegated
                {
                    authors: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SERVER_PUBKEY"]
                    ],
                    // @ts-ignore
                    kinds: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]
                    ],
                    "#u": [
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]
                    ]
                },
                // contributor
                {
                    // @ts-ignore
                    kinds: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]
                    ],
                    "#p": [
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]
                    ]
                }
            ], relays, 5000);
            console.log("site events", events);
            // sort by timestamp desc
            const array = [
                ...events.values()
            ].sort((a, b)=>b.created_at - a.created_at);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterDeleted"])(array, relays);
            sites.push(...array.map((e)=>parseSite(e.rawEvent())));
            await fetchSiteThemes();
            ok();
        });
        await sitesPromise;
        console.log("sites", sites);
    }
    return convertSites(sites);
}
function resetSites() {
    sites.length = 0;
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addOnAuth"])(async (type)=>{
    // clear sites on logout
    if (type === "logout") sites.length = 0;
});
async function fetchProfiles(pubkeys) {
    return profileFetchMutex.run(async ()=>{
        const res = [];
        const req = [];
        for (const p of pubkeys){
            const c = profileCache.get(p);
            if (c === undefined) {
                req.push(p);
            } else if (c !== null) {
                res.push(c);
            }
        }
        if (!req.length) {
            return res;
        }
        const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], {
            kinds: [
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_PROFILE"]
            ],
            authors: req
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OUTBOX_RELAYS"]);
        for (const e of events){
            profileCache.set(e.pubkey, e);
            res.push(e);
        }
        for (const p of req){
            if (!profileCache.get(p)) profileCache.set(p, null);
        }
        return res;
    });
}
async function searchProfiles(text) {
    let search = text + " include:spam";
    if (!text.trim().startsWith("npub1")) search += " sort:popular";
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], {
        kinds: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_PROFILE"]
        ],
        search,
        limit: 3
    }, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]);
    for (const e of events){
        profileCache.set(e.pubkey, e);
    }
    return [
        ...events
    ];
}
async function searchSites(text, until) {
    const limitFetchSites = 50;
    const filter = {
        kinds: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]
        ],
        limit: limitFetchSites
    };
    if (text) filter.search = text;
    if (until) filter.until = until - 1;
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filter, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"], 5000);
    const isMore = !([
        ...events
    ].length < limitFetchSites);
    const array = [
        ...events
    ].sort((a, b)=>b.created_at - a.created_at);
    const relays = [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$consts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SITE_RELAY"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userRelays"]
    ];
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterDeleted"])(array, relays);
    const sites = array.map((e)=>parseSite(e.rawEvent()));
    const pubkeys = sites.map((s)=>s.admin_pubkey);
    const profiles = await fetchProfiles(pubkeys);
    const res = convertSites(sites);
    res.forEach((s)=>{
        const profile = profiles.find((p)=>p.pubkey === s.adminPubkey);
        const npub = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].npubEncode(s.adminPubkey);
        if (profile) {
            try {
                const meta = JSON.parse(profile.content);
                s.adminName = meta.display_name || meta.name || npub.substring(0, 10) + "...";
                s.adminAvatar = meta.picture || "";
            } catch  {}
        }
    });
    return [
        res,
        array.length ? array[sites.length - 1].created_at : 0,
        isMore
    ];
}
const fetchCertDomain = async (domain)=>{
    const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/cert?domain=${domain}`, undefined, "POST");
    if (reply.status === 200) return reply.json();
    else throw new Error("Failed to issue certificate");
};
const fetchCertDomainStatus = async (domain)=>{
    const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/cert?domain=${domain}`);
    if (reply.status === 200) return reply.json();
    else throw new Error("Failed to fetch certificate status");
};
const fetchAttachDomain = async (domain, site)=>{
    const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/attach?domain=${domain}&site=${site}`, undefined, "POST");
    if (reply.status === 200) return reply.json();
    else throw new Error("Failed to attach domain");
};
const fetchAttachDomainStatus = async (domain, site)=>{
    const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/attach?domain=${domain}&site=${site}`);
    if (reply.status === 200) return reply.json();
    else throw new Error("Failed to fetch domain status");
};
const fetchDomains = async (site)=>{
    const reply = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithSession"])(`/attach?site=${site}`);
    return reply.json();
};
const searchPosts = async (siteId, query)=>{
    const site = sites.find((s)=>s.id === siteId);
    if (!site) return [];
    const filters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        settings: site,
        limit: 10
    });
    console.log("search filters", filters);
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], filters.map((f)=>({
            ...f,
            search: query
        })), __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]);
    console.log("searched events", events);
    const valid = [
        ...events
    ].filter((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(e, filters));
    const posts = [];
    for (const e of valid){
        const post = await parser.parseEvent(e);
        if (post) posts.push(post);
    }
    return posts;
};
const fetchPins = async (siteId)=>{
    const site = sites.find((s)=>s.id === siteId);
    if (!site) return [];
    const addr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAddr"])(siteId);
    const pinList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvent"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], {
        "#d": [
            `${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]}:${addr.pubkey}:${addr.identifier}`
        ],
        kinds: [
            KIND_PINNED_ON_SITE
        ],
        authors: [
            site.admin_pubkey
        ]
    }, [
        ...site.admin_relays,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]
    ]);
    console.log("pinList", pinList);
    const idAddrs = new Set();
    if (pinList) {
        const ids = parser.parsePins(pinList);
        for (const id of ids)idAddrs.add(id);
    }
    console.log("idAddrs", {
        idAddrs
    });
    const pinFilters = [];
    const idFilter = {
        ids: [
            ...idAddrs
        ].filter((i)=>i.startsWith("note")).map((id)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(id).data)
    };
    const addrs = [
        ...idAddrs
    ].filter((i)=>i.startsWith("naddr")).map((a)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(a).data);
    const addrFilter = {
        authors: [
            ...new Set(addrs.map((a)=>a.pubkey))
        ],
        kinds: [
            ...new Set(addrs.map((a)=>a.kind))
        ],
        "#d": [
            ...new Set(addrs.map((a)=>a.identifier))
        ]
    };
    if (idFilter.ids?.length) pinFilters.push(idFilter);
    if (addrFilter.authors?.length) pinFilters.push(addrFilter);
    console.log("pinFilters", pinFilters);
    if (!pinFilters.length) return [];
    const pinned = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchEvents"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], pinFilters, [
        ...site.contributor_relays,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]
    ]);
    console.log("pinned", pinned);
    const submits = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$content$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchSubmits"])(site);
    const siteFilters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSiteFilters"])({
        settings: site,
        limit: 10
    });
    const valid = [
        ...pinned
    ].filter((p)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPostsToFilters"])(p, siteFilters) || submits.find((s)=>s.id === (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventId"])(p)));
    console.log("pinned valid", valid);
    const posts = [];
    for (const e of valid){
        const post = await parser.parseEvent(e);
        if (post) posts.push(post);
    }
    return posts;
};
const savePins = async (siteId, ids)=>{
    if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userIsDelegated"]) throw new Error("Can't edit pins in delegated mode");
    const site = sites.find((s)=>s.id === siteId);
    if (!site) return [];
    if (site.admin_pubkey !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]) throw new Error("Only admin can edit pins");
    const addr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAddr"])(siteId);
    const event = {
        kind: KIND_PINNED_ON_SITE,
        content: "",
        created_at: Math.floor(Date.now() / 1000),
        tags: [
            [
                "d",
                `${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libnostrsite$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KIND_SITE"]}:${addr.pubkey}:${addr.identifier}`
            ]
        ],
        pubkey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userPubkey"]
    };
    const tags = ids.map((id)=>{
        const { type, data } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nip19"].decode(id);
        switch(type){
            case "note":
                return [
                    "e",
                    data
                ];
            case "nevent":
                return [
                    "e",
                    data.id
                ];
            case "naddr":
                return [
                    "a",
                    `${data.kind}:${data.pubkey}:${data.identifier}`
                ];
            default:
                return undefined;
        }
    }).filter(Boolean);
    event.tags.push(...tags);
    // sign it
    const nevent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKEvent"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"], event);
    await nevent.sign(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKNip07Signer"]());
    console.log("signed pins event", nevent);
    // publish
    const r = await nevent.publish(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NDKRelaySet"].fromRelayUrls([
        ...site.admin_relays,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SEARCH_RELAYS"]
    ], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ndk"]));
    console.log("published pins event to", [
        ...r
    ].map((r)=>r.url));
    if (!r.size) throw new Error("Failed to publish to relays");
};

})()),
"[project]/src/services/sites.service.ts [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "getSettingsSite": ()=>getSettingsSite,
    "getSites": ()=>getSites
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/api.ts [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const getSites = async ()=>{
    try {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchSites"])();
    // const res: AxiosResponse<any> = await ApiClient.get("/sites");
    // return res.data;
    } catch (error) {
        throw new Error(error);
    }
};
const getSettingsSite = async (id)=>{
    try {
        const site = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchSites"])()).find((s)=>s.id === id);
        console.log("site", site);
        return {
            ...site
        }; // FIXME remove, add empty hashtags for test and accentColor
    // const res: AxiosResponse<any> = await ApiClient.get(
    //   `/settings-site?id=${id}`,
    // );
    // return res.data;
    } catch (error) {
        throw new Error(error);
    }
};

})()),
"[project]/src/hooks/useListSites.ts [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "useListSites": ()=>useListSites
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$sites$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/sites.service.ts [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
var _s = __turbopack_refresh__.signature();
;
;
const useListSites = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "sites"
        ],
        queryFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$sites$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSites"],
        refetchOnMount: true,
        refetchOnWindowFocus: true
    });
};
_s(useListSites, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});

})()),
"[project]/src/components/ThemesOnboarding/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "ThemesOnboarding": ()=>ThemesOnboarding
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ThemesOnboarding/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemePreview$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ThemePreview/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/consts/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/nostr/nostr.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModalSites$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ModalSites/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useListSites$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/hooks/useListSites.ts [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
const ThemesOnboarding = ()=>{
    _s();
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useListSites$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useListSites"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { isAuth } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$nostr$2f$nostr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthContext"]);
    const [activeTag, setActiveTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showAllThemes, setShowAllThemes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isOpen, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [themeId, setThemeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const maxThemesToShow = 9;
    const filteredData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>activeTag ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["THEMES_PREVIEW"].filter((item)=>item.tag === activeTag) : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["THEMES_PREVIEW"], [
        activeTag
    ]);
    const handleChoise = (tag)=>{
        setActiveTag((prev)=>prev === tag ? null : tag);
        setShowAllThemes(true);
    };
    const getColor = (tag)=>activeTag === tag ? "decorate" : "lightInfo";
    const handleMoreTheme = ()=>{
        setShowAllThemes((prev)=>!prev);
    };
    const handleNavigate = (id)=>{
        if (isAuth && data?.length) {
            setOpen(true);
            setThemeId(id);
            return;
        }
        router.push(`/preview?themeId=${id}${activeTag ? `&tag=${activeTag}` : ""}`);
    };
    const handleClose = ()=>{
        setOpen(false);
        setThemeId("");
    };
    const displayedThemes = showAllThemes ? filteredData : filteredData.slice(0, maxThemesToShow);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
                    maxWidth: "lg",
                    id: "themes-onboarding",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                            children: "Pick a theme to start"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButtonGroup"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].MICROBLOG),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].MICROBLOG),
                                    children: "Microblog"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].BLOG),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].BLOG),
                                    children: "Blog"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 85,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].PODCAST),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].PODCAST),
                                    children: "Podcast"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 93,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].RECIPES),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].RECIPES),
                                    children: "Recipes"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].PHOTOGRAPHY),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].PHOTOGRAPHY),
                                    children: "Photography"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 109,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].MAGAZINE),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].MAGAZINE),
                                    children: "Magazine"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 117,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                    color: getColor(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].APPS),
                                    variant: "contained",
                                    onClick: ()=>handleChoise(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$consts$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPES_THEMES_TAG"].APPS),
                                    children: "Apps"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                    lineNumber: 125,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledPreviews"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                container: true,
                                spacing: {
                                    xs: "15px",
                                    md: "30px"
                                },
                                columns: {
                                    xs: 4,
                                    sm: 8,
                                    md: 12
                                },
                                children: displayedThemes.map((el, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        item: true,
                                        xs: 4,
                                        sm: 4,
                                        md: 4,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemePreview$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemePreview"], {
                                            alt: el.name,
                                            preview: el.preview,
                                            handleNavigate: ()=>handleNavigate(el.id)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                            lineNumber: 142,
                                            columnNumber: 19
                                        }, this)
                                    }, index, false, {
                                        fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                        lineNumber: 141,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                lineNumber: 135,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                            lineNumber: 134,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledMoreButton"], {
                            children: !showAllThemes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledButton"], {
                                color: "decorate",
                                variant: "contained",
                                onClick: handleMoreTheme,
                                children: "More Themes"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                                lineNumber: 154,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                            lineNumber: 152,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                    lineNumber: 74,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModalSites$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModalSites"], {
                handleClose: handleClose,
                themeId: themeId,
                tag: activeTag,
                isOpen: isOpen,
                sites: data ? data : []
            }, void 0, false, {
                fileName: "[project]/src/components/ThemesOnboarding/index.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
_s(ThemesOnboarding, "Xv9Een4LKWSRP5kJg7W980Z0ApI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useListSites$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useListSites"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ThemesOnboarding;
var _c;
__turbopack_refresh__.register(_c, "ThemesOnboarding");

})()),
"[project]/src/components/Pages/Landing/components/Benefits/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledTitle": ()=>StyledTitle,
    "StyledWrap": ()=>StyledWrap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: theme.palette.primary.main,
        color: "#fff",
        paddingBottom: "120px",
        paddingTop: "120px",
        [theme.breakpoints.down("md")]: {
            paddingBottom: "64px",
            paddingTop: "64px"
        }
    }));
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 48,
        color: "#fff",
        textAlign: "center",
        fontWeight: "bold",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        marginBottom: 64,
        [theme.breakpoints.down("md")]: {
            fontSize: 32,
            marginBottom: 24
        }
    }));

})()),
"[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledBottomInfo": ()=>StyledBottomInfo,
    "StyledFullGrayBenefit": ()=>StyledFullGrayBenefit,
    "StyledFullLightGrayBenefit": ()=>StyledFullLightGrayBenefit,
    "StyledLightBenefit": ()=>StyledLightBenefit,
    "StyledOpenSourceEmblem": ()=>StyledOpenSourceEmblem,
    "StyledOpenSourceEmblemWrap": ()=>StyledOpenSourceEmblemWrap,
    "StyledOpenSourceSubTitle": ()=>StyledOpenSourceSubTitle,
    "StyledOpenSourceTitle": ()=>StyledOpenSourceTitle,
    "StyledSubTitleFullBlock": ()=>StyledSubTitleFullBlock,
    "StyledTitleBlock": ()=>StyledTitleBlock,
    "StyledTitleFullBlock": ()=>StyledTitleFullBlock
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const StyledLightBenefit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: "#fff",
        borderRadius: 40,
        padding: 48,
        height: "100%",
        [theme.breakpoints.down("md")]: {
            padding: 24
        }
    }));
const StyledFullGrayBenefit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: "#606677",
        borderRadius: 40,
        padding: 48,
        paddingBottom: 64,
        paddingTop: 128,
        [theme.breakpoints.down("md")]: {
            padding: 24,
            paddingBottom: 32,
            paddingTop: 32
        }
    }));
const StyledFullLightGrayBenefit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: "#727A8E",
        borderRadius: 40,
        padding: 96,
        display: "flex",
        alignItems: "center",
        gap: 128,
        [theme.breakpoints.down("md")]: {
            flexDirection: "column",
            alignItems: "start",
            padding: 24,
            gap: 48
        }
    }));
const StyledOpenSourceEmblemWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        height: 320,
        borderRadius: 40,
        maxWidth: 320,
        display: "flex",
        width: "100%",
        background: "linear-gradient(to top, #FF3ED9, #FFF)"
    }));
const StyledOpenSourceEmblem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        height: "calc(100% - 8px)",
        width: "calc(100% - 8px)",
        borderRadius: 40,
        background: "#727A8E",
        margin: "auto",
        display: "flex",
        justifyContent: "end",
        alignItems: "end",
        padding: 15,
        flexDirection: "column"
    }));
const StyledOpenSourceTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: "700",
        fontSize: 137,
        lineHeight: "100px",
        color: "#fff",
        [theme.breakpoints.down("sm")]: {
            fontSize: 107
        }
    }));
const StyledOpenSourceSubTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontWeight: "600",
        fontSize: 20,
        maxWidth: 250,
        textAlign: "right",
        marginBottom: 10,
        color: "#fff",
        [theme.breakpoints.down("md")]: {
            fontSize: 16,
            maxWidth: 180
        }
    }));
const StyledTitleBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: "700",
        fontSize: 32,
        lineHeight: "39px",
        color: theme.palette.secondary.main,
        span: {
            color: theme.palette.decorate.main
        },
        [theme.breakpoints.down("md")]: {
            fontSize: 24,
            lineHeight: "29px"
        }
    }));
const StyledBottomInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        height: "100%",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "end"
    }));
const StyledTitleFullBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: "700",
        fontSize: 48,
        color: "#fff",
        marginBottom: 18,
        lineHeight: "59px",
        [theme.breakpoints.down("md")]: {
            marginBottom: 16,
            fontSize: 32,
            lineHeight: "39px"
        }
    }));
const StyledSubTitleFullBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        fontWeight: "600",
        fontSize: 24,
        color: "#fff",
        lineHeight: "34px"
    }));

})()),
"[project]/src/components/Pages/Landing/components/SocialBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledBenefitImgFooter": ()=>StyledBenefitImgFooter,
    "StyledBenefitImgSubTitle": ()=>StyledBenefitImgSubTitle,
    "StyledBenefitImgTitle": ()=>StyledBenefitImgTitle,
    "StyledWrapImg": ()=>StyledWrapImg
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const StyledWrapImg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        height: "320px",
        width: "100%",
        borderRadius: 32,
        overflow: "hidden",
        position: "relative",
        img: {
            height: "100%",
            width: "100%",
            objectFit: "cover",
            position: "absolute",
            left: 0,
            top: 0
        },
        marginTop: 80,
        [theme.breakpoints.down("md")]: {
            marginTop: 48,
            height: "240px"
        }
    }));
const StyledBenefitImgFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        position: "absolute",
        bottom: 0,
        left: 0,
        width: "100%",
        padding: "13px 28px",
        backdropFilter: "blur(7px)",
        [theme.breakpoints.down("md")]: {
            padding: "13px 20px"
        }
    }));
const StyledBenefitImgTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        color: "#fff",
        fontSize: "18px",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: "600",
        textTransform: "capitalize",
        marginBottom: 4
    }));
const StyledBenefitImgSubTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        color: "#fff",
        fontSize: "14px",
        fontWeight: "600",
        opacity: 0.7
    }));

})()),
"[project]/public/images/onboarding/social-benifit.jpg [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/social-benifit.558aeabc.jpg");
})()),
"[project]/public/images/onboarding/social-benifit.jpg.mjs { IMAGE => \"[project]/public/images/onboarding/social-benifit.jpg [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$social$2d$benifit$2e$jpg__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/onboarding/social-benifit.jpg [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$social$2d$benifit$2e$jpg__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 878,
    height: 585,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAFAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDS069aaK4d0G6MqqnPTPX+Vdc2/bRXkyl8DP/Z",
    blurWidth: 8,
    blurHeight: 5
};

})()),
"[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "SocialBenefit": ()=>SocialBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/SocialBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$social$2d$benifit$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$social$2d$benifit$2e$jpg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/onboarding/social-benifit.jpg.mjs { IMAGE => "[project]/public/images/onboarding/social-benifit.jpg [app-client] (static)" } [app-client] (structured image object, ecmascript)');
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
const SocialBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledLightBenefit"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleBlock"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Great for Sharing."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                        lineNumber: 18,
                        columnNumber: 9
                    }, this),
                    " Great looking previews on all social networks and messaging apps."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapImg"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$social$2d$benifit$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$social$2d$benifit$2e$jpg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "Social benefit",
                        priority: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledBenefitImgFooter"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledBenefitImgTitle"], {
                                children: "How to show your pug the love he deserves"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledBenefitImgSubTitle"], {
                                children: "sam.npub.pro"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
};
_c = SocialBenefit;
var _c;
__turbopack_refresh__.register(_c, "SocialBenefit");

})()),
"[project]/src/components/Pages/Landing/components/SeoBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledIcon": ()=>StyledIcon
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        height: "auto",
        width: 126,
        marginBottom: 80,
        [theme.breakpoints.down("md")]: {
            marginBottom: 48,
            width: 94
        }
    }));

})()),
"[project]/src/components/Pages/Landing/components/SeoBenefit/IconSeo.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "IconSeo": ()=>IconSeo
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const IconSeo = ()=>{
    // useEffect(() => {
    //   const handleLoad = () => {
    //     const body_tree = {
    //       id: "282:105",
    //       name: "SEO",
    //       type: "FRAME",
    //       deep_level: 0,
    //       locked: false,
    //       children: [
    //         {
    //           id: "282:109",
    //           name: "Vector",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:105",
    //           svg_node_id: "Vector",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(0px, 0px) rotateX(-11.8628deg) rotateY(5.47819deg)",
    //         },
    //         {
    //           id: "282:110",
    //           name: "Vector_2",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:105",
    //           svg_node_id: "Vector_2",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(-1.35625px, 0.269592px) rotateX(-11.8628deg) rotateY(5.47819deg)",
    //         },
    //       ],
    //       visible: true,
    //       svg_node_id: "SEO",
    //       svg_node: {},
    //     };
    //
    //     const icon = document.getElementById("icon-seo");
    //
    //     if (icon) {
    //       icon.addEventListener("mousemove", function (e) {
    //         MoveBackground(e, icon);
    //       });
    //
    //       icon.addEventListener("mouseleave", function (e) {
    //         body_tree.children.forEach((elemennt, index) => {
    //           const el = document.getElementById(elemennt.svg_node_id);
    //
    //           el.style.transformOrigin = elemennt.transformOrigin;
    //           el.style.transform = elemennt.transform;
    //           el.style.transition = ".3s";
    //         });
    //       });
    //     }
    //     function parseDigit(str) {
    //       const result = str.match(/(-?\d+(\.\d+)?)/g).map((v) => +v);
    //       return { tdeg: result[0], tox: result[1], toy: result[2] };
    //     }
    //     function MoveBackground(e, icon) {
    //       body_tree.children.forEach((elemennt, index) => {
    //         const el = document.getElementById(elemennt.svg_node_id);
    //         const iconReact = icon.getBoundingClientRect();
    //         if (elemennt.locked || !el) return;
    //         const ind = index;
    //         const i = ind;
    //         const offsetX =
    //           (e.clientX / window.innerWidth) * 30 * i * 0.4 - 15 * i * 0.4;
    //         const offsetY =
    //           (e.clientY / window.innerHeight) * 30 * i * 0.4 - 15 * i * 0.4;
    //         const transform = el
    //           ?.getAttribute("transform")
    //           ?.match(/rotate\(.*\)/);
    //
    //         const xOrigin =
    //           document.querySelector("body").getBoundingClientRect().width / 2;
    //         const yOrigin =
    //           document.querySelector("body").getBoundingClientRect().height / 2;
    //         console.log(iconReact)
    //         const yRot = ((e.clientX - xOrigin) / xOrigin) * -25;
    //         const xRot = ((e.clientY - yOrigin) / yOrigin) * 25;
    //         let { tdeg, tox, toy } = transform
    //           ? parseDigit(transform[0])
    //           : { tdeg: null, tox: null, toy: null };
    //         el.style.transformOrigin =
    //           transform && (tox || toy) ? `${tox}px, ${toy}px` : "center";
    //         el.style.transform =
    //           "translate(" +
    //           offsetX +
    //           "px," +
    //           offsetY +
    //           "px) " +
    //           (transform ? ` rotate(${tdeg}deg)` : "") +
    //           ` rotateX(${xRot}deg) rotateY(${yRot}deg)`;
    //         el.style.transition = "none";
    //       });
    //     }
    //   };
    //
    //   if (document.readyState === "complete") {
    //     handleLoad();
    //   } else {
    //     window.addEventListener("load", handleLoad);
    //
    //     return () => {
    //       window.removeEventListener("load", handleLoad);
    //     };
    //   }
    // }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 126 126",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
            height: "100%",
            width: "100%"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
            id: "SEO",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector",
                    d: "M63 9.84375C52.4867 9.84375 42.2095 12.9613 33.468 18.8022C24.7265 24.6431 17.9133 32.9449 13.8901 42.658C9.86678 52.371 8.81411 63.059 10.8652 73.3703C12.9162 83.6816 17.9788 93.1531 25.4129 100.587C32.8469 108.021 42.3184 113.084 52.6297 115.135C62.9411 117.186 73.629 116.133 83.342 112.11C93.0551 108.087 101.357 101.274 107.198 92.532C113.039 83.7905 116.156 73.5133 116.156 63C116.141 48.9069 110.535 35.3955 100.57 25.4301C90.6046 15.4648 77.0931 9.85938 63 9.84375ZM63 104.344C54.823 104.344 46.8296 101.919 40.0307 97.3761C33.2317 92.8332 27.9326 86.3761 24.8034 78.8216C21.6742 71.267 20.8554 62.9541 22.4507 54.9342C24.0459 46.9143 27.9835 39.5476 33.7656 33.7656C39.5476 27.9835 46.9144 24.0459 54.9343 22.4507C62.9542 20.8554 71.267 21.6741 78.8216 24.8034C86.3762 27.9326 92.8332 33.2317 97.3761 40.0306C101.919 46.8296 104.344 54.823 104.344 63C104.332 73.9614 99.9724 84.4706 92.2215 92.2215C84.4706 99.9724 73.9615 104.332 63 104.344ZM80.3595 37.8984L52.797 49.7109C51.4038 50.3083 50.2936 51.4185 49.6962 52.8117L37.8837 80.3742C37.427 81.4581 37.3043 82.6537 37.5314 83.8077C37.7585 84.9617 38.3249 86.0217 39.1582 86.8518C39.9914 87.6819 41.0536 88.2443 42.2085 88.4669C43.3634 88.6896 44.5584 88.5624 45.6406 88.1016L73.2031 76.2891C74.5963 75.6917 75.7065 74.5815 76.3038 73.1883L88.1163 45.6258C88.573 44.5419 88.6957 43.3463 88.4686 42.1923C88.2416 41.0383 87.6751 39.9783 86.8419 39.1482C86.0086 38.3181 84.9465 37.7557 83.7916 37.5331C82.6367 37.3104 81.4416 37.4376 80.3595 37.8984ZM66.3764 66.3912L54.5639 71.4558L59.6285 59.6433L71.441 54.5787L66.3764 66.3912Z",
                    fill: "#FF3ED9",
                    fillOpacity: "0.5",
                    style: {
                        transform: "translate(0px, 0px) rotateX(-11.8628deg) rotateY(5.47819deg)",
                        transformOrigin: "center center"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/IconSeo.tsx",
                    lineNumber: 127,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector_2",
                    d: "M63 9.84375C52.4867 9.84375 42.2095 12.9613 33.468 18.8022C24.7265 24.6431 17.9133 32.9449 13.8901 42.658C9.86678 52.371 8.81411 63.059 10.8652 73.3703C12.9162 83.6816 17.9788 93.1531 25.4129 100.587C32.8469 108.021 42.3184 113.084 52.6297 115.135C62.9411 117.186 73.629 116.133 83.342 112.11C93.0551 108.087 101.357 101.274 107.198 92.532C113.039 83.7905 116.156 73.5133 116.156 63C116.141 48.9069 110.535 35.3955 100.57 25.4301C90.6046 15.4648 77.0931 9.85938 63 9.84375ZM63 104.344C54.823 104.344 46.8296 101.919 40.0307 97.3761C33.2317 92.8332 27.9326 86.3761 24.8034 78.8216C21.6742 71.267 20.8554 62.9541 22.4507 54.9342C24.0459 46.9143 27.9835 39.5476 33.7656 33.7656C39.5476 27.9835 46.9144 24.0459 54.9343 22.4507C62.9542 20.8554 71.267 21.6741 78.8216 24.8034C86.3762 27.9326 92.8332 33.2317 97.3761 40.0306C101.919 46.8296 104.344 54.823 104.344 63C104.332 73.9614 99.9724 84.4706 92.2215 92.2215C84.4706 99.9724 73.9615 104.332 63 104.344ZM80.3595 37.8984L52.797 49.7109C51.4038 50.3083 50.2936 51.4185 49.6962 52.8117L37.8837 80.3742C37.427 81.4581 37.3043 82.6537 37.5314 83.8077C37.7585 84.9617 38.3249 86.0217 39.1582 86.8518C39.9914 87.6819 41.0536 88.2443 42.2085 88.4669C43.3634 88.6896 44.5584 88.5624 45.6406 88.1016L73.2031 76.2891C74.5963 75.6917 75.7065 74.5815 76.3038 73.1883L88.1163 45.6258C88.573 44.5419 88.6957 43.3463 88.4686 42.1923C88.2416 41.0383 87.6751 39.9783 86.8419 39.1482C86.0086 38.3181 84.9465 37.7557 83.7916 37.5331C82.6367 37.3104 81.4416 37.4376 80.3595 37.8984ZM66.3764 66.3912L54.5639 71.4558L59.6285 59.6433L71.441 54.5787L66.3764 66.3912Z",
                    fill: "#FF3ED9",
                    style: {
                        transform: "translate(-1.35625px, 0.269592px) rotateX(-11.8628deg) rotateY(5.47819deg)",
                        transformOrigin: "center center"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/IconSeo.tsx",
                    lineNumber: 138,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/IconSeo.tsx",
            lineNumber: 126,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/IconSeo.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
};
_c = IconSeo;
var _c;
__turbopack_refresh__.register(_c, "IconSeo");

})()),
"[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "SeoBenefit": ()=>SeoBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SeoBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/SeoBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SeoBenefit$2f$IconSeo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/SeoBenefit/IconSeo.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
const SeoBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledLightBenefit"], {
        id: "icon-seo",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledBottomInfo"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SeoBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIcon"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SeoBenefit$2f$IconSeo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconSeo"], {}, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleBlock"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "SEO-Friendly."
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        " Proper Meta Tags and high performance, accumulating trust signals to your own domain."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
};
_c = SeoBenefit;
var _c;
__turbopack_refresh__.register(_c, "SeoBenefit");

})()),
"[project]/src/components/Pages/Landing/components/ConversionBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledWrapImg": ()=>StyledWrapImg
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledWrapImg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        img: {
            width: "100%",
            height: "auto",
            verticalAlign: "middle"
        }
    }));

})()),
"[project]/public/images/onboarding/conversion-benefit.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/conversion-benefit.93c6240d.png");
})()),
"[project]/public/images/onboarding/conversion-benefit.png.mjs { IMAGE => \"[project]/public/images/onboarding/conversion-benefit.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$conversion$2d$benefit$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/onboarding/conversion-benefit.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$conversion$2d$benefit$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 904,
    height: 904,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4ElEQVR42m2NPWvCQBzGb+6nae2LLXHrkEAtNK6dS7mOjWYTXz6IYg7xJhEEcyQE3MRBRHxBFBdR8JaY4A0ifw6TRRD8wbM8zw8ehG6Af38w8CWE21Vwa0dmLmfKzUjCegiX8i4iFaEoSuolmVSLhTwzjH/rIsSj53nctm3++aXTt/uEeH949K8Ex3G467o8o+s08/wq1MSTjzD+w9GlqWmaSut12iCEfqTT36VymRnZrIUWI4BBV8pWkzExnohDry9Yu8Pk7iSBHwGt5mEQS9UKsfzpzI9DasQCcYKQ74MzTgt28Rb6jd0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};

})()),
"[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "ConversionBenefit": ()=>ConversionBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ConversionBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/ConversionBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$conversion$2d$benefit$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$conversion$2d$benefit$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/onboarding/conversion-benefit.png.mjs { IMAGE => "[project]/public/images/onboarding/conversion-benefit.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
const ConversionBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFullGrayBenefit"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            container: true,
            spacing: {
                xs: "48px",
                md: "65px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    item: true,
                    xs: 12,
                    sm: 6,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ConversionBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapImg"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$conversion$2d$benefit$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$conversion$2d$benefit$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "Conversion benefit",
                            priority: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                            lineNumber: 18,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                        lineNumber: 17,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    item: true,
                    xs: 12,
                    sm: 6,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledBottomInfo"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFullBlock"], {
                                children: "Great for Conversions"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                                lineNumber: 23,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledSubTitleFullBlock"], {
                                children: "Set up any tool for analytics, lead generation, monetization you desire"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                                lineNumber: 24,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                        lineNumber: 22,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
};
_c = ConversionBenefit;
var _c;
__turbopack_refresh__.register(_c, "ConversionBenefit");

})()),
"[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledWrap": ()=>StyledWrap,
    "StyledWrapImg": ()=>StyledWrapImg
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledWrapImg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        img: {
            width: "100%",
            height: "auto",
            verticalAlign: "middle"
        }
    }));
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: "#464B58",
        borderRadius: 40,
        padding: 96,
        paddingTop: 64,
        [theme.breakpoints.down("md")]: {
            padding: 24,
            paddingTop: 32,
            paddingBottom: 0
        },
        paddingBottom: 0
    }));

})()),
"[project]/public/images/onboarding/works-offline.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/works-offline.459b49e0.png");
})()),
"[project]/public/images/onboarding/works-offline.png.mjs { IMAGE => \"[project]/public/images/onboarding/works-offline.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$works$2d$offline$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/onboarding/works-offline.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$works$2d$offline$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 860,
    height: 912,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+ACUdH0lyVF6wdFZku0IzPLtAMT67a1Bqu2ZNZrAiGyFJAGxRWazenLX/1pW2/6Bwkf+cbZb/wojB/7WFwf9WQl6sAG5RW7e7hIr/sIKY/5p6kv+lhaH/k4So/5GxrP9HRVq1AG1OYbu+e6P/vH+s/7V8qf+NZan/YVGl/2VnoP9BOVq1AG1MY73Ee7L/xn+1/8F9tv9mR6j/Sjqj/1dHrP9BOWS6AG1LYb3Feq3/yX+w/717r/9QPZ3/Qjuq/0pEuv84NGi/AGpIW7fIfKj/zIGr/8GEsf9JQ6v/LS2j/yopn/8mJVi3AGxJWLXPgKX/0oeq/8ehwv81NpT/HB2C/x4ehv8fH021uAqRdqu9xKcAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};

})()),
"[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "WorksOfflineBenefit": ()=>WorksOfflineBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$WorksOfflineBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$works$2d$offline$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$works$2d$offline$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/onboarding/works-offline.png.mjs { IMAGE => "[project]/public/images/onboarding/works-offline.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
const WorksOfflineBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$WorksOfflineBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            container: true,
            spacing: {
                xs: "48px",
                md: "65px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    item: true,
                    xs: 12,
                    sm: 6,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFullBlock"], {
                            children: "Works like an App"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledSubTitleFullBlock"], {
                            children: "Your site can be added to home screen and works offline for your readers' convenience."
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    item: true,
                    xs: 12,
                    sm: 6,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$WorksOfflineBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapImg"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$works$2d$offline$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$works$2d$offline$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "Conversion benefit",
                            priority: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
                            lineNumber: 26,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
                        lineNumber: 25,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
};
_c = WorksOfflineBenefit;
var _c;
__turbopack_refresh__.register(_c, "WorksOfflineBenefit");

})()),
"[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "IconZeroMaintenance": ()=>IconZeroMaintenance
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const IconZeroMaintenance = ()=>{
    // useEffect(() => {
    //   const handleLoad = () => {
    //     document.querySelector("svg").style.height = "auto";
    //     document.querySelector("svg").style.width = "100%";
    //
    //     var body_tree = {
    //       id: "282:137",
    //       name: "Zero",
    //       type: "FRAME",
    //       deep_level: 0,
    //       locked: false,
    //       children: [
    //         {
    //           id: "282:95",
    //           name: "0(Stroke)",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:137",
    //           svg_node_id: "0(Stroke)",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(0px, 0px) rotateX(7.35294deg) rotateY(-2.25deg)",
    //         },
    //         {
    //           id: "282:96",
    //           name: "1(Stroke)",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:137",
    //           svg_node_id: "1(Stroke)",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(0.675px, 2.20588px) rotateX(7.35294deg) rotateY(-2.25deg)",
    //         },
    //         {
    //           id: "282:97",
    //           name: "2(Stroke)",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:137",
    //           svg_node_id: "2(Stroke)",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(1.35px, 4.41176px) rotateX(7.35294deg) rotateY(-2.25deg)",
    //         },
    //         {
    //           id: "282:98",
    //           name: "0_2(Stroke)",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:137",
    //           svg_node_id: "0_2(Stroke)",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(2.025px, 6.61765px) rotateX(7.35294deg) rotateY(-2.25deg)",
    //         },
    //         {
    //           id: "282:94",
    //           name: "0_3",
    //           type: "VECTOR",
    //           deep_level: 1,
    //           locked: false,
    //           children: [],
    //           visible: true,
    //           p_id: "282:137",
    //           svg_node_id: "0_3",
    //           svg_node: {},
    //           transformOrigin: "center center",
    //           transform:
    //             "translate(2.7px, 8.82353px) rotateX(7.35294deg) rotateY(-2.25deg)",
    //         },
    //       ],
    //       visible: true,
    //       svg_node_id: "Zero",
    //       svg_node: {},
    //     };
    //
    //     function parseDigit(str) {
    //       const result = str.match(/(-?\d+(\.\d+)?)/g).map((v) => +v);
    //       return { tdeg: result[0], tox: result[1], toy: result[2] };
    //     }
    //
    //     const icon = document.getElementById("icon-zero-maintenance");
    //
    //     if (icon) {
    //       icon.addEventListener("mousemove", function (e) {
    //         MoveBackground(e, icon);
    //       });
    //
    //       icon.addEventListener("mouseleave", function (e) {
    //         body_tree.children.forEach((elemennt, index) => {
    //           const el = document.getElementById(elemennt.svg_node_id);
    //
    //           el.style.transformOrigin = elemennt.transformOrigin;
    //           el.style.transform = elemennt.transform;
    //           el.style.transition = ".3s";
    //         });
    //       });
    //     }
    //
    //     function MoveBackground(e, icon) {
    //       body_tree.children.forEach((elemennt, index) => {
    //         const el = document.getElementById(elemennt.svg_node_id);
    //         const iconReact = icon.getBoundingClientRect();
    //         if (elemennt.locked || !el) return;
    //         const ind = index;
    //         const i = ind;
    //         const offsetX =
    //           ((e.clientX - iconReact.left) / icon.offsetWidth) * 30 * i * 0.5 -
    //           15 * i * 0.5;
    //         const offsetY =
    //           ((e.clientY - iconReact.top) / icon.offsetHeight) * 30 * i * 0.5 -
    //           15 * i * 0.5;
    //         const transform = el
    //           ?.getAttribute("transform")
    //           ?.match(/rotate\(.*\)/);
    //
    //         const xOrigin = iconReact.width / 2;
    //         const yOrigin = iconReact.height / 2;
    //
    //         const yRot = ((e.clientX - xOrigin) / xOrigin) * -25;
    //         const xRot = ((e.clientY - yOrigin) / yOrigin) * 25;
    //         let { tdeg, tox, toy } = transform
    //           ? parseDigit(transform[0])
    //           : { tdeg: null, tox: null, toy: null };
    //         el.style.transformOrigin =
    //           transform && (tox || toy) ? `${tox}px, ${toy}px` : "center";
    //         el.style.transform =
    //           "translate(" +
    //           offsetX +
    //           "px," +
    //           offsetY +
    //           "px) " +
    //           (transform ? ` rotate(${tdeg}deg)` : "") +
    //           ` rotateX(${xRot}deg) rotateY(${yRot}deg)`;
    //         el.style.transition = "none";
    //       });
    //     }
    //   };
    //
    //   if (document.readyState === "complete") {
    //     handleLoad();
    //   } else {
    //     window.addEventListener("load", handleLoad);
    //
    //     return () => {
    //       window.removeEventListener("load", handleLoad);
    //     };
    //   }
    // }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 235 300",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
            height: "100%",
            width: "100%"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                id: "Zero",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        id: "0(Stroke)",
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M38.7963 210.449L38.7935 210.443C31.7003 193.399 28.1699 173.292 28.1699 150.146C28.1699 126.904 31.7001 106.748 38.7936 89.7037L38.7955 89.6991C45.9872 72.6556 56.255 59.5057 69.6169 50.3005C82.9908 40.9892 98.9678 36.3535 117.5 36.3535C135.936 36.3535 151.864 40.99 165.237 50.301C178.599 59.5062 188.866 72.6559 196.058 89.6991C203.251 106.744 206.83 126.902 206.83 150.146C206.83 173.391 203.251 193.5 196.057 210.449C188.865 227.395 178.598 240.543 165.239 249.844L165.235 249.847C151.862 259.06 135.935 263.646 117.5 263.646C98.9687 263.646 82.9923 259.06 69.6182 249.847L69.6141 249.844C56.2558 240.543 45.9885 227.395 38.7963 210.449ZM164.668 51.123C151.484 41.9434 135.762 37.3535 117.5 37.3535C99.1406 37.3535 83.3691 41.9434 70.1855 51.123C57.002 60.2051 46.8457 73.1934 39.7168 90.0879C32.6855 106.982 29.1699 127.002 29.1699 150.146C29.1699 173.193 32.6855 193.164 39.7168 210.059C46.8457 226.855 57.002 239.844 70.1855 249.023C83.3691 258.105 99.1406 262.646 117.5 262.646C135.762 262.646 151.484 258.105 164.668 249.023C177.852 239.844 188.008 226.855 195.137 210.059C202.266 193.262 205.83 173.291 205.83 150.146C205.83 127.002 202.266 106.982 195.137 90.0879C188.008 73.1934 177.852 60.2051 164.668 51.123ZM151.045 206.25C159.248 192.578 163.35 173.877 163.35 150.146C163.35 126.318 159.248 107.568 151.045 93.8965C142.842 80.2246 131.66 73.3887 117.5 73.3887C103.242 73.3887 92.0117 80.2246 83.8086 93.8965C75.7031 107.568 71.6504 126.318 71.6504 150.146C71.6504 173.877 75.7031 192.578 83.8086 206.25C92.0117 219.824 103.242 226.611 117.5 226.611C131.66 226.611 142.842 219.824 151.045 206.25ZM84.6664 205.736C92.7126 219.049 103.638 225.611 117.5 225.611C131.262 225.611 142.141 219.051 150.189 205.734C158.263 192.275 162.35 173.777 162.35 150.146C162.35 126.416 158.262 107.869 150.187 94.411C142.138 80.9949 131.259 74.3887 117.5 74.3887C103.641 74.3887 92.7152 80.997 84.6673 94.409C76.689 107.868 72.6504 126.416 72.6504 150.146C72.6504 173.777 76.6884 192.277 84.6664 205.736Z",
                        fill: "#FF3ED9",
                        style: {
                            transformOrigin: "center center",
                            transform: "translate(0px, 0px) rotateX(7.35294deg) rotateY(-2.25deg)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                        lineNumber: 177,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        id: "1(Stroke)",
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M38.7963 210.449L38.7935 210.443C31.7003 193.399 28.1699 173.292 28.1699 150.146C28.1699 126.904 31.7001 106.748 38.7936 89.7037L38.7955 89.6991C45.9872 72.6556 56.255 59.5057 69.6169 50.3005C82.9908 40.9892 98.9678 36.3535 117.5 36.3535C135.936 36.3535 151.864 40.99 165.237 50.301C178.599 59.5062 188.866 72.6559 196.058 89.6991C203.251 106.744 206.83 126.902 206.83 150.146C206.83 173.391 203.251 193.5 196.057 210.449C188.865 227.395 178.598 240.543 165.239 249.844L165.235 249.847C151.862 259.06 135.935 263.646 117.5 263.646C98.9687 263.646 82.9923 259.06 69.6182 249.847L69.6141 249.844C56.2558 240.543 45.9885 227.395 38.7963 210.449ZM164.668 51.123C151.484 41.9434 135.762 37.3535 117.5 37.3535C99.1406 37.3535 83.3691 41.9434 70.1855 51.123C57.002 60.2051 46.8457 73.1934 39.7168 90.0879C32.6855 106.982 29.1699 127.002 29.1699 150.146C29.1699 173.193 32.6855 193.164 39.7168 210.059C46.8457 226.855 57.002 239.844 70.1855 249.023C83.3691 258.105 99.1406 262.646 117.5 262.646C135.762 262.646 151.484 258.105 164.668 249.023C177.852 239.844 188.008 226.855 195.137 210.059C202.266 193.262 205.83 173.291 205.83 150.146C205.83 127.002 202.266 106.982 195.137 90.0879C188.008 73.1934 177.852 60.2051 164.668 51.123ZM151.045 206.25C159.248 192.578 163.35 173.877 163.35 150.146C163.35 126.318 159.248 107.568 151.045 93.8965C142.842 80.2246 131.66 73.3887 117.5 73.3887C103.242 73.3887 92.0117 80.2246 83.8086 93.8965C75.7031 107.568 71.6504 126.318 71.6504 150.146C71.6504 173.877 75.7031 192.578 83.8086 206.25C92.0117 219.824 103.242 226.611 117.5 226.611C131.66 226.611 142.842 219.824 151.045 206.25ZM84.6664 205.736C92.7126 219.049 103.638 225.611 117.5 225.611C131.262 225.611 142.141 219.051 150.189 205.734C158.263 192.275 162.35 173.777 162.35 150.146C162.35 126.416 158.262 107.869 150.187 94.411C142.138 80.9949 131.259 74.3887 117.5 74.3887C103.641 74.3887 92.7152 80.997 84.6673 94.409C76.689 107.868 72.6504 126.416 72.6504 150.146C72.6504 173.777 76.6884 192.277 84.6664 205.736Z",
                        fill: "#FF3ED9",
                        style: {
                            transformOrigin: "center center",
                            transform: "translate(0.675px, 2.20588px) rotateX(7.35294deg) rotateY(-2.25deg)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                        lineNumber: 189,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        id: "2(Stroke)",
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M38.7963 210.449L38.7935 210.443C31.7003 193.399 28.1699 173.292 28.1699 150.146C28.1699 126.904 31.7001 106.748 38.7936 89.7037L38.7955 89.6991C45.9872 72.6556 56.255 59.5057 69.6169 50.3005C82.9908 40.9892 98.9678 36.3535 117.5 36.3535C135.936 36.3535 151.864 40.99 165.237 50.301C178.599 59.5062 188.866 72.6559 196.058 89.6991C203.251 106.744 206.83 126.902 206.83 150.146C206.83 173.391 203.251 193.5 196.057 210.449C188.865 227.395 178.598 240.543 165.239 249.844L165.235 249.847C151.862 259.06 135.935 263.646 117.5 263.646C98.9687 263.646 82.9923 259.06 69.6182 249.847L69.6141 249.844C56.2558 240.543 45.9885 227.395 38.7963 210.449ZM164.668 51.123C151.484 41.9434 135.762 37.3535 117.5 37.3535C99.1406 37.3535 83.3691 41.9434 70.1855 51.123C57.002 60.2051 46.8457 73.1934 39.7168 90.0879C32.6855 106.982 29.1699 127.002 29.1699 150.146C29.1699 173.193 32.6855 193.164 39.7168 210.059C46.8457 226.855 57.002 239.844 70.1855 249.023C83.3691 258.105 99.1406 262.646 117.5 262.646C135.762 262.646 151.484 258.105 164.668 249.023C177.852 239.844 188.008 226.855 195.137 210.059C202.266 193.262 205.83 173.291 205.83 150.146C205.83 127.002 202.266 106.982 195.137 90.0879C188.008 73.1934 177.852 60.2051 164.668 51.123ZM151.045 206.25C159.248 192.578 163.35 173.877 163.35 150.146C163.35 126.318 159.248 107.568 151.045 93.8965C142.842 80.2246 131.66 73.3887 117.5 73.3887C103.242 73.3887 92.0117 80.2246 83.8086 93.8965C75.7031 107.568 71.6504 126.318 71.6504 150.146C71.6504 173.877 75.7031 192.578 83.8086 206.25C92.0117 219.824 103.242 226.611 117.5 226.611C131.66 226.611 142.842 219.824 151.045 206.25ZM84.6664 205.736C92.7126 219.049 103.638 225.611 117.5 225.611C131.262 225.611 142.141 219.051 150.189 205.734C158.263 192.275 162.35 173.777 162.35 150.146C162.35 126.416 158.262 107.869 150.187 94.411C142.138 80.9949 131.259 74.3887 117.5 74.3887C103.641 74.3887 92.7152 80.997 84.6673 94.409C76.689 107.868 72.6504 126.416 72.6504 150.146C72.6504 173.777 76.6884 192.277 84.6664 205.736Z",
                        fill: "#FF3ED9",
                        style: {
                            transformOrigin: "center center",
                            transform: "translate(1.35px, 4.41176px) rotateX(7.35294deg) rotateY(-2.25deg)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        id: "0_2(Stroke)",
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M38.7963 210.449L38.7935 210.443C31.7003 193.399 28.1699 173.292 28.1699 150.146C28.1699 126.904 31.7001 106.748 38.7936 89.7037L38.7955 89.6991C45.9872 72.6556 56.255 59.5057 69.6169 50.3005C82.9908 40.9892 98.9678 36.3535 117.5 36.3535C135.936 36.3535 151.864 40.99 165.237 50.301C178.599 59.5062 188.866 72.6559 196.058 89.6991C203.251 106.744 206.83 126.902 206.83 150.146C206.83 173.391 203.251 193.5 196.057 210.449C188.865 227.395 178.598 240.543 165.239 249.844L165.235 249.847C151.862 259.06 135.935 263.646 117.5 263.646C98.9687 263.646 82.9923 259.06 69.6182 249.847L69.6141 249.844C56.2558 240.543 45.9885 227.395 38.7963 210.449ZM164.668 51.123C151.484 41.9434 135.762 37.3535 117.5 37.3535C99.1406 37.3535 83.3691 41.9434 70.1855 51.123C57.002 60.2051 46.8457 73.1934 39.7168 90.0879C32.6855 106.982 29.1699 127.002 29.1699 150.146C29.1699 173.193 32.6855 193.164 39.7168 210.059C46.8457 226.855 57.002 239.844 70.1855 249.023C83.3691 258.105 99.1406 262.646 117.5 262.646C135.762 262.646 151.484 258.105 164.668 249.023C177.852 239.844 188.008 226.855 195.137 210.059C202.266 193.262 205.83 173.291 205.83 150.146C205.83 127.002 202.266 106.982 195.137 90.0879C188.008 73.1934 177.852 60.2051 164.668 51.123ZM151.045 206.25C159.248 192.578 163.35 173.877 163.35 150.146C163.35 126.318 159.248 107.568 151.045 93.8965C142.842 80.2246 131.66 73.3887 117.5 73.3887C103.242 73.3887 92.0117 80.2246 83.8086 93.8965C75.7031 107.568 71.6504 126.318 71.6504 150.146C71.6504 173.877 75.7031 192.578 83.8086 206.25C92.0117 219.824 103.242 226.611 117.5 226.611C131.66 226.611 142.842 219.824 151.045 206.25ZM84.6664 205.736C92.7126 219.049 103.638 225.611 117.5 225.611C131.262 225.611 142.141 219.051 150.189 205.734C158.263 192.275 162.35 173.777 162.35 150.146C162.35 126.416 158.262 107.869 150.187 94.411C142.138 80.9949 131.259 74.3887 117.5 74.3887C103.641 74.3887 92.7152 80.997 84.6673 94.409C76.689 107.868 72.6504 126.416 72.6504 150.146C72.6504 173.777 76.6884 192.277 84.6664 205.736Z",
                        fill: "#FF3ED9",
                        style: {
                            transformOrigin: "center center",
                            transform: "translate(2.025px, 6.61765px) rotateX(7.35294deg) rotateY(-2.25deg)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        id: "0_3",
                        d: "M117.5 262.646C99.1406 262.646 83.3691 258.105 70.1855 249.023C57.002 239.844 46.8457 226.855 39.7168 210.059C32.6855 193.164 29.1699 173.193 29.1699 150.146C29.1699 127.002 32.6855 106.982 39.7168 90.0879C46.8457 73.1934 57.002 60.2051 70.1855 51.123C83.3691 41.9434 99.1406 37.3535 117.5 37.3535C135.762 37.3535 151.484 41.9434 164.668 51.123C177.852 60.2051 188.008 73.1934 195.137 90.0879C202.266 106.982 205.83 127.002 205.83 150.146C205.83 173.291 202.266 193.262 195.137 210.059C188.008 226.855 177.852 239.844 164.668 249.023C151.484 258.105 135.762 262.646 117.5 262.646ZM117.5 226.611C131.66 226.611 142.842 219.824 151.045 206.25C159.248 192.578 163.35 173.877 163.35 150.146C163.35 126.318 159.248 107.568 151.045 93.8965C142.842 80.2246 131.66 73.3887 117.5 73.3887C103.242 73.3887 92.0117 80.2246 83.8086 93.8965C75.7031 107.568 71.6504 126.318 71.6504 150.146C71.6504 173.877 75.7031 192.578 83.8086 206.25C92.0117 219.824 103.242 226.611 117.5 226.611Z",
                        fill: "url(#paint0_linear_282_137)",
                        style: {
                            transformOrigin: "center center",
                            transform: "translate(2.7px, 8.82353px) rotateX(7.35294deg) rotateY(-2.25deg)"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                lineNumber: 176,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_282_137",
                    x1: "215.941",
                    y1: "150.131",
                    x2: "19.9414",
                    y2: "150.131",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#FF3ED9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#FF3ED9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                            lineNumber: 246,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                    lineNumber: 237,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
                lineNumber: 236,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx",
        lineNumber: 170,
        columnNumber: 5
    }, this);
};
_c = IconZeroMaintenance;
var _c;
__turbopack_refresh__.register(_c, "IconZeroMaintenance");

})()),
"[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledIcon": ()=>StyledIcon
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        height: "auto",
        width: 235,
        margin: "auto",
        marginTop: 98,
        [theme.breakpoints.down("md")]: {
            marginTop: 16,
            width: 131
        }
    }));

})()),
"[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "ZeroMaintenanceBenefit": ()=>ZeroMaintenanceBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ZeroMaintenanceBenefit$2f$IconZeroMaintenance$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/IconZeroMaintenance.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ZeroMaintenanceBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/styled.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
const ZeroMaintenanceBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledLightBenefit"], {
        id: "icon-zero-maintenance",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleBlock"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Zero Maintenance."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx",
                        lineNumber: 12,
                        columnNumber: 9
                    }, this),
                    " No database to backup, no security issues to fix, no performance upgrades, it just works."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ZeroMaintenanceBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIcon"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ZeroMaintenanceBenefit$2f$IconZeroMaintenance$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconZeroMaintenance"], {}, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_c = ZeroMaintenanceBenefit;
var _c;
__turbopack_refresh__.register(_c, "ZeroMaintenanceBenefit");

})()),
"[project]/src/components/Pages/Landing/components/CustomDomain/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledGroupDomain": ()=>StyledGroupDomain,
    "StyledImgDomain": ()=>StyledImgDomain,
    "StyledTextDomain": ()=>StyledTextDomain,
    "StyledTextDomainDark": ()=>StyledTextDomainDark,
    "StyledWrapDomain": ()=>StyledWrapDomain,
    "StyledWrapDomainDark": ()=>StyledWrapDomainDark
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const StyledWrapDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        maxWidth: "100%",
        display: "flex",
        alignItems: "center",
        gap: 16,
        borderRadius: "50px",
        padding: "12px 16px",
        background: theme.palette.decorate.main,
        color: "#fff"
    }));
const StyledGroupDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        maxWidth: 305,
        width: "100%",
        margin: "auto",
        display: "flex",
        flexDirection: "column",
        gap: 24,
        marginTop: 143,
        paddingBottom: 87,
        [theme.breakpoints.down("md")]: {
            marginTop: 48,
            paddingBottom: 0
        }
    }));
const StyledWrapDomainDark = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        maxWidth: "100%",
        display: "flex",
        alignItems: "center",
        gap: 16,
        borderRadius: "50px",
        padding: "12px 16px",
        background: "#E7E9F0",
        color: "#696F7D"
    }));
const StyledImgDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        width: "100%",
        maxWidth: 64,
        height: 64,
        flex: "0 0 64px",
        overflow: "hidden",
        borderRadius: "50%",
        img: {
            width: "inherit",
            height: "inherit",
            verticalAlign: "middle"
        }
    }));
const StyledTextDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 26,
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: 700,
        color: "#fff",
        [theme.breakpoints.down("sm")]: {
            fontSize: 18
        }
    }));
const StyledTextDomainDark = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 26,
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: 700,
        color: "#696F7D",
        [theme.breakpoints.down("sm")]: {
            fontSize: 18
        }
    }));

})()),
"[project]/public/images/onboarding/user.jpg [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/user.e0ab6e25.jpg");
})()),
"[project]/public/images/onboarding/user.jpg.mjs { IMAGE => \"[project]/public/images/onboarding/user.jpg [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/onboarding/user.jpg [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 128,
    height: 128,
    blurDataURL: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/wAARCAAIAAgDAREAAhEBAxEB/9sAQwAKBwcIBwYKCAgICwoKCw4YEA4NDQ4dFRYRGCMfJSQiHyIhJis3LyYpNCkhIjBBMTQ5Oz4+PiUuRElDPEg3PT47/9sAQwEKCwsODQ4cEBAcOygiKDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDNu1lHia1mFwyQxgcK3B9QRXpU0pVmmx4xyoQjUjt1P//Z",
    blurWidth: 8,
    blurHeight: 8
};

})()),
"[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "CustomDomain": ()=>CustomDomain
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/CustomDomain/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/onboarding/user.jpg.mjs { IMAGE => "[project]/public/images/onboarding/user.jpg [app-client] (static)" } [app-client] (structured image object, ecmascript)');
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
const CustomDomain = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledLightBenefit"], {
        id: "icon-zero-maintenance",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleBlock"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Custom Domain."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                        lineNumber: 20,
                        columnNumber: 9
                    }, this),
                    " Start with a free npub.pro subdomain, and upgrade to use your own any time."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGroupDomain"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapDomain"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledImgDomain"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                    alt: "User avatar",
                                    priority: true
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                                lineNumber: 26,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTextDomain"], {
                                children: "janewrites.com"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapDomainDark"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledImgDomain"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$user$2e$jpg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                    alt: "User avatar",
                                    priority: true
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                                    lineNumber: 34,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                                lineNumber: 33,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTextDomainDark"], {
                                children: "jane.npub.pro"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
_c = CustomDomain;
var _c;
__turbopack_refresh__.register(_c, "CustomDomain");

})()),
"[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "OpenSourceBenefit": ()=>OpenSourceBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const OpenSourceBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFullLightGrayBenefit"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFullBlock"], {
                        children: "Open-source and self-hostable."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledSubTitleFullBlock"], {
                        children: "Use our high-performance infrastructure to power your site or host yourself — all data is on your Nostr relays."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledOpenSourceEmblemWrap"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledOpenSourceEmblem"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledOpenSourceSubTitle"], {
                            children: "open source initiative approved license ®"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledOpenSourceTitle"], {
                            children: "MIT"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
};
_c = OpenSourceBenefit;
var _c;
__turbopack_refresh__.register(_c, "OpenSourceBenefit");

})()),
"[project]/src/components/Pages/Landing/components/PopularAppsBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledWrapImg": ()=>StyledWrapImg
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledWrapImg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        img: {
            width: "100%",
            height: "auto",
            verticalAlign: "middle"
        }
    }));

})()),
"[project]/public/images/onboarding/popular-apps.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/popular-apps.4e5d8304.png");
})()),
"[project]/public/images/onboarding/popular-apps.png.mjs { IMAGE => \"[project]/public/images/onboarding/popular-apps.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$popular$2d$apps$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/onboarding/popular-apps.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$popular$2d$apps$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 904,
    height: 936,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AAAAAAAAAAAAOjo6Ot3P3u7czdzuR0lRoyovS/wmJT/xAAAAAAAAAAAAQUFBQd3M3fLk2eXyTlFatDQ1Yf0sKk/5ADMzMzM7Ozs7KCUqK3xmgo+FYYSPIBoiTBoZIp0WFR2KANPT0+vNzc3xgHaUpYNvxOavUsbmTSBCpUs3LPE6MivrANLS0uvFxcXxdniapWNvz+aEUrrmQSI+pVk6K/FFNSvrADMzM4pCQkKdJygtTGRpiY9sZYOPOjc7TGFgZZ1eXl+JACMjI/lsbGz9Sk5QtKTK6/LV3u7yqKattLC11P3K2ej5ACsrK/E0NDT8OTs8o6254u7GweDunp2ho9nd6vzQ3Obx9E98wd4lZQEAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};

})()),
"[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "PopularAppsBenefit": ()=>PopularAppsBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/shared/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$PopularAppsBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/PopularAppsBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$popular$2d$apps$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$popular$2d$apps$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/onboarding/popular-apps.png.mjs { IMAGE => "[project]/public/images/onboarding/popular-apps.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
const PopularAppsBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFullGrayBenefit"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            container: true,
            spacing: {
                xs: "48px",
                md: "65px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    item: true,
                    xs: 12,
                    sm: 6,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledBottomInfo"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFullBlock"], {
                                children: "Use with many popular apps"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                                lineNumber: 18,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$shared$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledSubTitleFullBlock"], {
                                children: "Your content is automatically compatible with hundreds of apps and their audiences."
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                                lineNumber: 21,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                        lineNumber: 17,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    item: true,
                    xs: 12,
                    sm: 6,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$PopularAppsBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapImg"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$onboarding$2f$popular$2d$apps$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$onboarding$2f$popular$2d$apps$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "Popular Apps",
                            priority: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                            lineNumber: 29,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
};
_c = PopularAppsBenefit;
var _c;
__turbopack_refresh__.register(_c, "PopularAppsBenefit");

})()),
"[project]/src/components/Pages/Landing/components/NativelySocialBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledGroupIcon": ()=>StyledGroupIcon,
    "StyledTitle": ()=>StyledTitle,
    "StyledWrap": ()=>StyledWrap,
    "StyledWrapIcon": ()=>StyledWrapIcon,
    "StyledWrapIconDefault": ()=>StyledWrapIconDefault
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: "#fff",
        borderRadius: 40,
        padding: "120px 96px",
        [theme.breakpoints.down("md")]: {
            padding: "40px 24px"
        }
    }));
const StyledGroupIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        display: "flex",
        justifyContent: "center",
        gap: 64,
        marginBottom: 64,
        [theme.breakpoints.down("lg")]: {
            gap: 44
        },
        [theme.breakpoints.down("md")]: {
            gap: 16,
            marginBottom: 48
        }
    }));
const StyledWrapIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        borderRadius: "50%",
        background: theme.palette.decorate.main,
        [theme.breakpoints.up("xs")]: {
            height: 56,
            width: 56,
            flex: "0 0 56px",
            padding: 15
        },
        [theme.breakpoints.up("sm")]: {
            height: 96,
            width: 96,
            flex: "0 0 96px",
            padding: 22
        },
        [theme.breakpoints.up("md")]: {
            height: 240,
            width: 240,
            flex: "0 0 240px",
            padding: 57
        }
    }));
const StyledWrapIconDefault = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        borderRadius: "50%",
        background: "#606677",
        [theme.breakpoints.up("xs")]: {
            height: 56,
            width: 56,
            flex: "0 0 56px",
            padding: 15
        },
        [theme.breakpoints.up("sm")]: {
            height: 96,
            width: 96,
            flex: "0 0 96px",
            padding: 22
        },
        [theme.breakpoints.up("md")]: {
            height: 240,
            width: 240,
            flex: "0 0 240px",
            padding: 57
        }
    }));
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: "700",
        fontSize: 48,
        maxWidth: 908,
        margin: "auto",
        textAlign: "center",
        lineHeight: "59px",
        color: theme.palette.secondary.main,
        span: {
            color: theme.palette.decorate.main
        },
        [theme.breakpoints.down("md")]: {
            fontSize: 24,
            lineHeight: "39px"
        }
    }));

})()),
"[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconMesssage.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "IconMessage": ()=>IconMessage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const IconMessage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "126",
        height: "126",
        viewBox: "0 0 126 126",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
            height: "100%",
            width: "100%"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
            id: "Frame",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector",
                    d: "M110.25 23.625H15.75C14.7057 23.625 13.7042 24.0398 12.9658 24.7783C12.2273 25.5167 11.8125 26.5182 11.8125 27.5625V94.5C11.8125 96.5886 12.6422 98.5916 14.119 100.068C15.5959 101.545 17.5989 102.375 19.6875 102.375H106.312C108.401 102.375 110.404 101.545 111.881 100.068C113.358 98.5916 114.188 96.5886 114.188 94.5V27.5625C114.188 26.5182 113.773 25.5167 113.034 24.7783C112.296 24.0398 111.294 23.625 110.25 23.625ZM48.5838 63L19.6875 89.4846V36.5154L48.5838 63ZM54.4113 68.3402L60.3176 73.7789C61.044 74.4458 61.9942 74.8158 62.9803 74.8158C63.9664 74.8158 64.9166 74.4458 65.643 73.7789L71.5493 68.3402L100.096 94.5H25.8743L54.4113 68.3402ZM77.4162 63L106.312 36.5105V89.4895L77.4162 63Z",
                    fill: "white",
                    fillOpacity: "0.5"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconMesssage.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector_2",
                    d: "M110.25 23.625H15.75C14.7057 23.625 13.7042 24.0398 12.9658 24.7783C12.2273 25.5167 11.8125 26.5182 11.8125 27.5625V94.5C11.8125 96.5886 12.6422 98.5916 14.119 100.068C15.5959 101.545 17.5989 102.375 19.6875 102.375H106.312C108.401 102.375 110.404 101.545 111.881 100.068C113.358 98.5916 114.188 96.5886 114.188 94.5V27.5625C114.188 26.5182 113.773 25.5167 113.034 24.7783C112.296 24.0398 111.294 23.625 110.25 23.625ZM48.5838 63L19.6875 89.4846V36.5154L48.5838 63ZM54.4113 68.3402L60.3176 73.7789C61.044 74.4458 61.9942 74.8158 62.9803 74.8158C63.9664 74.8158 64.9166 74.4458 65.643 73.7789L71.5493 68.3402L100.096 94.5H25.8743L54.4113 68.3402ZM77.4162 63L106.312 36.5105V89.4895L77.4162 63Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconMesssage.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconMesssage.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconMesssage.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
};
_c = IconMessage;
var _c;
__turbopack_refresh__.register(_c, "IconMessage");

})()),
"[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconChats.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "IconChats": ()=>IconChats
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const IconChats = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "126",
        height: "126",
        viewBox: "0 0 126 126",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
            height: "100%",
            width: "100%"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
            id: "chats",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector",
                    d: "M63.2188 14C50.1695 14.0143 37.6589 19.2045 28.4317 28.4317C19.2045 37.6589 14.0143 50.1695 14 63.2188V104.562C14 106.651 14.8297 108.654 16.3065 110.131C17.7834 111.608 19.7864 112.438 21.875 112.438H63.2188C76.2724 112.438 88.7914 107.252 98.0217 98.0217C107.252 88.7914 112.438 76.2724 112.438 63.2188C112.438 50.1651 107.252 37.6461 98.0217 28.4158C88.7914 19.1855 76.2724 14 63.2188 14ZM41.5625 71.0938C40.3944 71.0938 39.2524 70.7474 38.2812 70.0984C37.3099 69.4494 36.5529 68.5269 36.1058 67.4477C35.6588 66.3685 35.5418 65.1809 35.7697 64.0352C35.9976 62.8895 36.5601 61.8372 37.3862 61.0112C38.2122 60.1851 39.2645 59.6226 40.4102 59.3947C41.5559 59.1668 42.7435 59.2838 43.8227 59.7308C44.9019 60.1779 45.8244 60.9349 46.4734 61.9062C47.1224 62.8774 47.4688 64.0194 47.4688 65.1875C47.4687 66.7539 46.8465 68.2562 45.7388 69.3638C44.6312 70.4715 43.1289 71.0938 41.5625 71.0938ZM63.2188 71.0938C62.0506 71.0938 60.9087 70.7474 59.9374 70.0984C58.9661 69.4494 58.2091 68.5269 57.7621 67.4477C57.3151 66.3685 57.1981 65.1809 57.426 64.0352C57.6539 62.8895 58.2164 61.8372 59.0424 61.0112C59.8684 60.1851 60.9208 59.6226 62.0665 59.3947C63.2122 59.1668 64.3997 59.2838 65.479 59.7308C66.5582 60.1779 67.4806 60.9349 68.1296 61.9062C68.7786 62.8774 69.125 64.0194 69.125 65.1875C69.125 66.7539 68.5027 68.2562 67.3951 69.3638C66.2875 70.4715 64.7852 71.0938 63.2188 71.0938ZM84.875 71.0938C83.7069 71.0938 82.5649 70.7474 81.5937 70.0984C80.6224 69.4494 79.8654 68.5269 79.4183 67.4477C78.9713 66.3685 78.8543 65.1809 79.0822 64.0352C79.3101 62.8895 79.8727 61.8372 80.6987 61.0112C81.5247 60.1851 82.577 59.6226 83.7227 59.3947C84.8684 59.1668 86.056 59.2838 87.1352 59.7308C88.2144 60.1779 89.1369 60.9349 89.7859 61.9062C90.4349 62.8774 90.7812 64.0194 90.7812 65.1875C90.7812 66.7539 90.159 68.2562 89.0513 69.3638C87.9437 70.4715 86.4414 71.0938 84.875 71.0938Z",
                    fill: "white",
                    fillOpacity: "0.5"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconChats.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector_2",
                    d: "M63.2188 14C50.1695 14.0143 37.6589 19.2045 28.4317 28.4317C19.2045 37.6589 14.0143 50.1695 14 63.2188V104.562C14 106.651 14.8297 108.654 16.3065 110.131C17.7834 111.608 19.7864 112.438 21.875 112.438H63.2188C76.2724 112.438 88.7914 107.252 98.0217 98.0217C107.252 88.7914 112.438 76.2724 112.438 63.2188C112.438 50.1651 107.252 37.6461 98.0217 28.4158C88.7914 19.1855 76.2724 14 63.2188 14ZM41.5625 71.0938C40.3944 71.0938 39.2524 70.7474 38.2812 70.0984C37.3099 69.4494 36.5529 68.5269 36.1058 67.4477C35.6588 66.3685 35.5418 65.1809 35.7697 64.0352C35.9976 62.8895 36.5601 61.8372 37.3862 61.0112C38.2122 60.1851 39.2645 59.6226 40.4102 59.3947C41.5559 59.1668 42.7435 59.2838 43.8227 59.7308C44.9019 60.1779 45.8244 60.9349 46.4734 61.9062C47.1224 62.8774 47.4688 64.0194 47.4688 65.1875C47.4688 66.7539 46.8465 68.2562 45.7388 69.3638C44.6312 70.4715 43.1289 71.0938 41.5625 71.0938ZM63.2188 71.0938C62.0506 71.0938 60.9087 70.7474 59.9374 70.0984C58.9661 69.4494 58.2091 68.5269 57.7621 67.4477C57.3151 66.3685 57.1981 65.1809 57.426 64.0352C57.6539 62.8895 58.2164 61.8372 59.0424 61.0112C59.8684 60.1851 60.9208 59.6226 62.0665 59.3947C63.2122 59.1668 64.3997 59.2838 65.479 59.7308C66.5582 60.1779 67.4806 60.9349 68.1296 61.9062C68.7786 62.8774 69.125 64.0194 69.125 65.1875C69.125 66.7539 68.5027 68.2562 67.3951 69.3638C66.2875 70.4715 64.7852 71.0938 63.2188 71.0938ZM84.875 71.0938C83.7069 71.0938 82.5649 70.7474 81.5937 70.0984C80.6224 69.4494 79.8654 68.5269 79.4183 67.4477C78.9713 66.3685 78.8543 65.1809 79.0822 64.0352C79.3101 62.8895 79.8727 61.8372 80.6987 61.0112C81.5247 60.1851 82.577 59.6226 83.7227 59.3947C84.8684 59.1668 86.056 59.2838 87.1352 59.7308C88.2144 60.1779 89.1369 60.9349 89.7859 61.9062C90.4349 62.8774 90.7812 64.0194 90.7812 65.1875C90.7812 66.7539 90.159 68.2562 89.0513 69.3638C87.9437 70.4715 86.4414 71.0938 84.875 71.0938Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconChats.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconChats.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconChats.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
};
_c = IconChats;
var _c;
__turbopack_refresh__.register(_c, "IconChats");

})()),
"[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "IconPay": ()=>IconPay
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const IconPay = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "126",
        height: "126",
        viewBox: "0 0 126 126",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
            height: "100%",
            width: "100%"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
            id: "Frame",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector_2",
                    d: "M106.312 31.5H27.5625C26.5182 31.5 25.5167 31.0852 24.7783 30.3467C24.0398 29.6083 23.625 28.6068 23.625 27.5625C23.625 26.5182 24.0398 25.5167 24.7783 24.7783C25.5167 24.0398 26.5182 23.625 27.5625 23.625H94.5C95.5443 23.625 96.5458 23.2102 97.2842 22.4717C98.0227 21.7333 98.4375 20.7318 98.4375 19.6875C98.4375 18.6432 98.0227 17.6417 97.2842 16.9033C96.5458 16.1648 95.5443 15.75 94.5 15.75H27.5625C24.4296 15.75 21.4251 16.9945 19.2098 19.2098C16.9945 21.4251 15.75 24.4296 15.75 27.5625V90.5625C15.75 93.6954 16.9945 96.6999 19.2098 98.9152C21.4251 101.13 24.4296 102.375 27.5625 102.375H106.312C108.401 102.375 110.404 101.545 111.881 100.068C113.358 98.5916 114.188 96.5886 114.188 94.5V39.375C114.188 37.2864 113.358 35.2834 111.881 33.8065C110.404 32.3297 108.401 31.5 106.312 31.5ZM88.5938 70.875C87.4256 70.875 86.2837 70.5286 85.3124 69.8796C84.3411 69.2306 83.5841 68.3082 83.1371 67.229C82.6901 66.1497 82.5731 64.9622 82.801 63.8165C83.0289 62.6708 83.5914 61.6184 84.4174 60.7924C85.2434 59.9664 86.2958 59.4039 87.4415 59.176C88.5872 58.9481 89.7747 59.0651 90.854 59.5121C91.9332 59.9591 92.8556 60.7161 93.5046 61.6874C94.1536 62.6587 94.5 63.8006 94.5 64.9688C94.5 66.5352 93.8777 68.0375 92.7701 69.1451C91.6625 70.2527 90.1602 70.875 88.5938 70.875Z",
                    fill: "white",
                    fillOpacity: "0.5",
                    strokeDasharray: "0,0,380.96237790766264,152.2383667212436",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("animate", {
                        attributeType: "XML",
                        attributeName: "stroke-dasharray",
                        repeatCount: "indefinite",
                        dur: "1.2732335016565952s",
                        values: "0,0,380.96237790766264,152.2383667212436; 0,152.2383667212436,380.96237790766264,0; 380.96237790766264,152.2383667212436,0,0",
                        keyTimes: "0; 0.285517918447765; 1",
                        begin: "0.5632203885578269s"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx",
                        lineNumber: 20,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    id: "Vector",
                    d: "M106.312 31.5H27.5625C26.5182 31.5 25.5167 31.0852 24.7783 30.3467C24.0398 29.6083 23.625 28.6068 23.625 27.5625C23.625 26.5182 24.0398 25.5167 24.7783 24.7783C25.5167 24.0398 26.5182 23.625 27.5625 23.625H94.5C95.5443 23.625 96.5458 23.2102 97.2842 22.4717C98.0227 21.7333 98.4375 20.7318 98.4375 19.6875C98.4375 18.6432 98.0227 17.6417 97.2842 16.9033C96.5458 16.1648 95.5443 15.75 94.5 15.75H27.5625C24.4296 15.75 21.4251 16.9945 19.2098 19.2098C16.9945 21.4251 15.75 24.4296 15.75 27.5625V90.5625C15.75 93.6954 16.9945 96.6999 19.2098 98.9152C21.4251 101.13 24.4296 102.375 27.5625 102.375H106.312C108.401 102.375 110.404 101.545 111.881 100.068C113.358 98.5916 114.188 96.5886 114.188 94.5V39.375C114.188 37.2864 113.358 35.2834 111.881 33.8065C110.404 32.3297 108.401 31.5 106.312 31.5ZM88.5938 70.875C87.4256 70.875 86.2837 70.5286 85.3124 69.8796C84.3411 69.2306 83.5841 68.3082 83.1371 67.229C82.6901 66.1497 82.5731 64.9622 82.801 63.8165C83.0289 62.6708 83.5914 61.6184 84.4174 60.7924C85.2434 59.9664 86.2958 59.4039 87.4415 59.176C88.5872 58.9481 89.7747 59.0651 90.854 59.5121C91.9332 59.9591 92.8556 60.7161 93.5046 61.6874C94.1536 62.6587 94.5 63.8006 94.5 64.9688C94.5 66.5352 93.8777 68.0375 92.7701 69.1451C91.6625 70.2527 90.1602 70.875 88.5938 70.875Z",
                    fill: "white",
                    strokeDasharray: "0,0,382.39482986370916,150.80591476519712",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("animate", {
                        attributeType: "XML",
                        attributeName: "stroke-dasharray",
                        repeatCount: "indefinite",
                        dur: "1.18947141472479s",
                        values: "0,0,382.39482986370916,150.80591476519712; 0,150.80591476519712,382.39482986370916,0; 382.39482986370916,150.80591476519712,0,0",
                        keyTimes: "0; 0.28283140315221067; 1",
                        begin: "0.3429130998958814s"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx",
                        lineNumber: 39,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
};
_c = IconPay;
var _c;
__turbopack_refresh__.register(_c, "IconPay");

})()),
"[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "NativelySocialBenefit": ()=>NativelySocialBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/NativelySocialBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$IconMesssage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconMesssage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$IconChats$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconChats.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$IconPay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/NativelySocialBenefit/IconPay.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
const NativelySocialBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGroupIcon"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapIcon"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$IconChats$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconChats"], {}, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                            lineNumber: 17,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapIconDefault"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$IconMesssage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconMessage"], {}, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                            lineNumber: 20,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrapIcon"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$IconPay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconPay"], {}, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Natively Social."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    " Your site is part of a global open social network with powerful tools like chats, direct messages, digital payments and more..."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
};
_c = NativelySocialBenefit;
var _c;
__turbopack_refresh__.register(_c, "NativelySocialBenefit");

})()),
"[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledGroupImg": ()=>StyledGroupImg,
    "StyledTitle": ()=>StyledTitle,
    "StyledWrap": ()=>StyledWrap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        background: "#464B58",
        borderRadius: 40,
        paddingTop: 120,
        paddingBottom: 120,
        overflow: "hidden",
        [theme.breakpoints.down("md")]: {
            padding: 24,
            paddingTop: 32,
            paddingBottom: 32
        }
    }));
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        fontWeight: "700",
        fontSize: 48,
        color: "#C1C5CD",
        margin: "auto",
        marginBottom: 64,
        lineHeight: "59px",
        textAlign: "center",
        maxWidth: 908,
        [theme.breakpoints.down("md")]: {
            marginBottom: 48,
            fontSize: 32,
            lineHeight: "39px"
        },
        ".light-text": {
            color: "#fff"
        },
        ".decorate-text": {
            color: theme.palette.decorate.main
        }
    }));
const StyledGroupImg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        display: "flex",
        gap: 30,
        flexWrap: "nowrap",
        width: "100%",
        justifyContent: "center",
        img: {
            height: "auto",
            width: 428,
            verticalAlign: "middle",
            flex: "0 0 428px",
            borderRadius: 16,
            boxShadow: "0px 28px 40.1px 0px #00000026"
        },
        [theme.breakpoints.down("md")]: {
            img: {
                width: 214,
                flex: "0 0 214px"
            }
        }
    }));

})()),
"[project]/public/images/preview-theme/2.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/2.087f6d08.png");
})()),
"[project]/public/images/preview-theme/2.png.mjs { IMAGE => \"[project]/public/images/preview-theme/2.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$2$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/preview-theme/2.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$2$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 856,
    height: 560,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAlklEQVR42i3F3QrBYACA4e9yRIopJj/fDLOYYTRbNkxpRDhRHKwcKMpFv5YcPD1CkxJNNtHT25qkp+tYRgen38MfDRCB1SX8i2yDnWNymVvcwzGPaIrYtEqspIKr5pipefx6gbhT5mhWf8S2luVsqpyMMnG3wqJRxK0VcOsKQyWDuHkD3vuAV+pzWPJcT0g8k8Tvc7U1vhs0TQq1SpjNAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 5
};

})()),
"[project]/public/images/preview-theme/5.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/5.9e9f0df1.png");
})()),
"[project]/public/images/preview-theme/5.png.mjs { IMAGE => \"[project]/public/images/preview-theme/5.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$5$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/preview-theme/5.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$5$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 856,
    height: 560,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAfUlEQVR42lWNTQrCMBhEe/+jCB5ApFIUEcFSq6VpyM+XmFVyiWeblW5mYOYx05RS8PJh0cKyaIyxWOtIKbF1zSbj29F2E6eLZ1aCiPwDj17Rncfqs9Lrgq1QBXLOHNuB3f7OoVU8XxrnHDHGn4s1vN4m+sFjbCCEgISI9YUv7sKOM4thGhIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};

})()),
"[project]/public/images/preview-theme/8.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/8.90fdf166.png");
})()),
"[project]/public/images/preview-theme/8.png.mjs { IMAGE => \"[project]/public/images/preview-theme/8.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$8$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/preview-theme/8.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$8$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 856,
    height: 560,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAApElEQVR42g3MTQvBcADA4f9X4cDBYaIdKC8HIg5ykIRQ3oeMeY0oliRTwpC2j/qz+9MjtvoJ/Wrw+Hz5Wjbm60U6GqEc8HGdTxG96QJ1s+P2NLFti9tSo59NoUhe1HgIUa3X6CoK++MB823ye94xVjOaskTO40KMlSZrbchZdxbjwmEypJVJEPZLeN1uRCYZo5RP0ShmGTQKqJ0K2qiNLAcJOOgP9YhYxpMxgBQAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};

})()),
"[project]/public/images/preview-theme/11.png [app-client] (static)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/11.04925a83.png");
})()),
"[project]/public/images/preview-theme/11.png.mjs { IMAGE => \"[project]/public/images/preview-theme/11.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$11$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/public/images/preview-theme/11.png [app-client] (static)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$11$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 856,
    height: 560,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAiklEQVR42jXF0QqCMABA0f3/F/XQQxApqZkZZaVOl+Q2hKRF4oNwC6ELhyu01rStRhuD1gZrLc45pmmaL5RS5HkxK8oSKSVd1/FPaGMpK4Ws7zSPlmffM44jn2Hg5d6I9JSx8UO8bYQXRGTXnKKquZWSSjWI4/lCuE9/DiyWK9Z+QBAn+EHMLkn5ApEJkMmcKFMkAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 5
};

})()),
"[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "BeautifulThemesBenefit": ()=>BeautifulThemesBenefit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$BeautifulThemesBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$2$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$2$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/preview-theme/2.png.mjs { IMAGE => "[project]/public/images/preview-theme/2.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$5$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$5$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/preview-theme/5.png.mjs { IMAGE => "[project]/public/images/preview-theme/5.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$8$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$8$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/preview-theme/8.png.mjs { IMAGE => "[project]/public/images/preview-theme/8.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$11$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$11$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/public/images/preview-theme/11.png.mjs { IMAGE => "[project]/public/images/preview-theme/11.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
const BeautifulThemesBenefit = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$BeautifulThemesBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$BeautifulThemesBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "light-text",
                        children: "Beautiful Themes."
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this),
                    " Choose from hundreds of",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "decorate-text",
                        children: "open source Ghost themes"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                        lineNumber: 18,
                        columnNumber: 9
                    }, this),
                    " that are easy to customize to your needs."
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$BeautifulThemesBenefit$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGroupImg"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$2$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$2$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "Theme 1",
                        priority: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$5$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$5$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "Theme 2",
                        priority: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$8$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$8$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "Theme 3",
                        priority: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$11$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$public$2f$images$2f$preview$2d$theme$2f$11$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "Theme 4",
                        priority: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
};
_c = BeautifulThemesBenefit;
var _c;
__turbopack_refresh__.register(_c, "BeautifulThemesBenefit");

})()),
"[project]/src/components/Pages/Landing/components/Benefits/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Benefits": ()=>Benefits
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Benefits/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript) <export default as Grid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/SocialBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SeoBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/SeoBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ConversionBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/ConversionBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$WorksOfflineBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/WorksOfflineBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ZeroMaintenanceBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/ZeroMaintenanceBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/CustomDomain/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$OpenSourceBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/OpenSourceBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$PopularAppsBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/PopularAppsBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/NativelySocialBenefit/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$BeautifulThemesBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/BeautifulThemesBenefit/index.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
;
;
;
;
;
const Benefits = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                    children: "Powerful Benefits"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                    container: true,
                    spacing: {
                        xs: "24px",
                        md: "30px"
                    },
                    rowSpacing: {
                        xs: "24px",
                        md: "64px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SocialBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SocialBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 29,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$SeoBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SeoBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 32,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ConversionBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConversionBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 36,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$WorksOfflineBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WorksOfflineBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$ZeroMaintenanceBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZeroMaintenanceBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 44,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$CustomDomain$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomDomain"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 48,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$OpenSourceBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpenSourceBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 52,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 51,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$BeautifulThemesBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BeautifulThemesBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 56,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$NativelySocialBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NativelySocialBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 60,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$PopularAppsBenefit$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopularAppsBenefit"], {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                                lineNumber: 64,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/Benefits/index.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
};
_c = Benefits;
var _c;
__turbopack_refresh__.register(_c, "Benefits");

})()),
"[project]/src/components/Pages/Landing/components/FAQ/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledGridItem": ()=>StyledGridItem,
    "StyledTitle": ()=>StyledTitle,
    "StyledTitleDescription": ()=>StyledTitleDescription,
    "StyledTitleFAQ": ()=>StyledTitleFAQ,
    "StyledWrap": ()=>StyledWrap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript) <export default as Grid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        color: theme.palette.primary.main,
        paddingBottom: "120px",
        paddingTop: "120px",
        [theme.breakpoints.down("md")]: {
            paddingBottom: "64px",
            paddingTop: "64px"
        },
        hr: {
            margin: 0,
            border: "1px solid #EFEFEF"
        }
    }));
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 48,
        color: theme.palette.primary.main,
        textAlign: "center",
        fontWeight: "bold",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        marginBottom: 64,
        [theme.breakpoints.down("md")]: {
            fontSize: 32,
            marginBottom: 24
        }
    }));
const StyledTitleFAQ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 24,
        color: theme.palette.primary.main,
        fontWeight: "600",
        lineHeight: "34px",
        [theme.breakpoints.down("md")]: {
            fontSize: 21,
            marginBottom: 8
        }
    }));
const StyledTitleDescription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 18,
        color: theme.palette.primary.main,
        fontWeight: "400",
        lineHeight: "28px",
        [theme.breakpoints.down("md")]: {
            fontSize: 16,
            lineHeight: "24px"
        }
    }));
const StyledGridItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"])(({ theme })=>({
        [theme.breakpoints.down("sm")]: {
            paddingTop: "0 !important"
        }
    }));

})()),
"[project]/src/components/Pages/Landing/components/FAQ/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "FAQ": ()=>FAQ
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/FAQ/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript) <export default as Grid>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const FAQ = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
            maxWidth: "md",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                    children: "Questions & Answers"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                    container: true,
                    spacing: {
                        xs: "24px",
                        md: "48px"
                    },
                    rowSpacing: {
                        xs: "32px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFAQ"], {
                                children: "How does it work?"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 22,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGridItem"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleDescription"], {
                                children: [
                                    "Sites are Nostr events, the themes are open-source",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://ghost.org",
                                        target: "_blank",
                                        children: "Ghost"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 27,
                                        columnNumber: 15
                                    }, this),
                                    "themes published on relays and Blossom servers. Npub.pro does not host your data, it only hosts the code to convert Nostr events to web pages. The proposed NIP-512 is here."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 25,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 37,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFAQ"], {
                                children: "Can I self-host?"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 41,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGridItem"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleDescription"], {
                                children: [
                                    "Yes, absolutely! The easiest way to do that is using the free Github Pages hosting,",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://blog.npub.pro/post/how-to-self-host-on-github",
                                        children: "read more here"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 47,
                                        columnNumber: 15
                                    }, this),
                                    ". A more advanced solution would be to run a docker container that does server-side rendering for your site to improve SEO and link sharing experience, it's coming soon."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 44,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 57,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFAQ"], {
                                children: "How do I publish my site?"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGridItem"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleDescription"], {
                                children: [
                                    "You can use any Nostr client to publish, just make sure your post matches the filter you've set up for your site (kind and hashtags). For long-form posts you can use",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://habla.news",
                                        target: "_blank",
                                        children: "Habla"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 68,
                                        columnNumber: 15
                                    }, this),
                                    "or",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://highlighter.com",
                                        target: "_blank",
                                        children: "Highlighter"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 72,
                                        columnNumber: 15
                                    }, this),
                                    "or",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://yakihonne.com/",
                                        target: "_blank",
                                        children: "Yakihonne"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 76,
                                        columnNumber: 15
                                    }, this),
                                    ", for micro-blog -",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://damus.io/",
                                        target: "_blank",
                                        children: "Damus"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 80,
                                        columnNumber: 15
                                    }, this),
                                    ",",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://amethyst.social/",
                                        target: "_blank",
                                        children: "Amethyst"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 84,
                                        columnNumber: 15
                                    }, this),
                                    ",",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://primal.net",
                                        target: "_blank",
                                        children: "Primal"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 88,
                                        columnNumber: 15
                                    }, this),
                                    "or almost any other Nostr app."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 64,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 96,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 95,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFAQ"], {
                                children: "Is it censorship resistant?"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 100,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGridItem"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleDescription"], {
                                children: "The npub.pro site engine follows the outbox model, which means that if some relay blocks your events and you change your relay list, your site will fetch events from your new relays. We are making sure that your Nostr site is as robust as your Nostr profile."
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 103,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 113,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 112,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleFAQ"], {
                                children: "Is npub.pro site free?"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 117,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 116,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledGridItem"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitleDescription"], {
                                children: [
                                    "We will host your site for free on ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
                                        children: "your-name"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 121,
                                        columnNumber: 50
                                    }, this),
                                    ".npub.pro address. If you want to attach a custom domain and get other benefits, you can switch to a ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "#pro",
                                        children: "Pro plan"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 123,
                                        columnNumber: 45
                                    }, this),
                                    ". You can also self-host a Nostr site — all the data is on relays, the engine is",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://github.com/nostrband/nostrsite/",
                                        target: "_blank",
                                        children: "open-source"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                        lineNumber: 126,
                                        columnNumber: 15
                                    }, this),
                                    ', and there is no "migration" — it just works, anywhere.'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {}, void 0, false, {
                                fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                                lineNumber: 135,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                            lineNumber: 134,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/FAQ/index.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
};
_c = FAQ;
var _c;
__turbopack_refresh__.register(_c, "FAQ");

})()),
"[project]/src/components/Pages/Landing/components/Pricing/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledCostPrice": ()=>StyledCostPrice,
    "StyledDescriptionPrice": ()=>StyledDescriptionPrice,
    "StyledFeatureDescriptionPrice": ()=>StyledFeatureDescriptionPrice,
    "StyledFeaturePrice": ()=>StyledFeaturePrice,
    "StyledFeaturePriceGroup": ()=>StyledFeaturePriceGroup,
    "StyledIconPrice": ()=>StyledIconPrice,
    "StyledItem": ()=>StyledItem,
    "StyledPlanPrice": ()=>StyledPlanPrice,
    "StyledTitle": ()=>StyledTitle,
    "StyledWrap": ()=>StyledWrap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$theme$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/mui/theme.tsx [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__ = __turbopack_import__("[project]/src/mui/interdisplay_8136d12b.js [app-client] (ecmascript) <export default as InterDisplay>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
const StyledWrap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        color: "#fff",
        background: theme.palette.primary.main,
        paddingBottom: "120px",
        paddingTop: "120px",
        [theme.breakpoints.down("md")]: {
            paddingBottom: "64px",
            paddingTop: "64px"
        }
    }));
const StyledTitle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(({ theme })=>({
        fontSize: 48,
        color: "#fff",
        textAlign: "center",
        fontWeight: "bold",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        marginBottom: 64,
        [theme.breakpoints.down("md")]: {
            fontSize: 32,
            marginBottom: 24
        }
    }));
const StyledItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(({ theme })=>({
        color: theme.palette.primary.main,
        paddingBottom: "120px",
        padding: 24,
        borderRadius: 32,
        background: "#fff"
    }));
const StyledPlanPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        fontSize: 24,
        fontWeight: "bold",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        marginBottom: 8
    }));
const StyledDescriptionPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        fontSize: 14,
        fontWeight: "400",
        marginBottom: 8
    }));
const StyledCostPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        fontSize: 48,
        fontWeight: "bold",
        fontFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mui$2f$interdisplay_8136d12b$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InterDisplay$3e$__["InterDisplay"].style.fontFamily,
        marginBottom: 24,
        small: {
            fontSize: 24
        }
    }));
const StyledFeaturePrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        gap: 12
    }));
const StyledFeaturePriceGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        display: "flex",
        flexDirection: "column",
        gap: 24,
        marginTop: 24
    }));
const StyledIconPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        width: 16
    }));
const StyledFeatureDescriptionPrice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"])(()=>({
        fontSize: 16,
        lineHeight: "24px",
        fontWeight: "400",
        span: {
            fontWeight: "bold"
        }
    }));

})()),
"[project]/src/components/Pages/Landing/components/Pricing/IconCheck.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "IconCheck": ()=>IconCheck
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const IconCheck = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "16",
        height: "16",
        viewBox: "0 0 16 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M14.5306 5.03032L6.5306 13.0303C6.46092 13.1002 6.37813 13.1557 6.28696 13.1936C6.1958 13.2314 6.09806 13.2509 5.99935 13.2509C5.90064 13.2509 5.8029 13.2314 5.71173 13.1936C5.62057 13.1557 5.53778 13.1002 5.4681 13.0303L1.9681 9.53032C1.89833 9.46056 1.84299 9.37774 1.80524 9.28658C1.76748 9.19543 1.74805 9.09774 1.74805 8.99907C1.74805 8.90041 1.76748 8.80272 1.80524 8.71156C1.84299 8.62041 1.89833 8.53759 1.9681 8.46782C2.03786 8.39806 2.12069 8.34272 2.21184 8.30496C2.30299 8.26721 2.40069 8.24777 2.49935 8.24777C2.59801 8.24777 2.69571 8.26721 2.78686 8.30496C2.87801 8.34272 2.96083 8.39806 3.0306 8.46782L5.99997 11.4372L13.4693 3.96907C13.6102 3.82818 13.8013 3.74902 14.0006 3.74902C14.1999 3.74902 14.391 3.82818 14.5318 3.96907C14.6727 4.10997 14.7519 4.30107 14.7519 4.50032C14.7519 4.69958 14.6727 4.89068 14.5318 5.03157L14.5306 5.03032Z",
            fill: "#FF3ED9"
        }, void 0, false, {
            fileName: "[project]/src/components/Pages/Landing/components/Pricing/IconCheck.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/Pricing/IconCheck.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
};
_c = IconCheck;
var _c;
__turbopack_refresh__.register(_c, "IconCheck");

})()),
"[project]/src/components/Pages/Landing/components/Pricing/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Pricing": ()=>Pricing
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Pricing/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript) <export default as Grid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Pricing/IconCheck.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
const Pricing = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                    id: "pricing",
                    children: "Pricing"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                    container: true,
                    spacing: {
                        xs: "24px"
                    },
                    justifyContent: "center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            md: 4,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledItem"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledPlanPrice"], {
                                        children: "Free"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 25,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledDescriptionPrice"], {
                                        children: "Good for starters"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 26,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledCostPrice"], {
                                        children: "0 sats"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 27,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        size: "large",
                                        fullWidth: true,
                                        color: "decorate",
                                        variant: "contained",
                                        href: "#themes-onboarding",
                                        children: "Choose a Theme"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 28,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePriceGroup"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 41,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 40,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Beautiful themes."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 45,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Compatible with open-source Ghost themes to make your content stand out."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 44,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 43,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 39,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 53,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 52,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Subdomain."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 57,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Get your-name.npub.pro domain — a short address you can share with your audience."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 56,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 55,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 51,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 65,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 64,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Performance."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 69,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Your site is served by a global CDN with low latency and 99.9% uptime."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 68,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 67,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 63,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 77,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 76,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Meta tags & SEO."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 81,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Up to 1000 latest posts rendered by our server to improve SEO and link sharing experience."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 80,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 79,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 75,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 90,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 89,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Self-hostable."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 94,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Download a zip-archive and publish the code of your site to Github Pages or your own server."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 93,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 92,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 88,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 116,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 115,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Interoperable."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 120,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Built around the new NIP-512 proposal, so that you could switch to a better engine at any time."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 119,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 118,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 114,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 38,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                lineNumber: 24,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            md: 4,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledItem"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledPlanPrice"], {
                                        id: "pro",
                                        children: "Pro"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 131,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledDescriptionPrice"], {
                                        children: "Best for active creators"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledCostPrice"], {
                                        children: [
                                            "9000 sats ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                children: "/mo"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 136,
                                                columnNumber: 27
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 135,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        size: "large",
                                        fullWidth: true,
                                        color: "decorate",
                                        variant: "contained",
                                        disabled: true,
                                        children: "Coming soon"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 138,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePriceGroup"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "All you get on Free"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 151,
                                                            columnNumber: 21
                                                        }, this),
                                                        " plus:"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                    lineNumber: 150,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 149,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 157,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 156,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Custom Domain."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 161,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Switch to your own domain and keep using our scalable infrastructure to host your site."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 160,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 159,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 155,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 169,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Higher capacity."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 173,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Up to 10000 latest posts rendered by our server for longer-term SEO benefits."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 172,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 171,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 167,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 181,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 180,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Support & customizations."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 185,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Reach out to discuss any custom theme, plugin or integration that you need for your site."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 184,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 183,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 179,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeaturePrice"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledIconPrice"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$IconCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconCheck"], {}, void 0, false, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 194,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 193,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFeatureDescriptionPrice"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Fund the ecosystem."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                                    lineNumber: 198,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Big part of your payments go directly to developers of themes and plugins you're using."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                            lineNumber: 197,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                        lineNumber: 196,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                                lineNumber: 192,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                        lineNumber: 148,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                                lineNumber: 130,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                            lineNumber: 129,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
                    lineNumber: 22,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/Pricing/index.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
_c = Pricing;
var _c;
__turbopack_refresh__.register(_c, "Pricing");

})()),
"[project]/src/components/Pages/Landing/components/Footer/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledFooter": ()=>StyledFooter
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const StyledFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        padding: 25,
        textAlign: "center",
        color: "#292C34"
    }));

})()),
"[project]/src/components/Pages/Landing/components/Footer/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Footer": ()=>Footer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Footer$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Footer/styled.tsx [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const Footer = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Footer$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledFooter"], {
        children: [
            "© Npub.Pro 2024.",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "https://github.com/nostrband/nostrsite/",
                children: "Open-source"
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/components/Footer/index.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this),
            " project by ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "https://nostr.band",
                children: "Nostr.Band"
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/components/Footer/index.tsx",
                lineNumber: 8,
                columnNumber: 10
            }, this),
            "."
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Pages/Landing/components/Footer/index.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
};
_c = Footer;
var _c;
__turbopack_refresh__.register(_c, "Footer");

})()),
"[project]/src/components/Pages/Landing/components/Reviews/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Reviews": ()=>Reviews
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Benefits/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Grid/Grid.js [app-client] (ecmascript) <export default as Grid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/script.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
const Reviews = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledWrap"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledTitle"], {
                    children: "Community Opinion"
                }, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                    container: true,
                    spacing: {
                        xs: "24px",
                        md: "30px"
                    },
                    rowSpacing: {
                        xs: "24px",
                        md: "64px"
                    },
                    color: "#000",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note16allhwqwtdh67tggr4vk2pqgjyus68783t7pdalru90n54tcqdzqvcs8ue"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 24,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review1",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note16allhwqwtdh67tggr4vk2pqgjyus68783t7pdalru90n54tcqdzqvcs8ue',        '#nostr-embed-note16allhwqwtdh67tggr4vk2pqgjyus68783t7pdalru90n54tcqdzqvcs8ue',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note1k08kxsxdzcfw96rr8uh42rehd94kzxaw049axnqdkmjfccj3vk0sdy5d8g"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review2",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note1k08kxsxdzcfw96rr8uh42rehd94kzxaw049axnqdkmjfccj3vk0sdy5d8g',        '#nostr-embed-note1k08kxsxdzcfw96rr8uh42rehd94kzxaw049axnqdkmjfccj3vk0sdy5d8g',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note13jevyp8h8dfnhjwu6hq82x2qyk4kw4udukhjcpunhd4cgv39k6lqfa57p0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 34,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review3",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note13jevyp8h8dfnhjwu6hq82x2qyk4kw4udukhjcpunhd4cgv39k6lqfa57p0',        '#nostr-embed-note13jevyp8h8dfnhjwu6hq82x2qyk4kw4udukhjcpunhd4cgv39k6lqfa57p0',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note10xfzq7m40ex34aum69cjhn0e0xegn9nv56j3nury2dpvzl04cjxss8z786"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review4",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note10xfzq7m40ex34aum69cjhn0e0xegn9nv56j3nury2dpvzl04cjxss8z786',        '#nostr-embed-note10xfzq7m40ex34aum69cjhn0e0xegn9nv56j3nury2dpvzl04cjxss8z786',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 40,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note1zrgenv0706vulhv4m2s6lrtt940p5w6ufna568g3ph9f6hllmxdsn6t3sg"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 44,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review5",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note1zrgenv0706vulhv4m2s6lrtt940p5w6ufna568g3ph9f6hllmxdsn6t3sg',        '#nostr-embed-note1zrgenv0706vulhv4m2s6lrtt940p5w6ufna568g3ph9f6hllmxdsn6t3sg',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 45,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note19huvh7nmtgqww2ye0esmvazvtpkty2wpyv466cgatnrzchadwvkqke42a4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review6",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note19huvh7nmtgqww2ye0esmvazvtpkty2wpyv466cgatnrzchadwvkqke42a4',        '#nostr-embed-note19huvh7nmtgqww2ye0esmvazvtpkty2wpyv466cgatnrzchadwvkqke42a4',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 50,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note1hnhpe9j0g4gqrkw3zvcvqv25ghdumwspscc97xzu7ts5yekd7wrqrlrnkn"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 54,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review7",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note1hnhpe9j0g4gqrkw3zvcvqv25ghdumwspscc97xzu7ts5yekd7wrqrlrnkn',        '#nostr-embed-note1hnhpe9j0g4gqrkw3zvcvqv25ghdumwspscc97xzu7ts5yekd7wrqrlrnkn',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 55,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Grid$2f$Grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Grid$3e$__["Grid"], {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "nostr-embed-note12rpy7e4x9u7782e3emtvyamga97hqtsudm8993scsmje7353gjmqvt39nw"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 59,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "review8",
                                    children: `!(function () {    const n=document.createElement('script');n.type='text/javascript';n.async=!0;n.src='https://cdn.jsdelivr.net/gh/nostrband/nostr-embed@0.1.17/dist/nostr-embed.js';    const options = {      showZaps: true,      showCopyAddr: false,      hideNostrich: true,      showFollowing: true, hideCounters: true };    n.onload=function () {      nostrEmbed.init(        'note12rpy7e4x9u7782e3emtvyamga97hqtsudm8993scsmje7353gjmqvt39nw',        '#nostr-embed-note12rpy7e4x9u7782e3emtvyamga97hqtsudm8993scsmje7353gjmqvt39nw',        '',        options      );    };const a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(n, a);  })();`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                                    lineNumber: 60,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
            lineNumber: 14,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Pages/Landing/components/Reviews/index.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
};
_c = Reviews;
var _c;
__turbopack_refresh__.register(_c, "Reviews");

})()),
"[project]/src/components/HeaderOnboardingScroll/styled.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "StyledAppBar": ()=>StyledAppBar,
    "StyledHeaderContainer": ()=>StyledHeaderContainer,
    "StyledHeaderOnboarding": ()=>StyledHeaderOnboarding,
    "StyledLogo": ()=>StyledLogo,
    "StyledToolbar": ()=>StyledToolbar
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/styles/styled.js [app-client] (ecmascript) <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppBar$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/AppBar/AppBar.js [app-client] (ecmascript) <export default as AppBar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Box/Box.js [app-client] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Container/Container.js [app-client] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Toolbar/Toolbar.js [app-client] (ecmascript) <export default as Toolbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
const StyledHeaderOnboarding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        position: "relative",
        width: "100%",
        padding: "16px 0"
    }));
const StyledHeaderContainer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"])(()=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "10px"
    }));
const StyledLogo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"])(()=>({
        width: "45px",
        display: "flex",
        alignItems: "center"
    }));
const StyledAppBar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function MainContentName(props, ref) {
    const exclude = new Set([
        "isHide"
    ]);
    const omitProps = Object.fromEntries(Object.entries(props).filter((e)=>!exclude.has(e[0])));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$AppBar$2f$AppBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppBar$3e$__["AppBar"], {
        component: "nav",
        ref: ref,
        ...omitProps
    }, void 0, false, {
        fileName: "[project]/src/components/HeaderOnboardingScroll/styled.tsx",
        lineNumber: 39,
        columnNumber: 14
    }, this);
}))(({ isHide, theme })=>({
        width: "100%",
        left: 0,
        overflow: "hidden",
        top: `${isHide ? "-100px" : "0px"}`,
        transition: "0.3s",
        [theme.breakpoints.down("lg")]: {
            width: "100%"
        }
    }));
const StyledToolbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Toolbar$2f$Toolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Toolbar$3e$__["Toolbar"])(({ theme })=>({
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        width: "100%",
        left: 0,
        padding: "0 !important"
    }));

})()),
"[project]/src/components/HeaderOnboardingScroll/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "HeaderOnboardingScroll": ()=>HeaderOnboardingScroll
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/HeaderOnboardingScroll/styled.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@mui/material/Button/Button.js [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Logo$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Logo/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
const HeaderOnboardingScroll = ({ isHeaderVisible })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledAppBar"], {
        isHide: isHeaderVisible,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledToolbar"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledHeaderContainer"], {
                maxWidth: "lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$styled$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledLogo"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Logo$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                            fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
                            lineNumber: 22,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
                        lineNumber: 21,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        size: "large",
                        variant: "contained",
                        color: "decorate",
                        LinkComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                        href: "/onboarding",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                            children: "Get started →"
                        }, void 0, false, {
                            fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
                            lineNumber: 31,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
                        lineNumber: 24,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/HeaderOnboardingScroll/index.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
_c = HeaderOnboardingScroll;
var _c;
__turbopack_refresh__.register(_c, "HeaderOnboardingScroll");

})()),
"[project]/src/components/Pages/Landing/index.tsx [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboarding$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/HeaderOnboarding/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/HeadIntroOnboarding/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ThemesOnboarding/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Benefits/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/FAQ/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Pricing/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Footer$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Footer/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Reviews$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Pages/Landing/components/Reviews/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/HeaderOnboardingScroll/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
const Landing = ()=>{
    _s();
    const headerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isHeaderVisible, setIsHeaderVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const observer = new IntersectionObserver(([entry])=>{
            setIsHeaderVisible(entry.isIntersecting);
        }, {
            root: null,
            rootMargin: "0px",
            threshold: 0
        });
        if (headerRef.current) {
            observer.observe(headerRef.current);
        }
        return ()=>{
            if (headerRef.current) {
                observer.unobserve(headerRef.current);
            }
        };
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboardingScroll$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeaderOnboardingScroll"], {
                isHeaderVisible: isHeaderVisible
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: headerRef,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeaderOnboarding$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeaderOnboarding"], {}, void 0, false, {
                    fileName: "[project]/src/components/Pages/Landing/index.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$HeadIntroOnboarding$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadIntroOnboarding"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Benefits$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Benefits"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThemesOnboarding$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemesOnboarding"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Reviews$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Reviews"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$FAQ$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FAQ"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Pricing$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pricing"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Pages$2f$Landing$2f$components$2f$Footer$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Footer"], {}, void 0, false, {
                fileName: "[project]/src/components/Pages/Landing/index.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
_s(Landing, "tROP4VSqW0GZeUMlVRTM23N7Wsw=");
_c = Landing;
const __TURBOPACK__default__export__ = Landing;
var _c;
__turbopack_refresh__.register(_c, "Landing");

})()),
}]);

//# sourceMappingURL=_1994db._.js.map
(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_not-found_tsx_7c11c6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_not-found_tsx_7c11c6._.js",
  "chunks": [
    "static/chunks/node_modules_eb31d9._.js",
    "static/chunks/src_0214e1._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_f6d818._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_f6d818._.js",
  "chunks": [
    "static/chunks/_6033da._.js",
    "static/chunks/node_modules_@mui_material_b24412._.js",
    "static/chunks/node_modules_next_0db4c3._.js",
    "static/chunks/node_modules_9232d4._.js"
  ],
  "source": "dynamic"
});

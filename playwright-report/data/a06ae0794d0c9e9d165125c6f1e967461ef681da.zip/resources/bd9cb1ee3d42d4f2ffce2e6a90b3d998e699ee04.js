(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/node_modules_228eaf._.js", {

"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "bool": ()=>bool,
    "bytes": ()=>bytes,
    "default": ()=>__TURBOPACK__default__export__,
    "exists": ()=>exists,
    "hash": ()=>hash,
    "isBytes": ()=>isBytes,
    "number": ()=>number,
    "output": ()=>output
});
function number(n) {
    if (!Number.isSafeInteger(n) || n < 0) throw new Error(`positive integer expected, not ${n}`);
}
function bool(b) {
    if (typeof b !== 'boolean') throw new Error(`boolean expected, not ${b}`);
}
function isBytes(a) {
    return a instanceof Uint8Array || a != null && typeof a === 'object' && a.constructor.name === 'Uint8Array';
}
function bytes(b, ...lengths) {
    if (!isBytes(b)) throw new Error('Uint8Array expected');
    if (lengths.length > 0 && !lengths.includes(b.length)) throw new Error(`Uint8Array expected of length ${lengths}, not of length=${b.length}`);
}
function hash(hash) {
    if (typeof hash !== 'function' || typeof hash.create !== 'function') throw new Error('hash must be wrapped by utils.wrapConstructor');
    number(hash.outputLen);
    number(hash.blockLen);
}
function exists(instance, checkFinished = true) {
    if (instance.destroyed) throw new Error('Hash instance has been destroyed');
    if (checkFinished && instance.finished) throw new Error('Hash#digest() has already been called');
}
function output(out, instance) {
    bytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
        throw new Error(`digestInto() expects output buffer of length at least ${min}`);
    }
}
;
const assert = {
    number,
    bool,
    bytes,
    hash,
    exists,
    output
};
const __TURBOPACK__default__export__ = assert;
 //# sourceMappingURL=_assert.js.map

})()),
"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

/*! noble-ciphers - MIT License (c) 2023 Paul Miller (paulmillr.com) */ __turbopack_esm__({
    "Hash": ()=>Hash,
    "asyncLoop": ()=>asyncLoop,
    "bytesToHex": ()=>bytesToHex,
    "bytesToNumberBE": ()=>bytesToNumberBE,
    "bytesToUtf8": ()=>bytesToUtf8,
    "checkOpts": ()=>checkOpts,
    "concatBytes": ()=>concatBytes,
    "createView": ()=>createView,
    "equalBytes": ()=>equalBytes,
    "hexToBytes": ()=>hexToBytes,
    "hexToNumber": ()=>hexToNumber,
    "isLE": ()=>isLE,
    "nextTick": ()=>nextTick,
    "numberToBytesBE": ()=>numberToBytesBE,
    "setBigUint64": ()=>setBigUint64,
    "toBytes": ()=>toBytes,
    "u16": ()=>u16,
    "u32": ()=>u32,
    "u64Lengths": ()=>u64Lengths,
    "u8": ()=>u8,
    "utf8ToBytes": ()=>utf8ToBytes,
    "wrapCipher": ()=>wrapCipher
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const u8 = (arr)=>new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
const u16 = (arr)=>new Uint16Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 2));
const u32 = (arr)=>new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
const createView = (arr)=>new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
const isLE = new Uint8Array(new Uint32Array([
    0x11223344
]).buffer)[0] === 0x44;
if (!isLE) throw new Error('Non little-endian hardware is not supported');
// Array where index 0xf0 (240) is mapped to string 'f0'
const hexes = /* @__PURE__ */ Array.from({
    length: 256
}, (_, i)=>i.toString(16).padStart(2, '0'));
function bytesToHex(bytes) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(bytes);
    // pre-caching improves the speed 6x
    let hex = '';
    for(let i = 0; i < bytes.length; i++){
        hex += hexes[bytes[i]];
    }
    return hex;
}
// We use optimized technique to convert hex string to byte array
const asciis = {
    _0: 48,
    _9: 57,
    _A: 65,
    _F: 70,
    _a: 97,
    _f: 102
};
function asciiToBase16(char) {
    if (char >= asciis._0 && char <= asciis._9) return char - asciis._0;
    if (char >= asciis._A && char <= asciis._F) return char - (asciis._A - 10);
    if (char >= asciis._a && char <= asciis._f) return char - (asciis._a - 10);
    return;
}
function hexToBytes(hex) {
    if (typeof hex !== 'string') throw new Error('hex string expected, got ' + typeof hex);
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2) throw new Error('padded hex string expected, got unpadded hex of length ' + hl);
    const array = new Uint8Array(al);
    for(let ai = 0, hi = 0; ai < al; ai++, hi += 2){
        const n1 = asciiToBase16(hex.charCodeAt(hi));
        const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
        if (n1 === undefined || n2 === undefined) {
            const char = hex[hi] + hex[hi + 1];
            throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
        }
        array[ai] = n1 * 16 + n2;
    }
    return array;
}
function hexToNumber(hex) {
    if (typeof hex !== 'string') throw new Error('hex string expected, got ' + typeof hex);
    // Big Endian
    return BigInt(hex === '' ? '0' : `0x${hex}`);
}
function bytesToNumberBE(bytes) {
    return hexToNumber(bytesToHex(bytes));
}
function numberToBytesBE(n, len) {
    return hexToBytes(n.toString(16).padStart(len * 2, '0'));
}
const nextTick = async ()=>{};
async function asyncLoop(iters, tick, cb) {
    let ts = Date.now();
    for(let i = 0; i < iters; i++){
        cb(i);
        // Date.now() is not monotonic, so in case if clock goes backwards we return return control too
        const diff = Date.now() - ts;
        if (diff >= 0 && diff < tick) continue;
        await nextTick();
        ts += diff;
    }
}
function utf8ToBytes(str) {
    if (typeof str !== 'string') throw new Error(`string expected, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
}
function bytesToUtf8(bytes) {
    return new TextDecoder().decode(bytes);
}
function toBytes(data) {
    if (typeof data === 'string') data = utf8ToBytes(data);
    else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBytes"])(data)) data = data.slice();
    else throw new Error(`Uint8Array expected, got ${typeof data}`);
    return data;
}
function concatBytes(...arrays) {
    let sum = 0;
    for(let i = 0; i < arrays.length; i++){
        const a = arrays[i];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(a);
        sum += a.length;
    }
    const res = new Uint8Array(sum);
    for(let i = 0, pad = 0; i < arrays.length; i++){
        const a = arrays[i];
        res.set(a, pad);
        pad += a.length;
    }
    return res;
}
function checkOpts(defaults, opts) {
    if (opts == null || typeof opts !== 'object') throw new Error('options must be defined');
    const merged = Object.assign(defaults, opts);
    return merged;
}
function equalBytes(a, b) {
    if (a.length !== b.length) return false;
    let diff = 0;
    for(let i = 0; i < a.length; i++)diff |= a[i] ^ b[i];
    return diff === 0;
}
class Hash {
}
const wrapCipher = (params, c)=>{
    Object.assign(c, params);
    return c;
};
function setBigUint64(view, byteOffset, value, isLE) {
    if (typeof view.setBigUint64 === 'function') return view.setBigUint64(byteOffset, value, isLE);
    const _32n = BigInt(32);
    const _u32_max = BigInt(0xffffffff);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE ? 4 : 0;
    const l = isLE ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE);
    view.setUint32(byteOffset + l, wl, isLE);
}
function u64Lengths(ciphertext, AAD) {
    const num = new Uint8Array(16);
    const view = createView(num);
    setBigUint64(view, 0, BigInt(AAD ? AAD.length : 0), true);
    setBigUint64(view, 8, BigInt(ciphertext.length), true);
    return num;
} //# sourceMappingURL=utils.js.map

})()),
"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_polyval.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "_toGHASHKey": ()=>_toGHASHKey,
    "ghash": ()=>ghash,
    "polyval": ()=>polyval
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
// GHash from AES-GCM and its little-endian "mirror image" Polyval from AES-SIV.
// Implemented in terms of GHash with conversion function for keys
// GCM GHASH from NIST SP800-38d, SIV from RFC 8452.
// https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38d.pdf
// GHASH   modulo: x^128 + x^7   + x^2   + x     + 1
// POLYVAL modulo: x^128 + x^127 + x^126 + x^121 + 1
const BLOCK_SIZE = 16;
// TODO: rewrite
// temporary padding buffer
const ZEROS16 = /* @__PURE__ */ new Uint8Array(16);
const ZEROS32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(ZEROS16);
const POLY = 0xe1; // v = 2*v % POLY
// v = 2*v % POLY
// NOTE: because x + x = 0 (add/sub is same), mul2(x) != x+x
// We can multiply any number using montgomery ladder and this function (works as double, add is simple xor)
const mul2 = (s0, s1, s2, s3)=>{
    const hiBit = s3 & 1;
    return {
        s3: s2 << 31 | s3 >>> 1,
        s2: s1 << 31 | s2 >>> 1,
        s1: s0 << 31 | s1 >>> 1,
        s0: s0 >>> 1 ^ POLY << 24 & -(hiBit & 1)
    };
};
const swapLE = (n)=>(n >>> 0 & 0xff) << 24 | (n >>> 8 & 0xff) << 16 | (n >>> 16 & 0xff) << 8 | n >>> 24 & 0xff | 0;
function _toGHASHKey(k) {
    k.reverse();
    const hiBit = k[15] & 1;
    // k >>= 1
    let carry = 0;
    for(let i = 0; i < k.length; i++){
        const t = k[i];
        k[i] = t >>> 1 | carry;
        carry = (t & 1) << 7;
    }
    k[0] ^= -hiBit & 0xe1; // if (hiBit) n ^= 0xe1000000000000000000000000000000;
    return k;
}
const estimateWindow = (bytes)=>{
    if (bytes > 64 * 1024) return 8;
    if (bytes > 1024) return 4;
    return 2;
};
class GHASH {
    // We select bits per window adaptively based on expectedLength
    constructor(key, expectedLength){
        this.blockLen = BLOCK_SIZE;
        this.outputLen = BLOCK_SIZE;
        this.s0 = 0;
        this.s1 = 0;
        this.s2 = 0;
        this.s3 = 0;
        this.finished = false;
        key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(key);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key, 16);
        const kView = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createView"])(key);
        let k0 = kView.getUint32(0, false);
        let k1 = kView.getUint32(4, false);
        let k2 = kView.getUint32(8, false);
        let k3 = kView.getUint32(12, false);
        // generate table of doubled keys (half of montgomery ladder)
        const doubles = [];
        for(let i = 0; i < 128; i++){
            doubles.push({
                s0: swapLE(k0),
                s1: swapLE(k1),
                s2: swapLE(k2),
                s3: swapLE(k3)
            });
            ({ s0: k0, s1: k1, s2: k2, s3: k3 } = mul2(k0, k1, k2, k3));
        }
        const W = estimateWindow(expectedLength || 1024);
        if (![
            1,
            2,
            4,
            8
        ].includes(W)) throw new Error(`ghash: wrong window size=${W}, should be 2, 4 or 8`);
        this.W = W;
        const bits = 128; // always 128 bits;
        const windows = bits / W;
        const windowSize = this.windowSize = 2 ** W;
        const items = [];
        // Create precompute table for window of W bits
        for(let w = 0; w < windows; w++){
            // truth table: 00, 01, 10, 11
            for(let byte = 0; byte < windowSize; byte++){
                // prettier-ignore
                let s0 = 0, s1 = 0, s2 = 0, s3 = 0;
                for(let j = 0; j < W; j++){
                    const bit = byte >>> W - j - 1 & 1;
                    if (!bit) continue;
                    const { s0: d0, s1: d1, s2: d2, s3: d3 } = doubles[W * w + j];
                    s0 ^= d0, s1 ^= d1, s2 ^= d2, s3 ^= d3;
                }
                items.push({
                    s0,
                    s1,
                    s2,
                    s3
                });
            }
        }
        this.t = items;
    }
    _updateBlock(s0, s1, s2, s3) {
        s0 ^= this.s0, s1 ^= this.s1, s2 ^= this.s2, s3 ^= this.s3;
        const { W, t, windowSize } = this;
        // prettier-ignore
        let o0 = 0, o1 = 0, o2 = 0, o3 = 0;
        const mask = (1 << W) - 1; // 2**W will kill performance.
        let w = 0;
        for (const num of [
            s0,
            s1,
            s2,
            s3
        ]){
            for(let bytePos = 0; bytePos < 4; bytePos++){
                const byte = num >>> 8 * bytePos & 0xff;
                for(let bitPos = 8 / W - 1; bitPos >= 0; bitPos--){
                    const bit = byte >>> W * bitPos & mask;
                    const { s0: e0, s1: e1, s2: e2, s3: e3 } = t[w * windowSize + bit];
                    o0 ^= e0, o1 ^= e1, o2 ^= e2, o3 ^= e3;
                    w += 1;
                }
            }
        }
        this.s0 = o0;
        this.s1 = o1;
        this.s2 = o2;
        this.s3 = o3;
    }
    update(data) {
        data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(data);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exists"])(this);
        const b32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(data);
        const blocks = Math.floor(data.length / BLOCK_SIZE);
        const left = data.length % BLOCK_SIZE;
        for(let i = 0; i < blocks; i++){
            this._updateBlock(b32[i * 4 + 0], b32[i * 4 + 1], b32[i * 4 + 2], b32[i * 4 + 3]);
        }
        if (left) {
            ZEROS16.set(data.subarray(blocks * BLOCK_SIZE));
            this._updateBlock(ZEROS32[0], ZEROS32[1], ZEROS32[2], ZEROS32[3]);
            ZEROS32.fill(0); // clean tmp buffer
        }
        return this;
    }
    destroy() {
        const { t } = this;
        // clean precompute table
        for (const elm of t){
            elm.s0 = 0, elm.s1 = 0, elm.s2 = 0, elm.s3 = 0;
        }
    }
    digestInto(out) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exists"])(this);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["output"])(out, this);
        this.finished = true;
        const { s0, s1, s2, s3 } = this;
        const o32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(out);
        o32[0] = s0;
        o32[1] = s1;
        o32[2] = s2;
        o32[3] = s3;
        return out;
    }
    digest() {
        const res = new Uint8Array(BLOCK_SIZE);
        this.digestInto(res);
        this.destroy();
        return res;
    }
}
class Polyval extends GHASH {
    constructor(key, expectedLength){
        key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(key);
        const ghKey = _toGHASHKey(key.slice());
        super(ghKey, expectedLength);
        ghKey.fill(0);
    }
    update(data) {
        data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(data);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exists"])(this);
        const b32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(data);
        const left = data.length % BLOCK_SIZE;
        const blocks = Math.floor(data.length / BLOCK_SIZE);
        for(let i = 0; i < blocks; i++){
            this._updateBlock(swapLE(b32[i * 4 + 3]), swapLE(b32[i * 4 + 2]), swapLE(b32[i * 4 + 1]), swapLE(b32[i * 4 + 0]));
        }
        if (left) {
            ZEROS16.set(data.subarray(blocks * BLOCK_SIZE));
            this._updateBlock(swapLE(ZEROS32[3]), swapLE(ZEROS32[2]), swapLE(ZEROS32[1]), swapLE(ZEROS32[0]));
            ZEROS32.fill(0); // clean tmp buffer
        }
        return this;
    }
    digestInto(out) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exists"])(this);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["output"])(out, this);
        this.finished = true;
        // tmp ugly hack
        const { s0, s1, s2, s3 } = this;
        const o32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(out);
        o32[0] = s0;
        o32[1] = s1;
        o32[2] = s2;
        o32[3] = s3;
        return out.reverse();
    }
}
function wrapConstructorWithKey(hashCons) {
    const hashC = (msg, key)=>hashCons(key, msg.length).update((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(msg)).digest();
    const tmp = hashCons(new Uint8Array(16), 0);
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (key, expectedLength)=>hashCons(key, expectedLength);
    return hashC;
}
const ghash = wrapConstructorWithKey((key, expectedLength)=>new GHASH(key, expectedLength));
const polyval = wrapConstructorWithKey((key, expectedLength)=>new Polyval(key, expectedLength)); //# sourceMappingURL=_polyval.js.map

})()),
"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/aes.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

// prettier-ignore
__turbopack_esm__({
    "cbc": ()=>cbc,
    "cfb": ()=>cfb,
    "ctr": ()=>ctr,
    "ecb": ()=>ecb,
    "expandKeyDecLE": ()=>expandKeyDecLE,
    "expandKeyLE": ()=>expandKeyLE,
    "gcm": ()=>gcm,
    "siv": ()=>siv,
    "unsafe": ()=>unsafe
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_polyval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_polyval.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
/*
AES (Advanced Encryption Standard) aka Rijndael block cipher.

Data is split into 128-bit blocks. Encrypted in 10/12/14 rounds (128/192/256 bits). In every round:
1. **S-box**, table substitution
2. **Shift rows**, cyclic shift left of all rows of data array
3. **Mix columns**, multiplying every column by fixed polynomial
4. **Add round key**, round_key xor i-th column of array

Resources:
- FIPS-197 https://csrc.nist.gov/files/pubs/fips/197/final/docs/fips-197.pdf
- Original proposal: https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/aes-development/rijndael-ammended.pdf
*/ const BLOCK_SIZE = 16;
const BLOCK_SIZE32 = 4;
const EMPTY_BLOCK = new Uint8Array(BLOCK_SIZE);
const POLY = 0x11b; // 1 + x + x**3 + x**4 + x**8
// TODO: remove multiplication, binary ops only
function mul2(n) {
    return n << 1 ^ POLY & -(n >> 7);
}
function mul(a, b) {
    let res = 0;
    for(; b > 0; b >>= 1){
        // Montgomery ladder
        res ^= a & -(b & 1); // if (b&1) res ^=a (but const-time).
        a = mul2(a); // a = 2*a
    }
    return res;
}
// AES S-box is generated using finite field inversion,
// an affine transform, and xor of a constant 0x63.
const sbox = /* @__PURE__ */ (()=>{
    let t = new Uint8Array(256);
    for(let i = 0, x = 1; i < 256; i++, x ^= mul2(x))t[i] = x;
    const box = new Uint8Array(256);
    box[0] = 0x63; // first elm
    for(let i = 0; i < 255; i++){
        let x = t[255 - i];
        x |= x << 8;
        box[t[i]] = (x ^ x >> 4 ^ x >> 5 ^ x >> 6 ^ x >> 7 ^ 0x63) & 0xff;
    }
    return box;
})();
// Inverted S-box
const invSbox = /* @__PURE__ */ sbox.map((_, j)=>sbox.indexOf(j));
// Rotate u32 by 8
const rotr32_8 = (n)=>n << 24 | n >>> 8;
const rotl32_8 = (n)=>n << 8 | n >>> 24;
// T-table is optimization suggested in 5.2 of original proposal (missed from FIPS-197). Changes:
// - LE instead of BE
// - bigger tables: T0 and T1 are merged into T01 table and T2 & T3 into T23;
//   so index is u16, instead of u8. This speeds up things, unexpectedly
function genTtable(sbox, fn) {
    if (sbox.length !== 256) throw new Error('Wrong sbox length');
    const T0 = new Uint32Array(256).map((_, j)=>fn(sbox[j]));
    const T1 = T0.map(rotl32_8);
    const T2 = T1.map(rotl32_8);
    const T3 = T2.map(rotl32_8);
    const T01 = new Uint32Array(256 * 256);
    const T23 = new Uint32Array(256 * 256);
    const sbox2 = new Uint16Array(256 * 256);
    for(let i = 0; i < 256; i++){
        for(let j = 0; j < 256; j++){
            const idx = i * 256 + j;
            T01[idx] = T0[i] ^ T1[j];
            T23[idx] = T2[i] ^ T3[j];
            sbox2[idx] = sbox[i] << 8 | sbox[j];
        }
    }
    return {
        sbox,
        sbox2,
        T0,
        T1,
        T2,
        T3,
        T01,
        T23
    };
}
const tableEncoding = /* @__PURE__ */ genTtable(sbox, (s)=>mul(s, 3) << 24 | s << 16 | s << 8 | mul(s, 2));
const tableDecoding = /* @__PURE__ */ genTtable(invSbox, (s)=>mul(s, 11) << 24 | mul(s, 13) << 16 | mul(s, 9) << 8 | mul(s, 14));
const xPowers = /* @__PURE__ */ (()=>{
    const p = new Uint8Array(16);
    for(let i = 0, x = 1; i < 16; i++, x = mul2(x))p[i] = x;
    return p;
})();
function expandKeyLE(key) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key);
    const len = key.length;
    if (![
        16,
        24,
        32
    ].includes(len)) throw new Error(`aes: wrong key size: should be 16, 24 or 32, got: ${len}`);
    const { sbox2 } = tableEncoding;
    const k32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(key);
    const Nk = k32.length;
    const subByte = (n)=>applySbox(sbox2, n, n, n, n);
    const xk = new Uint32Array(len + 28); // expanded key
    xk.set(k32);
    // 4.3.1 Key expansion
    for(let i = Nk; i < xk.length; i++){
        let t = xk[i - 1];
        if (i % Nk === 0) t = subByte(rotr32_8(t)) ^ xPowers[i / Nk - 1];
        else if (Nk > 6 && i % Nk === 4) t = subByte(t);
        xk[i] = xk[i - Nk] ^ t;
    }
    return xk;
}
function expandKeyDecLE(key) {
    const encKey = expandKeyLE(key);
    const xk = encKey.slice();
    const Nk = encKey.length;
    const { sbox2 } = tableEncoding;
    const { T0, T1, T2, T3 } = tableDecoding;
    // Inverse key by chunks of 4 (rounds)
    for(let i = 0; i < Nk; i += 4){
        for(let j = 0; j < 4; j++)xk[i + j] = encKey[Nk - i - 4 + j];
    }
    encKey.fill(0);
    // apply InvMixColumn except first & last round
    for(let i = 4; i < Nk - 4; i++){
        const x = xk[i];
        const w = applySbox(sbox2, x, x, x, x);
        xk[i] = T0[w & 0xff] ^ T1[w >>> 8 & 0xff] ^ T2[w >>> 16 & 0xff] ^ T3[w >>> 24];
    }
    return xk;
}
// Apply tables
function apply0123(T01, T23, s0, s1, s2, s3) {
    return T01[s0 << 8 & 0xff00 | s1 >>> 8 & 0xff] ^ T23[s2 >>> 8 & 0xff00 | s3 >>> 24 & 0xff];
}
function applySbox(sbox2, s0, s1, s2, s3) {
    return sbox2[s0 & 0xff | s1 & 0xff00] | sbox2[s2 >>> 16 & 0xff | s3 >>> 16 & 0xff00] << 16;
}
function encrypt(xk, s0, s1, s2, s3) {
    const { sbox2, T01, T23 } = tableEncoding;
    let k = 0;
    s0 ^= xk[k++], s1 ^= xk[k++], s2 ^= xk[k++], s3 ^= xk[k++];
    const rounds = xk.length / 4 - 2;
    for(let i = 0; i < rounds; i++){
        const t0 = xk[k++] ^ apply0123(T01, T23, s0, s1, s2, s3);
        const t1 = xk[k++] ^ apply0123(T01, T23, s1, s2, s3, s0);
        const t2 = xk[k++] ^ apply0123(T01, T23, s2, s3, s0, s1);
        const t3 = xk[k++] ^ apply0123(T01, T23, s3, s0, s1, s2);
        s0 = t0, s1 = t1, s2 = t2, s3 = t3;
    }
    // last round (without mixcolumns, so using SBOX2 table)
    const t0 = xk[k++] ^ applySbox(sbox2, s0, s1, s2, s3);
    const t1 = xk[k++] ^ applySbox(sbox2, s1, s2, s3, s0);
    const t2 = xk[k++] ^ applySbox(sbox2, s2, s3, s0, s1);
    const t3 = xk[k++] ^ applySbox(sbox2, s3, s0, s1, s2);
    return {
        s0: t0,
        s1: t1,
        s2: t2,
        s3: t3
    };
}
function decrypt(xk, s0, s1, s2, s3) {
    const { sbox2, T01, T23 } = tableDecoding;
    let k = 0;
    s0 ^= xk[k++], s1 ^= xk[k++], s2 ^= xk[k++], s3 ^= xk[k++];
    const rounds = xk.length / 4 - 2;
    for(let i = 0; i < rounds; i++){
        const t0 = xk[k++] ^ apply0123(T01, T23, s0, s3, s2, s1);
        const t1 = xk[k++] ^ apply0123(T01, T23, s1, s0, s3, s2);
        const t2 = xk[k++] ^ apply0123(T01, T23, s2, s1, s0, s3);
        const t3 = xk[k++] ^ apply0123(T01, T23, s3, s2, s1, s0);
        s0 = t0, s1 = t1, s2 = t2, s3 = t3;
    }
    // Last round
    const t0 = xk[k++] ^ applySbox(sbox2, s0, s3, s2, s1);
    const t1 = xk[k++] ^ applySbox(sbox2, s1, s0, s3, s2);
    const t2 = xk[k++] ^ applySbox(sbox2, s2, s1, s0, s3);
    const t3 = xk[k++] ^ applySbox(sbox2, s3, s2, s1, s0);
    return {
        s0: t0,
        s1: t1,
        s2: t2,
        s3: t3
    };
}
function getDst(len, dst) {
    if (!dst) return new Uint8Array(len);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(dst);
    if (dst.length < len) throw new Error(`aes: wrong destination length, expected at least ${len}, got: ${dst.length}`);
    return dst;
}
// TODO: investigate merging with ctr32
function ctrCounter(xk, nonce, src, dst) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce, BLOCK_SIZE);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(src);
    const srcLen = src.length;
    dst = getDst(srcLen, dst);
    const ctr = nonce;
    const c32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(ctr);
    // Fill block (empty, ctr=0)
    let { s0, s1, s2, s3 } = encrypt(xk, c32[0], c32[1], c32[2], c32[3]);
    const src32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(src);
    const dst32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(dst);
    // process blocks
    for(let i = 0; i + 4 <= src32.length; i += 4){
        dst32[i + 0] = src32[i + 0] ^ s0;
        dst32[i + 1] = src32[i + 1] ^ s1;
        dst32[i + 2] = src32[i + 2] ^ s2;
        dst32[i + 3] = src32[i + 3] ^ s3;
        // Full 128 bit counter with wrap around
        let carry = 1;
        for(let i = ctr.length - 1; i >= 0; i--){
            carry = carry + (ctr[i] & 0xff) | 0;
            ctr[i] = carry & 0xff;
            carry >>>= 8;
        }
        ({ s0, s1, s2, s3 } = encrypt(xk, c32[0], c32[1], c32[2], c32[3]));
    }
    // leftovers (less than block)
    // It's possible to handle > u32 fast, but is it worth it?
    const start = BLOCK_SIZE * Math.floor(src32.length / BLOCK_SIZE32);
    if (start < srcLen) {
        const b32 = new Uint32Array([
            s0,
            s1,
            s2,
            s3
        ]);
        const buf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u8"])(b32);
        for(let i = start, pos = 0; i < srcLen; i++, pos++)dst[i] = src[i] ^ buf[pos];
    }
    return dst;
}
// AES CTR with overflowing 32 bit counter
// It's possible to do 32le significantly simpler (and probably faster) by using u32.
// But, we need both, and perf bottleneck is in ghash anyway.
function ctr32(xk, isLE, nonce, src, dst) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce, BLOCK_SIZE);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(src);
    dst = getDst(src.length, dst);
    const ctr = nonce; // write new value to nonce, so it can be re-used
    const c32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(ctr);
    const view = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createView"])(ctr);
    const src32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(src);
    const dst32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(dst);
    const ctrPos = isLE ? 0 : 12;
    const srcLen = src.length;
    // Fill block (empty, ctr=0)
    let ctrNum = view.getUint32(ctrPos, isLE); // read current counter value
    let { s0, s1, s2, s3 } = encrypt(xk, c32[0], c32[1], c32[2], c32[3]);
    // process blocks
    for(let i = 0; i + 4 <= src32.length; i += 4){
        dst32[i + 0] = src32[i + 0] ^ s0;
        dst32[i + 1] = src32[i + 1] ^ s1;
        dst32[i + 2] = src32[i + 2] ^ s2;
        dst32[i + 3] = src32[i + 3] ^ s3;
        ctrNum = ctrNum + 1 >>> 0; // u32 wrap
        view.setUint32(ctrPos, ctrNum, isLE);
        ({ s0, s1, s2, s3 } = encrypt(xk, c32[0], c32[1], c32[2], c32[3]));
    }
    // leftovers (less than a block)
    const start = BLOCK_SIZE * Math.floor(src32.length / BLOCK_SIZE32);
    if (start < srcLen) {
        const b32 = new Uint32Array([
            s0,
            s1,
            s2,
            s3
        ]);
        const buf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u8"])(b32);
        for(let i = start, pos = 0; i < srcLen; i++, pos++)dst[i] = src[i] ^ buf[pos];
    }
    return dst;
}
const ctr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 16,
    nonceLength: 16
}, function ctr(key, nonce) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce, BLOCK_SIZE);
    function processCtr(buf, dst) {
        const xk = expandKeyLE(key);
        const n = nonce.slice();
        const out = ctrCounter(xk, n, buf, dst);
        xk.fill(0);
        n.fill(0);
        return out;
    }
    return {
        encrypt: (plaintext, dst)=>processCtr(plaintext, dst),
        decrypt: (ciphertext, dst)=>processCtr(ciphertext, dst)
    };
});
function validateBlockDecrypt(data) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(data);
    if (data.length % BLOCK_SIZE !== 0) {
        throw new Error(`aes/(cbc-ecb).decrypt ciphertext should consist of blocks with size ${BLOCK_SIZE}`);
    }
}
function validateBlockEncrypt(plaintext, pcks5, dst) {
    let outLen = plaintext.length;
    const remaining = outLen % BLOCK_SIZE;
    if (!pcks5 && remaining !== 0) throw new Error('aec/(cbc-ecb): unpadded plaintext with disabled padding');
    const b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(plaintext);
    if (pcks5) {
        let left = BLOCK_SIZE - remaining;
        if (!left) left = BLOCK_SIZE; // if no bytes left, create empty padding block
        outLen = outLen + left;
    }
    const out = getDst(outLen, dst);
    const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(out);
    return {
        b,
        o,
        out
    };
}
function validatePCKS(data, pcks5) {
    if (!pcks5) return data;
    const len = data.length;
    if (!len) throw new Error(`aes/pcks5: empty ciphertext not allowed`);
    const lastByte = data[len - 1];
    if (lastByte <= 0 || lastByte > 16) throw new Error(`aes/pcks5: wrong padding byte: ${lastByte}`);
    const out = data.subarray(0, -lastByte);
    for(let i = 0; i < lastByte; i++)if (data[len - i - 1] !== lastByte) throw new Error(`aes/pcks5: wrong padding`);
    return out;
}
function padPCKS(left) {
    const tmp = new Uint8Array(16);
    const tmp32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(tmp);
    tmp.set(left);
    const paddingByte = BLOCK_SIZE - left.length;
    for(let i = BLOCK_SIZE - paddingByte; i < BLOCK_SIZE; i++)tmp[i] = paddingByte;
    return tmp32;
}
const ecb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 16
}, function ecb(key, opts = {}) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key);
    const pcks5 = !opts.disablePadding;
    return {
        encrypt: (plaintext, dst)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(plaintext);
            const { b, o, out: _out } = validateBlockEncrypt(plaintext, pcks5, dst);
            const xk = expandKeyLE(key);
            let i = 0;
            for(; i + 4 <= b.length;){
                const { s0, s1, s2, s3 } = encrypt(xk, b[i + 0], b[i + 1], b[i + 2], b[i + 3]);
                o[i++] = s0, o[i++] = s1, o[i++] = s2, o[i++] = s3;
            }
            if (pcks5) {
                const tmp32 = padPCKS(plaintext.subarray(i * 4));
                const { s0, s1, s2, s3 } = encrypt(xk, tmp32[0], tmp32[1], tmp32[2], tmp32[3]);
                o[i++] = s0, o[i++] = s1, o[i++] = s2, o[i++] = s3;
            }
            xk.fill(0);
            return _out;
        },
        decrypt: (ciphertext, dst)=>{
            validateBlockDecrypt(ciphertext);
            const xk = expandKeyDecLE(key);
            const out = getDst(ciphertext.length, dst);
            const b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(ciphertext);
            const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(out);
            for(let i = 0; i + 4 <= b.length;){
                const { s0, s1, s2, s3 } = decrypt(xk, b[i + 0], b[i + 1], b[i + 2], b[i + 3]);
                o[i++] = s0, o[i++] = s1, o[i++] = s2, o[i++] = s3;
            }
            xk.fill(0);
            return validatePCKS(out, pcks5);
        }
    };
});
const cbc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 16,
    nonceLength: 16
}, function cbc(key, iv, opts = {}) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(iv, 16);
    const pcks5 = !opts.disablePadding;
    return {
        encrypt: (plaintext, dst)=>{
            const xk = expandKeyLE(key);
            const { b, o, out: _out } = validateBlockEncrypt(plaintext, pcks5, dst);
            const n32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(iv);
            // prettier-ignore
            let s0 = n32[0], s1 = n32[1], s2 = n32[2], s3 = n32[3];
            let i = 0;
            for(; i + 4 <= b.length;){
                s0 ^= b[i + 0], s1 ^= b[i + 1], s2 ^= b[i + 2], s3 ^= b[i + 3];
                ({ s0, s1, s2, s3 } = encrypt(xk, s0, s1, s2, s3));
                o[i++] = s0, o[i++] = s1, o[i++] = s2, o[i++] = s3;
            }
            if (pcks5) {
                const tmp32 = padPCKS(plaintext.subarray(i * 4));
                s0 ^= tmp32[0], s1 ^= tmp32[1], s2 ^= tmp32[2], s3 ^= tmp32[3];
                ({ s0, s1, s2, s3 } = encrypt(xk, s0, s1, s2, s3));
                o[i++] = s0, o[i++] = s1, o[i++] = s2, o[i++] = s3;
            }
            xk.fill(0);
            return _out;
        },
        decrypt: (ciphertext, dst)=>{
            validateBlockDecrypt(ciphertext);
            const xk = expandKeyDecLE(key);
            const n32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(iv);
            const out = getDst(ciphertext.length, dst);
            const b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(ciphertext);
            const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(out);
            // prettier-ignore
            let s0 = n32[0], s1 = n32[1], s2 = n32[2], s3 = n32[3];
            for(let i = 0; i + 4 <= b.length;){
                // prettier-ignore
                const ps0 = s0, ps1 = s1, ps2 = s2, ps3 = s3;
                s0 = b[i + 0], s1 = b[i + 1], s2 = b[i + 2], s3 = b[i + 3];
                const { s0: o0, s1: o1, s2: o2, s3: o3 } = decrypt(xk, s0, s1, s2, s3);
                o[i++] = o0 ^ ps0, o[i++] = o1 ^ ps1, o[i++] = o2 ^ ps2, o[i++] = o3 ^ ps3;
            }
            xk.fill(0);
            return validatePCKS(out, pcks5);
        }
    };
});
const cfb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 16,
    nonceLength: 16
}, function cfb(key, iv) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(iv, 16);
    function processCfb(src, isEncrypt, dst) {
        const xk = expandKeyLE(key);
        const srcLen = src.length;
        dst = getDst(srcLen, dst);
        const src32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(src);
        const dst32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(dst);
        const next32 = isEncrypt ? dst32 : src32;
        const n32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(iv);
        // prettier-ignore
        let s0 = n32[0], s1 = n32[1], s2 = n32[2], s3 = n32[3];
        for(let i = 0; i + 4 <= src32.length;){
            const { s0: e0, s1: e1, s2: e2, s3: e3 } = encrypt(xk, s0, s1, s2, s3);
            dst32[i + 0] = src32[i + 0] ^ e0;
            dst32[i + 1] = src32[i + 1] ^ e1;
            dst32[i + 2] = src32[i + 2] ^ e2;
            dst32[i + 3] = src32[i + 3] ^ e3;
            s0 = next32[i++], s1 = next32[i++], s2 = next32[i++], s3 = next32[i++];
        }
        // leftovers (less than block)
        const start = BLOCK_SIZE * Math.floor(src32.length / BLOCK_SIZE32);
        if (start < srcLen) {
            ({ s0, s1, s2, s3 } = encrypt(xk, s0, s1, s2, s3));
            const buf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u8"])(new Uint32Array([
                s0,
                s1,
                s2,
                s3
            ]));
            for(let i = start, pos = 0; i < srcLen; i++, pos++)dst[i] = src[i] ^ buf[pos];
            buf.fill(0);
        }
        xk.fill(0);
        return dst;
    }
    return {
        encrypt: (plaintext, dst)=>processCfb(plaintext, true, dst),
        decrypt: (ciphertext, dst)=>processCfb(ciphertext, false, dst)
    };
});
// TODO: merge with chacha, however gcm has bitLen while chacha has byteLen
function computeTag(fn, isLE, key, data, AAD) {
    const h = fn.create(key, data.length + (AAD?.length || 0));
    if (AAD) h.update(AAD);
    h.update(data);
    const num = new Uint8Array(16);
    const view = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createView"])(num);
    if (AAD) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 0, BigInt(AAD.length * 8), isLE);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 8, BigInt(data.length * 8), isLE);
    h.update(num);
    return h.digest();
}
const gcm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 16,
    nonceLength: 12,
    tagLength: 16
}, function gcm(key, nonce, AAD) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce);
    // Nonce can be pretty much anything (even 1 byte). But smaller nonces less secure.
    if (nonce.length === 0) throw new Error('aes/gcm: empty nonce');
    const tagLength = 16;
    function _computeTag(authKey, tagMask, data) {
        const tag = computeTag(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_polyval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ghash"], false, authKey, data, AAD);
        for(let i = 0; i < tagMask.length; i++)tag[i] ^= tagMask[i];
        return tag;
    }
    function deriveKeys() {
        const xk = expandKeyLE(key);
        const authKey = EMPTY_BLOCK.slice();
        const counter = EMPTY_BLOCK.slice();
        ctr32(xk, false, counter, counter, authKey);
        if (nonce.length === 12) {
            counter.set(nonce);
        } else {
            // Spec (NIST 800-38d) supports variable size nonce.
            // Not supported for now, but can be useful.
            const nonceLen = EMPTY_BLOCK.slice();
            const view = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createView"])(nonceLen);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 8, BigInt(nonce.length * 8), false);
            // ghash(nonce || u64be(0) || u64be(nonceLen*8))
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_polyval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ghash"].create(authKey).update(nonce).update(nonceLen).digestInto(counter);
        }
        const tagMask = ctr32(xk, false, counter, EMPTY_BLOCK);
        return {
            xk,
            authKey,
            counter,
            tagMask
        };
    }
    return {
        encrypt: (plaintext)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(plaintext);
            const { xk, authKey, counter, tagMask } = deriveKeys();
            const out = new Uint8Array(plaintext.length + tagLength);
            ctr32(xk, false, counter, plaintext, out);
            const tag = _computeTag(authKey, tagMask, out.subarray(0, out.length - tagLength));
            out.set(tag, plaintext.length);
            xk.fill(0);
            return out;
        },
        decrypt: (ciphertext)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(ciphertext);
            if (ciphertext.length < tagLength) throw new Error(`aes/gcm: ciphertext less than tagLen (${tagLength})`);
            const { xk, authKey, counter, tagMask } = deriveKeys();
            const data = ciphertext.subarray(0, -tagLength);
            const passedTag = ciphertext.subarray(-tagLength);
            const tag = _computeTag(authKey, tagMask, data);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equalBytes"])(tag, passedTag)) throw new Error('aes/gcm: invalid ghash tag');
            const out = ctr32(xk, false, counter, data);
            authKey.fill(0);
            tagMask.fill(0);
            xk.fill(0);
            return out;
        }
    };
});
const limit = (name, min, max)=>(value)=>{
        if (!Number.isSafeInteger(value) || min > value || value > max) throw new Error(`${name}: invalid value=${value}, must be [${min}..${max}]`);
    };
const siv = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 16,
    nonceLength: 12,
    tagLength: 16
}, function siv(key, nonce, AAD) {
    const tagLength = 16;
    // From RFC 8452: Section 6
    const AAD_LIMIT = limit('AAD', 0, 2 ** 36);
    const PLAIN_LIMIT = limit('plaintext', 0, 2 ** 36);
    const NONCE_LIMIT = limit('nonce', 12, 12);
    const CIPHER_LIMIT = limit('ciphertext', 16, 2 ** 36 + 16);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce);
    NONCE_LIMIT(nonce.length);
    if (AAD) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(AAD);
        AAD_LIMIT(AAD.length);
    }
    function deriveKeys() {
        const len = key.length;
        if (len !== 16 && len !== 24 && len !== 32) throw new Error(`key length must be 16, 24 or 32 bytes, got: ${len} bytes`);
        const xk = expandKeyLE(key);
        const encKey = new Uint8Array(len);
        const authKey = new Uint8Array(16);
        const n32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(nonce);
        // prettier-ignore
        let s0 = 0, s1 = n32[0], s2 = n32[1], s3 = n32[2];
        let counter = 0;
        for (const derivedKey of [
            authKey,
            encKey
        ].map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])){
            const d32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(derivedKey);
            for(let i = 0; i < d32.length; i += 2){
                // aes(u32le(0) || nonce)[:8] || aes(u32le(1) || nonce)[:8] ...
                const { s0: o0, s1: o1 } = encrypt(xk, s0, s1, s2, s3);
                d32[i + 0] = o0;
                d32[i + 1] = o1;
                s0 = ++counter; // increment counter inside state
            }
        }
        xk.fill(0);
        return {
            authKey,
            encKey: expandKeyLE(encKey)
        };
    }
    function _computeTag(encKey, authKey, data) {
        const tag = computeTag(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_polyval$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polyval"], true, authKey, data, AAD);
        // Compute the expected tag by XORing S_s and the nonce, clearing the
        // most significant bit of the last byte and encrypting with the
        // message-encryption key.
        for(let i = 0; i < 12; i++)tag[i] ^= nonce[i];
        tag[15] &= 0x7f; // Clear the highest bit
        // encrypt tag as block
        const t32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(tag);
        // prettier-ignore
        let s0 = t32[0], s1 = t32[1], s2 = t32[2], s3 = t32[3];
        ({ s0, s1, s2, s3 } = encrypt(encKey, s0, s1, s2, s3));
        t32[0] = s0, t32[1] = s1, t32[2] = s2, t32[3] = s3;
        return tag;
    }
    // actual decrypt/encrypt of message.
    function processSiv(encKey, tag, input) {
        let block = tag.slice();
        block[15] |= 0x80; // Force highest bit
        return ctr32(encKey, true, block, input);
    }
    return {
        encrypt: (plaintext)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(plaintext);
            PLAIN_LIMIT(plaintext.length);
            const { encKey, authKey } = deriveKeys();
            const tag = _computeTag(encKey, authKey, plaintext);
            const out = new Uint8Array(plaintext.length + tagLength);
            out.set(tag, plaintext.length);
            out.set(processSiv(encKey, tag, plaintext));
            encKey.fill(0);
            authKey.fill(0);
            return out;
        },
        decrypt: (ciphertext)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(ciphertext);
            CIPHER_LIMIT(ciphertext.length);
            const tag = ciphertext.subarray(-tagLength);
            const { encKey, authKey } = deriveKeys();
            const plaintext = processSiv(encKey, tag, ciphertext.subarray(0, -tagLength));
            const expectedTag = _computeTag(encKey, authKey, plaintext);
            encKey.fill(0);
            authKey.fill(0);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equalBytes"])(tag, expectedTag)) throw new Error('invalid polyval tag');
            return plaintext;
        }
    };
});
function isBytes32(a) {
    return a != null && typeof a === 'object' && (a instanceof Uint32Array || a.constructor.name === 'Uint32Array');
}
function encryptBlock(xk, block) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(block, 16);
    if (!isBytes32(xk)) throw new Error('_encryptBlock accepts result of expandKeyLE');
    const b32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(block);
    let { s0, s1, s2, s3 } = encrypt(xk, b32[0], b32[1], b32[2], b32[3]);
    b32[0] = s0, b32[1] = s1, b32[2] = s2, b32[3] = s3;
    return block;
}
function decryptBlock(xk, block) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(block, 16);
    if (!isBytes32(xk)) throw new Error('_decryptBlock accepts result of expandKeyLE');
    const b32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(block);
    let { s0, s1, s2, s3 } = decrypt(xk, b32[0], b32[1], b32[2], b32[3]);
    b32[0] = s0, b32[1] = s1, b32[2] = s2, b32[3] = s3;
    return block;
}
const unsafe = {
    expandKeyLE,
    expandKeyDecLE,
    encrypt,
    decrypt,
    encryptBlock,
    decryptBlock,
    ctrCounter,
    ctr32
}; //# sourceMappingURL=aes.js.map

})()),
"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_poly1305.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "poly1305": ()=>poly1305,
    "wrapConstructorWithKey": ()=>wrapConstructorWithKey
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
// Poly1305 is a fast and parallel secret-key message-authentication code.
// https://cr.yp.to/mac.html, https://cr.yp.to/mac/poly1305-20050329.pdf
// https://datatracker.ietf.org/doc/html/rfc8439
// Based on Public Domain poly1305-donna https://github.com/floodyberry/poly1305-donna
const u8to16 = (a, i)=>a[i++] & 0xff | (a[i++] & 0xff) << 8;
class Poly1305 {
    constructor(key){
        this.blockLen = 16;
        this.outputLen = 16;
        this.buffer = new Uint8Array(16);
        this.r = new Uint16Array(10);
        this.h = new Uint16Array(10);
        this.pad = new Uint16Array(8);
        this.pos = 0;
        this.finished = false;
        key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(key);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key, 32);
        const t0 = u8to16(key, 0);
        const t1 = u8to16(key, 2);
        const t2 = u8to16(key, 4);
        const t3 = u8to16(key, 6);
        const t4 = u8to16(key, 8);
        const t5 = u8to16(key, 10);
        const t6 = u8to16(key, 12);
        const t7 = u8to16(key, 14);
        // https://github.com/floodyberry/poly1305-donna/blob/e6ad6e091d30d7f4ec2d4f978be1fcfcbce72781/poly1305-donna-16.h#L47
        this.r[0] = t0 & 0x1fff;
        this.r[1] = (t0 >>> 13 | t1 << 3) & 0x1fff;
        this.r[2] = (t1 >>> 10 | t2 << 6) & 0x1f03;
        this.r[3] = (t2 >>> 7 | t3 << 9) & 0x1fff;
        this.r[4] = (t3 >>> 4 | t4 << 12) & 0x00ff;
        this.r[5] = t4 >>> 1 & 0x1ffe;
        this.r[6] = (t4 >>> 14 | t5 << 2) & 0x1fff;
        this.r[7] = (t5 >>> 11 | t6 << 5) & 0x1f81;
        this.r[8] = (t6 >>> 8 | t7 << 8) & 0x1fff;
        this.r[9] = t7 >>> 5 & 0x007f;
        for(let i = 0; i < 8; i++)this.pad[i] = u8to16(key, 16 + 2 * i);
    }
    process(data, offset, isLast = false) {
        const hibit = isLast ? 0 : 1 << 11;
        const { h, r } = this;
        const r0 = r[0];
        const r1 = r[1];
        const r2 = r[2];
        const r3 = r[3];
        const r4 = r[4];
        const r5 = r[5];
        const r6 = r[6];
        const r7 = r[7];
        const r8 = r[8];
        const r9 = r[9];
        const t0 = u8to16(data, offset + 0);
        const t1 = u8to16(data, offset + 2);
        const t2 = u8to16(data, offset + 4);
        const t3 = u8to16(data, offset + 6);
        const t4 = u8to16(data, offset + 8);
        const t5 = u8to16(data, offset + 10);
        const t6 = u8to16(data, offset + 12);
        const t7 = u8to16(data, offset + 14);
        let h0 = h[0] + (t0 & 0x1fff);
        let h1 = h[1] + ((t0 >>> 13 | t1 << 3) & 0x1fff);
        let h2 = h[2] + ((t1 >>> 10 | t2 << 6) & 0x1fff);
        let h3 = h[3] + ((t2 >>> 7 | t3 << 9) & 0x1fff);
        let h4 = h[4] + ((t3 >>> 4 | t4 << 12) & 0x1fff);
        let h5 = h[5] + (t4 >>> 1 & 0x1fff);
        let h6 = h[6] + ((t4 >>> 14 | t5 << 2) & 0x1fff);
        let h7 = h[7] + ((t5 >>> 11 | t6 << 5) & 0x1fff);
        let h8 = h[8] + ((t6 >>> 8 | t7 << 8) & 0x1fff);
        let h9 = h[9] + (t7 >>> 5 | hibit);
        let c = 0;
        let d0 = c + h0 * r0 + h1 * (5 * r9) + h2 * (5 * r8) + h3 * (5 * r7) + h4 * (5 * r6);
        c = d0 >>> 13;
        d0 &= 0x1fff;
        d0 += h5 * (5 * r5) + h6 * (5 * r4) + h7 * (5 * r3) + h8 * (5 * r2) + h9 * (5 * r1);
        c += d0 >>> 13;
        d0 &= 0x1fff;
        let d1 = c + h0 * r1 + h1 * r0 + h2 * (5 * r9) + h3 * (5 * r8) + h4 * (5 * r7);
        c = d1 >>> 13;
        d1 &= 0x1fff;
        d1 += h5 * (5 * r6) + h6 * (5 * r5) + h7 * (5 * r4) + h8 * (5 * r3) + h9 * (5 * r2);
        c += d1 >>> 13;
        d1 &= 0x1fff;
        let d2 = c + h0 * r2 + h1 * r1 + h2 * r0 + h3 * (5 * r9) + h4 * (5 * r8);
        c = d2 >>> 13;
        d2 &= 0x1fff;
        d2 += h5 * (5 * r7) + h6 * (5 * r6) + h7 * (5 * r5) + h8 * (5 * r4) + h9 * (5 * r3);
        c += d2 >>> 13;
        d2 &= 0x1fff;
        let d3 = c + h0 * r3 + h1 * r2 + h2 * r1 + h3 * r0 + h4 * (5 * r9);
        c = d3 >>> 13;
        d3 &= 0x1fff;
        d3 += h5 * (5 * r8) + h6 * (5 * r7) + h7 * (5 * r6) + h8 * (5 * r5) + h9 * (5 * r4);
        c += d3 >>> 13;
        d3 &= 0x1fff;
        let d4 = c + h0 * r4 + h1 * r3 + h2 * r2 + h3 * r1 + h4 * r0;
        c = d4 >>> 13;
        d4 &= 0x1fff;
        d4 += h5 * (5 * r9) + h6 * (5 * r8) + h7 * (5 * r7) + h8 * (5 * r6) + h9 * (5 * r5);
        c += d4 >>> 13;
        d4 &= 0x1fff;
        let d5 = c + h0 * r5 + h1 * r4 + h2 * r3 + h3 * r2 + h4 * r1;
        c = d5 >>> 13;
        d5 &= 0x1fff;
        d5 += h5 * r0 + h6 * (5 * r9) + h7 * (5 * r8) + h8 * (5 * r7) + h9 * (5 * r6);
        c += d5 >>> 13;
        d5 &= 0x1fff;
        let d6 = c + h0 * r6 + h1 * r5 + h2 * r4 + h3 * r3 + h4 * r2;
        c = d6 >>> 13;
        d6 &= 0x1fff;
        d6 += h5 * r1 + h6 * r0 + h7 * (5 * r9) + h8 * (5 * r8) + h9 * (5 * r7);
        c += d6 >>> 13;
        d6 &= 0x1fff;
        let d7 = c + h0 * r7 + h1 * r6 + h2 * r5 + h3 * r4 + h4 * r3;
        c = d7 >>> 13;
        d7 &= 0x1fff;
        d7 += h5 * r2 + h6 * r1 + h7 * r0 + h8 * (5 * r9) + h9 * (5 * r8);
        c += d7 >>> 13;
        d7 &= 0x1fff;
        let d8 = c + h0 * r8 + h1 * r7 + h2 * r6 + h3 * r5 + h4 * r4;
        c = d8 >>> 13;
        d8 &= 0x1fff;
        d8 += h5 * r3 + h6 * r2 + h7 * r1 + h8 * r0 + h9 * (5 * r9);
        c += d8 >>> 13;
        d8 &= 0x1fff;
        let d9 = c + h0 * r9 + h1 * r8 + h2 * r7 + h3 * r6 + h4 * r5;
        c = d9 >>> 13;
        d9 &= 0x1fff;
        d9 += h5 * r4 + h6 * r3 + h7 * r2 + h8 * r1 + h9 * r0;
        c += d9 >>> 13;
        d9 &= 0x1fff;
        c = (c << 2) + c | 0;
        c = c + d0 | 0;
        d0 = c & 0x1fff;
        c = c >>> 13;
        d1 += c;
        h[0] = d0;
        h[1] = d1;
        h[2] = d2;
        h[3] = d3;
        h[4] = d4;
        h[5] = d5;
        h[6] = d6;
        h[7] = d7;
        h[8] = d8;
        h[9] = d9;
    }
    finalize() {
        const { h, pad } = this;
        const g = new Uint16Array(10);
        let c = h[1] >>> 13;
        h[1] &= 0x1fff;
        for(let i = 2; i < 10; i++){
            h[i] += c;
            c = h[i] >>> 13;
            h[i] &= 0x1fff;
        }
        h[0] += c * 5;
        c = h[0] >>> 13;
        h[0] &= 0x1fff;
        h[1] += c;
        c = h[1] >>> 13;
        h[1] &= 0x1fff;
        h[2] += c;
        g[0] = h[0] + 5;
        c = g[0] >>> 13;
        g[0] &= 0x1fff;
        for(let i = 1; i < 10; i++){
            g[i] = h[i] + c;
            c = g[i] >>> 13;
            g[i] &= 0x1fff;
        }
        g[9] -= 1 << 13;
        let mask = (c ^ 1) - 1;
        for(let i = 0; i < 10; i++)g[i] &= mask;
        mask = ~mask;
        for(let i = 0; i < 10; i++)h[i] = h[i] & mask | g[i];
        h[0] = (h[0] | h[1] << 13) & 0xffff;
        h[1] = (h[1] >>> 3 | h[2] << 10) & 0xffff;
        h[2] = (h[2] >>> 6 | h[3] << 7) & 0xffff;
        h[3] = (h[3] >>> 9 | h[4] << 4) & 0xffff;
        h[4] = (h[4] >>> 12 | h[5] << 1 | h[6] << 14) & 0xffff;
        h[5] = (h[6] >>> 2 | h[7] << 11) & 0xffff;
        h[6] = (h[7] >>> 5 | h[8] << 8) & 0xffff;
        h[7] = (h[8] >>> 8 | h[9] << 5) & 0xffff;
        let f = h[0] + pad[0];
        h[0] = f & 0xffff;
        for(let i = 1; i < 8; i++){
            f = (h[i] + pad[i] | 0) + (f >>> 16) | 0;
            h[i] = f & 0xffff;
        }
    }
    update(data) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exists"])(this);
        const { buffer, blockLen } = this;
        data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(data);
        const len = data.length;
        for(let pos = 0; pos < len;){
            const take = Math.min(blockLen - this.pos, len - pos);
            // Fast path: we have at least one block in input
            if (take === blockLen) {
                for(; blockLen <= len - pos; pos += blockLen)this.process(data, pos);
                continue;
            }
            buffer.set(data.subarray(pos, pos + take), this.pos);
            this.pos += take;
            pos += take;
            if (this.pos === blockLen) {
                this.process(buffer, 0, false);
                this.pos = 0;
            }
        }
        return this;
    }
    destroy() {
        this.h.fill(0);
        this.r.fill(0);
        this.buffer.fill(0);
        this.pad.fill(0);
    }
    digestInto(out) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exists"])(this);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["output"])(out, this);
        this.finished = true;
        const { buffer, h } = this;
        let { pos } = this;
        if (pos) {
            buffer[pos++] = 1;
            // buffer.subarray(pos).fill(0);
            for(; pos < 16; pos++)buffer[pos] = 0;
            this.process(buffer, 0, true);
        }
        this.finalize();
        let opos = 0;
        for(let i = 0; i < 8; i++){
            out[opos++] = h[i] >>> 0;
            out[opos++] = h[i] >>> 8;
        }
        return out;
    }
    digest() {
        const { buffer, outputLen } = this;
        this.digestInto(buffer);
        const res = buffer.slice(0, outputLen);
        this.destroy();
        return res;
    }
}
function wrapConstructorWithKey(hashCons) {
    const hashC = (msg, key)=>hashCons(key).update((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(msg)).digest();
    const tmp = hashCons(new Uint8Array(32));
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (key)=>hashCons(key);
    return hashC;
}
const poly1305 = wrapConstructorWithKey((key)=>new Poly1305(key)); //# sourceMappingURL=_poly1305.js.map

})()),
"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_arx.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

// Basic utils for ARX (add-rotate-xor) salsa and chacha ciphers.
__turbopack_esm__({
    "createCipher": ()=>createCipher,
    "rotl": ()=>rotl,
    "sigma": ()=>sigma
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
/*
RFC8439 requires multi-step cipher stream, where
authKey starts with counter: 0, actual msg with counter: 1.

For this, we need a way to re-use nonce / counter:

    const counter = new Uint8Array(4);
    chacha(..., counter, ...); // counter is now 1
    chacha(..., counter, ...); // counter is now 2

This is complicated:

- 32-bit counters are enough, no need for 64-bit: max ArrayBuffer size in JS is 4GB
- Original papers don't allow mutating counters
- Counter overflow is undefined [^1]
- Idea A: allow providing (nonce | counter) instead of just nonce, re-use it
- Caveat: Cannot be re-used through all cases:
- * chacha has (counter | nonce)
- * xchacha has (nonce16 | counter | nonce16)
- Idea B: separate nonce / counter and provide separate API for counter re-use
- Caveat: there are different counter sizes depending on an algorithm.
- salsa & chacha also differ in structures of key & sigma:
  salsa20:      s[0] | k(4) | s[1] | nonce(2) | ctr(2) | s[2] | k(4) | s[3]
  chacha:       s(4) | k(8) | ctr(1) | nonce(3)
  chacha20orig: s(4) | k(8) | ctr(2) | nonce(2)
- Idea C: helper method such as `setSalsaState(key, nonce, sigma, data)`
- Caveat: we can't re-use counter array

xchacha [^2] uses the subkey and remaining 8 byte nonce with ChaCha20 as normal
(prefixed by 4 NUL bytes, since [RFC8439] specifies a 12-byte nonce).

[^1]: https://mailarchive.ietf.org/arch/msg/cfrg/gsOnTJzcbgG6OqD8Sc0GO5aR_tU/
[^2]: https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha#appendix-A.2
*/ // We can't make top-level var depend on utils.utf8ToBytes
// because it's not present in all envs. Creating a similar fn here
const _utf8ToBytes = (str)=>Uint8Array.from(str.split('').map((c)=>c.charCodeAt(0)));
const sigma16 = _utf8ToBytes('expand 16-byte k');
const sigma32 = _utf8ToBytes('expand 32-byte k');
const sigma16_32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(sigma16);
const sigma32_32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(sigma32);
const sigma = sigma32_32.slice();
function rotl(a, b) {
    return a << b | a >>> 32 - b;
}
// Is byte array aligned to 4 byte offset (u32)?
function isAligned32(b) {
    return b.byteOffset % 4 === 0;
}
// Salsa and Chacha block length is always 512-bit
const BLOCK_LEN = 64;
const BLOCK_LEN32 = 16;
// new Uint32Array([2**32])   // => Uint32Array(1) [ 0 ]
// new Uint32Array([2**32-1]) // => Uint32Array(1) [ 4294967295 ]
const MAX_COUNTER = 2 ** 32 - 1;
const U32_EMPTY = new Uint32Array();
function runCipher(core, sigma, key, nonce, data, output, counter, rounds) {
    const len = data.length;
    const block = new Uint8Array(BLOCK_LEN);
    const b32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(block);
    // Make sure that buffers aligned to 4 bytes
    const isAligned = isAligned32(data) && isAligned32(output);
    const d32 = isAligned ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(data) : U32_EMPTY;
    const o32 = isAligned ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(output) : U32_EMPTY;
    for(let pos = 0; pos < len; counter++){
        core(sigma, key, nonce, b32, counter, rounds);
        if (counter >= MAX_COUNTER) throw new Error('arx: counter overflow');
        const take = Math.min(BLOCK_LEN, len - pos);
        // aligned to 4 bytes
        if (isAligned && take === BLOCK_LEN) {
            const pos32 = pos / 4;
            if (pos % 4 !== 0) throw new Error('arx: invalid block position');
            for(let j = 0, posj; j < BLOCK_LEN32; j++){
                posj = pos32 + j;
                o32[posj] = d32[posj] ^ b32[j];
            }
            pos += BLOCK_LEN;
            continue;
        }
        for(let j = 0, posj; j < take; j++){
            posj = pos + j;
            output[posj] = data[posj] ^ block[j];
        }
        pos += take;
    }
}
function createCipher(core, opts) {
    const { allowShortKeys, extendNonceFn, counterLength, counterRight, rounds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkOpts"])({
        allowShortKeys: false,
        counterLength: 8,
        counterRight: false,
        rounds: 20
    }, opts);
    if (typeof core !== 'function') throw new Error('core must be a function');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["number"])(counterLength);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["number"])(rounds);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bool"])(counterRight);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bool"])(allowShortKeys);
    return (key, nonce, data, output, counter = 0)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(data);
        const len = data.length;
        if (!output) output = new Uint8Array(len);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(output);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["number"])(counter);
        if (counter < 0 || counter >= MAX_COUNTER) throw new Error('arx: counter overflow');
        if (output.length < len) throw new Error(`arx: output (${output.length}) is shorter than data (${len})`);
        const toClean = [];
        // Key & sigma
        // key=16 -> sigma16, k=key|key
        // key=32 -> sigma32, k=key
        let l = key.length, k, sigma;
        if (l === 32) {
            k = key.slice();
            toClean.push(k);
            sigma = sigma32_32;
        } else if (l === 16 && allowShortKeys) {
            k = new Uint8Array(32);
            k.set(key);
            k.set(key, 16);
            sigma = sigma16_32;
            toClean.push(k);
        } else {
            throw new Error(`arx: invalid 32-byte key, got length=${l}`);
        }
        // Nonce
        // salsa20:      8   (8-byte counter)
        // chacha20orig: 8   (8-byte counter)
        // chacha20:     12  (4-byte counter)
        // xsalsa20:     24  (16 -> hsalsa,  8 -> old nonce)
        // xchacha20:    24  (16 -> hchacha, 8 -> old nonce)
        // Align nonce to 4 bytes
        if (!isAligned32(nonce)) {
            nonce = nonce.slice();
            toClean.push(nonce);
        }
        const k32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(k);
        // hsalsa & hchacha: handle extended nonce
        if (extendNonceFn) {
            if (nonce.length !== 24) throw new Error(`arx: extended nonce must be 24 bytes`);
            extendNonceFn(sigma, k32, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(nonce.subarray(0, 16)), k32);
            nonce = nonce.subarray(16);
        }
        // Handle nonce counter
        const nonceNcLen = 16 - counterLength;
        if (nonceNcLen !== nonce.length) throw new Error(`arx: nonce must be ${nonceNcLen} or 16 bytes`);
        // Pad counter when nonce is 64 bit
        if (nonceNcLen !== 12) {
            const nc = new Uint8Array(12);
            nc.set(nonce, counterRight ? 0 : 12 - nonce.length);
            nonce = nc;
            toClean.push(nonce);
        }
        const n32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(nonce);
        runCipher(core, sigma, k32, n32, data, output, counter, rounds);
        while(toClean.length > 0)toClean.pop().fill(0);
        return output;
    };
} //# sourceMappingURL=_arx.js.map

})()),
"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/chacha.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

// prettier-ignore
__turbopack_esm__({
    "_poly1305_aead": ()=>_poly1305_aead,
    "chacha12": ()=>chacha12,
    "chacha20": ()=>chacha20,
    "chacha20orig": ()=>chacha20orig,
    "chacha20poly1305": ()=>chacha20poly1305,
    "chacha8": ()=>chacha8,
    "hchacha": ()=>hchacha,
    "xchacha20": ()=>xchacha20,
    "xchacha20poly1305": ()=>xchacha20poly1305
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_poly1305$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_poly1305.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_arx.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
// ChaCha20 stream cipher was released in 2008. ChaCha aims to increase
// the diffusion per round, but had slightly less cryptanalysis.
// https://cr.yp.to/chacha.html, http://cr.yp.to/chacha/chacha-20080128.pdf
/**
 * ChaCha core function.
 */ // prettier-ignore
function chachaCore(s, k, n, out, cnt, rounds = 20) {
    let y00 = s[0], y01 = s[1], y02 = s[2], y03 = s[3], y04 = k[0], y05 = k[1], y06 = k[2], y07 = k[3], y08 = k[4], y09 = k[5], y10 = k[6], y11 = k[7], y12 = cnt, y13 = n[0], y14 = n[1], y15 = n[2]; // Counter  Counter	Nonce   Nonce
    // Save state to temporary variables
    let x00 = y00, x01 = y01, x02 = y02, x03 = y03, x04 = y04, x05 = y05, x06 = y06, x07 = y07, x08 = y08, x09 = y09, x10 = y10, x11 = y11, x12 = y12, x13 = y13, x14 = y14, x15 = y15;
    for(let r = 0; r < rounds; r += 2){
        x00 = x00 + x04 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x00, 16);
        x08 = x08 + x12 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x08, 12);
        x00 = x00 + x04 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x00, 8);
        x08 = x08 + x12 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x08, 7);
        x01 = x01 + x05 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x01, 16);
        x09 = x09 + x13 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x09, 12);
        x01 = x01 + x05 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x01, 8);
        x09 = x09 + x13 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x09, 7);
        x02 = x02 + x06 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x02, 16);
        x10 = x10 + x14 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x10, 12);
        x02 = x02 + x06 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x02, 8);
        x10 = x10 + x14 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x10, 7);
        x03 = x03 + x07 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x03, 16);
        x11 = x11 + x15 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x11, 12);
        x03 = x03 + x07 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x03, 8);
        x11 = x11 + x15 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x11, 7);
        x00 = x00 + x05 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x00, 16);
        x10 = x10 + x15 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x10, 12);
        x00 = x00 + x05 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x00, 8);
        x10 = x10 + x15 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x10, 7);
        x01 = x01 + x06 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x01, 16);
        x11 = x11 + x12 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x11, 12);
        x01 = x01 + x06 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x01, 8);
        x11 = x11 + x12 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x11, 7);
        x02 = x02 + x07 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x02, 16);
        x08 = x08 + x13 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x08, 12);
        x02 = x02 + x07 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x02, 8);
        x08 = x08 + x13 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x08, 7);
        x03 = x03 + x04 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x03, 16);
        x09 = x09 + x14 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x09, 12);
        x03 = x03 + x04 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x03, 8);
        x09 = x09 + x14 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x09, 7);
    }
    // Write output
    let oi = 0;
    out[oi++] = y00 + x00 | 0;
    out[oi++] = y01 + x01 | 0;
    out[oi++] = y02 + x02 | 0;
    out[oi++] = y03 + x03 | 0;
    out[oi++] = y04 + x04 | 0;
    out[oi++] = y05 + x05 | 0;
    out[oi++] = y06 + x06 | 0;
    out[oi++] = y07 + x07 | 0;
    out[oi++] = y08 + x08 | 0;
    out[oi++] = y09 + x09 | 0;
    out[oi++] = y10 + x10 | 0;
    out[oi++] = y11 + x11 | 0;
    out[oi++] = y12 + x12 | 0;
    out[oi++] = y13 + x13 | 0;
    out[oi++] = y14 + x14 | 0;
    out[oi++] = y15 + x15 | 0;
}
function hchacha(s, k, i, o32) {
    let x00 = s[0], x01 = s[1], x02 = s[2], x03 = s[3], x04 = k[0], x05 = k[1], x06 = k[2], x07 = k[3], x08 = k[4], x09 = k[5], x10 = k[6], x11 = k[7], x12 = i[0], x13 = i[1], x14 = i[2], x15 = i[3];
    for(let r = 0; r < 20; r += 2){
        x00 = x00 + x04 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x00, 16);
        x08 = x08 + x12 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x08, 12);
        x00 = x00 + x04 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x00, 8);
        x08 = x08 + x12 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x08, 7);
        x01 = x01 + x05 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x01, 16);
        x09 = x09 + x13 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x09, 12);
        x01 = x01 + x05 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x01, 8);
        x09 = x09 + x13 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x09, 7);
        x02 = x02 + x06 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x02, 16);
        x10 = x10 + x14 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x10, 12);
        x02 = x02 + x06 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x02, 8);
        x10 = x10 + x14 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x10, 7);
        x03 = x03 + x07 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x03, 16);
        x11 = x11 + x15 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x11, 12);
        x03 = x03 + x07 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x03, 8);
        x11 = x11 + x15 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x11, 7);
        x00 = x00 + x05 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x00, 16);
        x10 = x10 + x15 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x10, 12);
        x00 = x00 + x05 | 0;
        x15 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x15 ^ x00, 8);
        x10 = x10 + x15 | 0;
        x05 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x05 ^ x10, 7);
        x01 = x01 + x06 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x01, 16);
        x11 = x11 + x12 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x11, 12);
        x01 = x01 + x06 | 0;
        x12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x12 ^ x01, 8);
        x11 = x11 + x12 | 0;
        x06 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x06 ^ x11, 7);
        x02 = x02 + x07 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x02, 16);
        x08 = x08 + x13 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x08, 12);
        x02 = x02 + x07 | 0;
        x13 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x13 ^ x02, 8);
        x08 = x08 + x13 | 0;
        x07 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x07 ^ x08, 7);
        x03 = x03 + x04 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x03, 16);
        x09 = x09 + x14 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x09, 12);
        x03 = x03 + x04 | 0;
        x14 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x14 ^ x03, 8);
        x09 = x09 + x14 | 0;
        x04 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotl"])(x04 ^ x09, 7);
    }
    let oi = 0;
    o32[oi++] = x00;
    o32[oi++] = x01;
    o32[oi++] = x02;
    o32[oi++] = x03;
    o32[oi++] = x12;
    o32[oi++] = x13;
    o32[oi++] = x14;
    o32[oi++] = x15;
}
const chacha20orig = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCipher"])(chachaCore, {
    counterRight: false,
    counterLength: 8,
    allowShortKeys: true
});
const chacha20 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCipher"])(chachaCore, {
    counterRight: false,
    counterLength: 4,
    allowShortKeys: false
});
const xchacha20 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCipher"])(chachaCore, {
    counterRight: false,
    counterLength: 8,
    extendNonceFn: hchacha,
    allowShortKeys: false
});
const chacha8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCipher"])(chachaCore, {
    counterRight: false,
    counterLength: 4,
    rounds: 8
});
const chacha12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_arx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCipher"])(chachaCore, {
    counterRight: false,
    counterLength: 4,
    rounds: 12
});
const ZEROS16 = /* @__PURE__ */ new Uint8Array(16);
// Pad to digest size with zeros
const updatePadded = (h, msg)=>{
    h.update(msg);
    const left = msg.length % 16;
    if (left) h.update(ZEROS16.subarray(left));
};
const ZEROS32 = /* @__PURE__ */ new Uint8Array(32);
function computeTag(fn, key, nonce, data, AAD) {
    const authKey = fn(key, nonce, ZEROS32);
    const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_poly1305$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["poly1305"].create(authKey);
    if (AAD) updatePadded(h, AAD);
    updatePadded(h, data);
    const num = new Uint8Array(16);
    const view = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createView"])(num);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 0, BigInt(AAD ? AAD.length : 0), true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 8, BigInt(data.length), true);
    h.update(num);
    const res = h.digest();
    authKey.fill(0);
    return res;
}
const _poly1305_aead = (xorStream)=>(key, nonce, AAD)=>{
        const tagLength = 16;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(key, 32);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(nonce);
        return {
            encrypt: (plaintext, output)=>{
                const plength = plaintext.length;
                const clength = plength + tagLength;
                if (output) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(output, clength);
                } else {
                    output = new Uint8Array(clength);
                }
                xorStream(key, nonce, plaintext, output, 1);
                const tag = computeTag(xorStream, key, nonce, output.subarray(0, -tagLength), AAD);
                output.set(tag, plength); // append tag
                return output;
            },
            decrypt: (ciphertext, output)=>{
                const clength = ciphertext.length;
                const plength = clength - tagLength;
                if (clength < tagLength) throw new Error(`encrypted data must be at least ${tagLength} bytes`);
                if (output) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytes"])(output, plength);
                } else {
                    output = new Uint8Array(plength);
                }
                const data = ciphertext.subarray(0, -tagLength);
                const passedTag = ciphertext.subarray(-tagLength);
                const tag = computeTag(xorStream, key, nonce, data, AAD);
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equalBytes"])(passedTag, tag)) throw new Error('invalid tag');
                xorStream(key, nonce, data, output, 1);
                return output;
            }
        };
    };
const chacha20poly1305 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 64,
    nonceLength: 12,
    tagLength: 16
}, _poly1305_aead(chacha20));
const xchacha20poly1305 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapCipher"])({
    blockSize: 64,
    nonceLength: 24,
    tagLength: 16
}, _poly1305_aead(xchacha20)); //# sourceMappingURL=chacha.js.map

})()),
"[project]/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

/*! noble-ciphers - MIT License (c) 2023 Paul Miller (paulmillr.com) */ __turbopack_esm__({
    "Hash": ()=>Hash,
    "asyncLoop": ()=>asyncLoop,
    "bytesToHex": ()=>bytesToHex,
    "bytesToUtf8": ()=>bytesToUtf8,
    "checkOpts": ()=>checkOpts,
    "concatBytes": ()=>concatBytes,
    "createView": ()=>createView,
    "ensureBytes": ()=>ensureBytes,
    "equalBytes": ()=>equalBytes,
    "hexToBytes": ()=>hexToBytes,
    "isLE": ()=>isLE,
    "nextTick": ()=>nextTick,
    "setBigUint64": ()=>setBigUint64,
    "toBytes": ()=>toBytes,
    "u16": ()=>u16,
    "u32": ()=>u32,
    "u8": ()=>u8,
    "utf8ToBytes": ()=>utf8ToBytes
});
const u8a = (a)=>a instanceof Uint8Array;
const u8 = (arr)=>new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
const u16 = (arr)=>new Uint16Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 2));
const u32 = (arr)=>new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
const createView = (arr)=>new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
const isLE = new Uint8Array(new Uint32Array([
    0x11223344
]).buffer)[0] === 0x44;
if (!isLE) throw new Error('Non little-endian hardware is not supported');
const hexes = /* @__PURE__ */ Array.from({
    length: 256
}, (_, i)=>i.toString(16).padStart(2, '0'));
function bytesToHex(bytes) {
    if (!u8a(bytes)) throw new Error('Uint8Array expected');
    // pre-caching improves the speed 6x
    let hex = '';
    for(let i = 0; i < bytes.length; i++){
        hex += hexes[bytes[i]];
    }
    return hex;
}
function hexToBytes(hex) {
    if (typeof hex !== 'string') throw new Error('hex string expected, got ' + typeof hex);
    const len = hex.length;
    if (len % 2) throw new Error('padded hex string expected, got unpadded hex of length ' + len);
    const array = new Uint8Array(len / 2);
    for(let i = 0; i < array.length; i++){
        const j = i * 2;
        const hexByte = hex.slice(j, j + 2);
        const byte = Number.parseInt(hexByte, 16);
        if (Number.isNaN(byte) || byte < 0) throw new Error('Invalid byte sequence');
        array[i] = byte;
    }
    return array;
}
const nextTick = async ()=>{};
async function asyncLoop(iters, tick, cb) {
    let ts = Date.now();
    for(let i = 0; i < iters; i++){
        cb(i);
        // Date.now() is not monotonic, so in case if clock goes backwards we return return control too
        const diff = Date.now() - ts;
        if (diff >= 0 && diff < tick) continue;
        await nextTick();
        ts += diff;
    }
}
function utf8ToBytes(str) {
    if (typeof str !== 'string') throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
}
function bytesToUtf8(bytes) {
    return new TextDecoder().decode(bytes);
}
function toBytes(data) {
    if (typeof data === 'string') data = utf8ToBytes(data);
    if (!u8a(data)) throw new Error(`expected Uint8Array, got ${typeof data}`);
    return data;
}
function concatBytes(...arrays) {
    const r = new Uint8Array(arrays.reduce((sum, a)=>sum + a.length, 0));
    let pad = 0; // walk through each item, ensure they have proper type
    arrays.forEach((a)=>{
        if (!u8a(a)) throw new Error('Uint8Array expected');
        r.set(a, pad);
        pad += a.length;
    });
    return r;
}
// Check if object doens't have custom constructor (like Uint8Array/Array)
const isPlainObject = (obj)=>Object.prototype.toString.call(obj) === '[object Object]' && obj.constructor === Object;
function checkOpts(defaults, opts) {
    if (opts !== undefined && (typeof opts !== 'object' || !isPlainObject(opts))) throw new Error('options must be object or undefined');
    const merged = Object.assign(defaults, opts);
    return merged;
}
function ensureBytes(b, len) {
    if (!(b instanceof Uint8Array)) throw new Error('Uint8Array expected');
    if (typeof len === 'number') {
        if (b.length !== len) throw new Error(`Uint8Array length ${len} expected`);
    }
}
function equalBytes(a, b) {
    // Should not happen
    if (a.length !== b.length) throw new Error('equalBytes: Different size of Uint8Arrays');
    let isSame = true;
    for(let i = 0; i < a.length; i++)isSame && (isSame = a[i] === b[i]); // Lets hope JIT won't optimize away.
    return isSame;
}
class Hash {
}
function setBigUint64(view, byteOffset, value, isLE) {
    if (typeof view.setBigUint64 === 'function') return view.setBigUint64(byteOffset, value, isLE);
    const _32n = BigInt(32);
    const _u32_max = BigInt(0xffffffff);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE ? 4 : 0;
    const l = isLE ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE);
    view.setUint32(byteOffset + l, wl, isLE);
} //# sourceMappingURL=utils.js.map

})()),
"[project]/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "bool": ()=>bool,
    "bytes": ()=>bytes,
    "default": ()=>__TURBOPACK__default__export__,
    "exists": ()=>exists,
    "hash": ()=>hash,
    "number": ()=>number,
    "output": ()=>output
});
function number(n) {
    if (!Number.isSafeInteger(n) || n < 0) throw new Error(`Wrong positive integer: ${n}`);
}
function bool(b) {
    if (typeof b !== 'boolean') throw new Error(`Expected boolean, not ${b}`);
}
function bytes(b, ...lengths) {
    if (!(b instanceof Uint8Array)) throw new Error('Expected Uint8Array');
    if (lengths.length > 0 && !lengths.includes(b.length)) throw new Error(`Expected Uint8Array of length ${lengths}, not of length=${b.length}`);
}
function hash(hash) {
    if (typeof hash !== 'function' || typeof hash.create !== 'function') throw new Error('hash must be wrapped by utils.wrapConstructor');
    number(hash.outputLen);
    number(hash.blockLen);
}
function exists(instance, checkFinished = true) {
    if (instance.destroyed) throw new Error('Hash instance has been destroyed');
    if (checkFinished && instance.finished) throw new Error('Hash#digest() has already been called');
}
function output(out, instance) {
    bytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
        throw new Error(`digestInto() expects output buffer of length at least ${min}`);
    }
}
;
const assert = {
    number,
    bool,
    bytes,
    hash,
    exists,
    output
};
const __TURBOPACK__default__export__ = assert;
 //# sourceMappingURL=_assert.js.map

})()),
"[project]/node_modules/@noble/ciphers/esm/_poly1305.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "poly1305": ()=>poly1305,
    "wrapConstructorWithKey": ()=>wrapConstructorWithKey
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
// Poly1305 is a fast and parallel secret-key message-authentication code.
// https://cr.yp.to/mac.html, https://cr.yp.to/mac/poly1305-20050329.pdf
// https://datatracker.ietf.org/doc/html/rfc8439
// Based on Public Domain poly1305-donna https://github.com/floodyberry/poly1305-donna
const u8to16 = (a, i)=>a[i++] & 0xff | (a[i++] & 0xff) << 8;
class Poly1305 {
    constructor(key){
        this.blockLen = 16;
        this.outputLen = 16;
        this.buffer = new Uint8Array(16);
        this.r = new Uint16Array(10);
        this.h = new Uint16Array(10);
        this.pad = new Uint16Array(8);
        this.pos = 0;
        this.finished = false;
        key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(key);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(key, 32);
        const t0 = u8to16(key, 0);
        const t1 = u8to16(key, 2);
        const t2 = u8to16(key, 4);
        const t3 = u8to16(key, 6);
        const t4 = u8to16(key, 8);
        const t5 = u8to16(key, 10);
        const t6 = u8to16(key, 12);
        const t7 = u8to16(key, 14);
        // https://github.com/floodyberry/poly1305-donna/blob/e6ad6e091d30d7f4ec2d4f978be1fcfcbce72781/poly1305-donna-16.h#L47
        this.r[0] = t0 & 0x1fff;
        this.r[1] = (t0 >>> 13 | t1 << 3) & 0x1fff;
        this.r[2] = (t1 >>> 10 | t2 << 6) & 0x1f03;
        this.r[3] = (t2 >>> 7 | t3 << 9) & 0x1fff;
        this.r[4] = (t3 >>> 4 | t4 << 12) & 0x00ff;
        this.r[5] = t4 >>> 1 & 0x1ffe;
        this.r[6] = (t4 >>> 14 | t5 << 2) & 0x1fff;
        this.r[7] = (t5 >>> 11 | t6 << 5) & 0x1f81;
        this.r[8] = (t6 >>> 8 | t7 << 8) & 0x1fff;
        this.r[9] = t7 >>> 5 & 0x007f;
        for(let i = 0; i < 8; i++)this.pad[i] = u8to16(key, 16 + 2 * i);
    }
    process(data, offset, isLast = false) {
        const hibit = isLast ? 0 : 1 << 11;
        const { h, r } = this;
        const r0 = r[0];
        const r1 = r[1];
        const r2 = r[2];
        const r3 = r[3];
        const r4 = r[4];
        const r5 = r[5];
        const r6 = r[6];
        const r7 = r[7];
        const r8 = r[8];
        const r9 = r[9];
        const t0 = u8to16(data, offset + 0);
        const t1 = u8to16(data, offset + 2);
        const t2 = u8to16(data, offset + 4);
        const t3 = u8to16(data, offset + 6);
        const t4 = u8to16(data, offset + 8);
        const t5 = u8to16(data, offset + 10);
        const t6 = u8to16(data, offset + 12);
        const t7 = u8to16(data, offset + 14);
        let h0 = h[0] + (t0 & 0x1fff);
        let h1 = h[1] + ((t0 >>> 13 | t1 << 3) & 0x1fff);
        let h2 = h[2] + ((t1 >>> 10 | t2 << 6) & 0x1fff);
        let h3 = h[3] + ((t2 >>> 7 | t3 << 9) & 0x1fff);
        let h4 = h[4] + ((t3 >>> 4 | t4 << 12) & 0x1fff);
        let h5 = h[5] + (t4 >>> 1 & 0x1fff);
        let h6 = h[6] + ((t4 >>> 14 | t5 << 2) & 0x1fff);
        let h7 = h[7] + ((t5 >>> 11 | t6 << 5) & 0x1fff);
        let h8 = h[8] + ((t6 >>> 8 | t7 << 8) & 0x1fff);
        let h9 = h[9] + (t7 >>> 5 | hibit);
        let c = 0;
        let d0 = c + h0 * r0 + h1 * (5 * r9) + h2 * (5 * r8) + h3 * (5 * r7) + h4 * (5 * r6);
        c = d0 >>> 13;
        d0 &= 0x1fff;
        d0 += h5 * (5 * r5) + h6 * (5 * r4) + h7 * (5 * r3) + h8 * (5 * r2) + h9 * (5 * r1);
        c += d0 >>> 13;
        d0 &= 0x1fff;
        let d1 = c + h0 * r1 + h1 * r0 + h2 * (5 * r9) + h3 * (5 * r8) + h4 * (5 * r7);
        c = d1 >>> 13;
        d1 &= 0x1fff;
        d1 += h5 * (5 * r6) + h6 * (5 * r5) + h7 * (5 * r4) + h8 * (5 * r3) + h9 * (5 * r2);
        c += d1 >>> 13;
        d1 &= 0x1fff;
        let d2 = c + h0 * r2 + h1 * r1 + h2 * r0 + h3 * (5 * r9) + h4 * (5 * r8);
        c = d2 >>> 13;
        d2 &= 0x1fff;
        d2 += h5 * (5 * r7) + h6 * (5 * r6) + h7 * (5 * r5) + h8 * (5 * r4) + h9 * (5 * r3);
        c += d2 >>> 13;
        d2 &= 0x1fff;
        let d3 = c + h0 * r3 + h1 * r2 + h2 * r1 + h3 * r0 + h4 * (5 * r9);
        c = d3 >>> 13;
        d3 &= 0x1fff;
        d3 += h5 * (5 * r8) + h6 * (5 * r7) + h7 * (5 * r6) + h8 * (5 * r5) + h9 * (5 * r4);
        c += d3 >>> 13;
        d3 &= 0x1fff;
        let d4 = c + h0 * r4 + h1 * r3 + h2 * r2 + h3 * r1 + h4 * r0;
        c = d4 >>> 13;
        d4 &= 0x1fff;
        d4 += h5 * (5 * r9) + h6 * (5 * r8) + h7 * (5 * r7) + h8 * (5 * r6) + h9 * (5 * r5);
        c += d4 >>> 13;
        d4 &= 0x1fff;
        let d5 = c + h0 * r5 + h1 * r4 + h2 * r3 + h3 * r2 + h4 * r1;
        c = d5 >>> 13;
        d5 &= 0x1fff;
        d5 += h5 * r0 + h6 * (5 * r9) + h7 * (5 * r8) + h8 * (5 * r7) + h9 * (5 * r6);
        c += d5 >>> 13;
        d5 &= 0x1fff;
        let d6 = c + h0 * r6 + h1 * r5 + h2 * r4 + h3 * r3 + h4 * r2;
        c = d6 >>> 13;
        d6 &= 0x1fff;
        d6 += h5 * r1 + h6 * r0 + h7 * (5 * r9) + h8 * (5 * r8) + h9 * (5 * r7);
        c += d6 >>> 13;
        d6 &= 0x1fff;
        let d7 = c + h0 * r7 + h1 * r6 + h2 * r5 + h3 * r4 + h4 * r3;
        c = d7 >>> 13;
        d7 &= 0x1fff;
        d7 += h5 * r2 + h6 * r1 + h7 * r0 + h8 * (5 * r9) + h9 * (5 * r8);
        c += d7 >>> 13;
        d7 &= 0x1fff;
        let d8 = c + h0 * r8 + h1 * r7 + h2 * r6 + h3 * r5 + h4 * r4;
        c = d8 >>> 13;
        d8 &= 0x1fff;
        d8 += h5 * r3 + h6 * r2 + h7 * r1 + h8 * r0 + h9 * (5 * r9);
        c += d8 >>> 13;
        d8 &= 0x1fff;
        let d9 = c + h0 * r9 + h1 * r8 + h2 * r7 + h3 * r6 + h4 * r5;
        c = d9 >>> 13;
        d9 &= 0x1fff;
        d9 += h5 * r4 + h6 * r3 + h7 * r2 + h8 * r1 + h9 * r0;
        c += d9 >>> 13;
        d9 &= 0x1fff;
        c = (c << 2) + c | 0;
        c = c + d0 | 0;
        d0 = c & 0x1fff;
        c = c >>> 13;
        d1 += c;
        h[0] = d0;
        h[1] = d1;
        h[2] = d2;
        h[3] = d3;
        h[4] = d4;
        h[5] = d5;
        h[6] = d6;
        h[7] = d7;
        h[8] = d8;
        h[9] = d9;
    }
    finalize() {
        const { h, pad } = this;
        const g = new Uint16Array(10);
        let c = h[1] >>> 13;
        h[1] &= 0x1fff;
        for(let i = 2; i < 10; i++){
            h[i] += c;
            c = h[i] >>> 13;
            h[i] &= 0x1fff;
        }
        h[0] += c * 5;
        c = h[0] >>> 13;
        h[0] &= 0x1fff;
        h[1] += c;
        c = h[1] >>> 13;
        h[1] &= 0x1fff;
        h[2] += c;
        g[0] = h[0] + 5;
        c = g[0] >>> 13;
        g[0] &= 0x1fff;
        for(let i = 1; i < 10; i++){
            g[i] = h[i] + c;
            c = g[i] >>> 13;
            g[i] &= 0x1fff;
        }
        g[9] -= 1 << 13;
        let mask = (c ^ 1) - 1;
        for(let i = 0; i < 10; i++)g[i] &= mask;
        mask = ~mask;
        for(let i = 0; i < 10; i++)h[i] = h[i] & mask | g[i];
        h[0] = (h[0] | h[1] << 13) & 0xffff;
        h[1] = (h[1] >>> 3 | h[2] << 10) & 0xffff;
        h[2] = (h[2] >>> 6 | h[3] << 7) & 0xffff;
        h[3] = (h[3] >>> 9 | h[4] << 4) & 0xffff;
        h[4] = (h[4] >>> 12 | h[5] << 1 | h[6] << 14) & 0xffff;
        h[5] = (h[6] >>> 2 | h[7] << 11) & 0xffff;
        h[6] = (h[7] >>> 5 | h[8] << 8) & 0xffff;
        h[7] = (h[8] >>> 8 | h[9] << 5) & 0xffff;
        let f = h[0] + pad[0];
        h[0] = f & 0xffff;
        for(let i = 1; i < 8; i++){
            f = (h[i] + pad[i] | 0) + (f >>> 16) | 0;
            h[i] = f & 0xffff;
        }
    }
    update(data) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].exists(this);
        const { buffer, blockLen } = this;
        data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(data);
        const len = data.length;
        for(let pos = 0; pos < len;){
            const take = Math.min(blockLen - this.pos, len - pos);
            // Fast path: we have at least one block in input
            if (take === blockLen) {
                for(; blockLen <= len - pos; pos += blockLen)this.process(data, pos);
                continue;
            }
            buffer.set(data.subarray(pos, pos + take), this.pos);
            this.pos += take;
            pos += take;
            if (this.pos === blockLen) {
                this.process(buffer, 0, false);
                this.pos = 0;
            }
        }
        return this;
    }
    destroy() {
        this.h.fill(0);
        this.r.fill(0);
        this.buffer.fill(0);
        this.pad.fill(0);
    }
    digestInto(out) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].exists(this);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].output(out, this);
        this.finished = true;
        const { buffer, h } = this;
        let { pos } = this;
        if (pos) {
            buffer[pos++] = 1;
            // buffer.subarray(pos).fill(0);
            for(; pos < 16; pos++)buffer[pos] = 0;
            this.process(buffer, 0, true);
        }
        this.finalize();
        let opos = 0;
        for(let i = 0; i < 8; i++){
            out[opos++] = h[i] >>> 0;
            out[opos++] = h[i] >>> 8;
        }
        return out;
    }
    digest() {
        const { buffer, outputLen } = this;
        this.digestInto(buffer);
        const res = buffer.slice(0, outputLen);
        this.destroy();
        return res;
    }
}
function wrapConstructorWithKey(hashCons) {
    const hashC = (msg, key)=>hashCons(key).update((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBytes"])(msg)).digest();
    const tmp = hashCons(new Uint8Array(32));
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (key)=>hashCons(key);
    return hashC;
}
const poly1305 = wrapConstructorWithKey((key)=>new Poly1305(key)); //# sourceMappingURL=_poly1305.js.map

})()),
"[project]/node_modules/@noble/ciphers/esm/_salsa.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

// Basic utils for salsa-like ciphers
// Check out _micro.ts for descriptive documentation.
__turbopack_esm__({
    "salsaBasic": ()=>salsaBasic
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/_assert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
/*
RFC8439 requires multi-step cipher stream, where
authKey starts with counter: 0, actual msg with counter: 1.

For this, we need a way to re-use nonce / counter:

    const counter = new Uint8Array(4);
    chacha(..., counter, ...); // counter is now 1
    chacha(..., counter, ...); // counter is now 2

This is complicated:

- Original papers don't allow mutating counters
- Counter overflow is undefined: https://mailarchive.ietf.org/arch/msg/cfrg/gsOnTJzcbgG6OqD8Sc0GO5aR_tU/
- 3rd-party library stablelib implementation uses an approach where you can provide
  nonce and counter instead of just nonce - and it will re-use it
- We could have did something similar, but ChaCha has different counter position
  (counter | nonce), which is not composable with XChaCha, because full counter
  is (nonce16 | counter | nonce16). Stablelib doesn't support in-place counter for XChaCha.
- We could separate nonce & counter and provide separate API for counter re-use, but
  there are different counter sizes depending on an algorithm.
- Salsa & ChaCha also differ in structures of key / sigma:

    salsa:     c0 | k(4) | c1 | nonce(2) | ctr(2) | c2 | k(4) | c4
    chacha:    c(4) | k(8) | ctr(1) | nonce(3)
    chachaDJB: c(4) | k(8) | ctr(2) | nonce(2)
- Creating function such as `setSalsaState(key, nonce, sigma, data)` won't work,
  because we can't re-use counter array
- 32-bit nonce is `2 ** 32 * 64` = 256GB with 32-bit counter
- JS does not allow UintArrays bigger than 4GB, so supporting 64-bit counters doesn't matter

Structure is as following:

key=16 -> sigma16, k=key|key
key=32 -> sigma32, k=key

nonces:
salsa20:      8   (8-byte counter)
chacha20djb:  8   (8-byte counter)
chacha20tls:  12  (4-byte counter)
xsalsa:       24  (16 -> hsalsa, 8 -> old nonce)
xchacha:      24  (16 -> hchacha, 8 -> old nonce)

https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha#appendix-A.2
Use the subkey and remaining 8 byte nonce with ChaCha20 as normal
(prefixed by 4 NUL bytes, since [RFC8439] specifies a 12-byte nonce).
*/ const sigma16 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utf8ToBytes"])('expand 16-byte k');
const sigma32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["utf8ToBytes"])('expand 32-byte k');
const sigma16_32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(sigma16);
const sigma32_32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(sigma32);
// Is byte array aligned to 4 byte offset (u32)?
const isAligned32 = (b)=>!(b.byteOffset % 4);
const salsaBasic = (opts)=>{
    const { core, rounds, counterRight, counterLen, allow128bitKeys, extendNonceFn, blockLen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkOpts"])({
        rounds: 20,
        counterRight: false,
        counterLen: 8,
        allow128bitKeys: true,
        blockLen: 64
    }, opts);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number(counterLen);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number(rounds);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number(blockLen);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool(counterRight);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool(allow128bitKeys);
    const blockLen32 = blockLen / 4;
    if (blockLen % 4 !== 0) throw new Error('Salsa/ChaCha: blockLen must be aligned to 4 bytes');
    return (key, nonce, data, output, counter = 0)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bytes(key);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bytes(nonce);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bytes(data);
        if (!output) output = new Uint8Array(data.length);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bytes(output);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_assert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number(counter);
        // > new Uint32Array([2**32])
        // Uint32Array(1) [ 0 ]
        // > new Uint32Array([2**32-1])
        // Uint32Array(1) [ 4294967295 ]
        if (counter < 0 || counter >= 2 ** 32 - 1) throw new Error('Salsa/ChaCha: counter overflow');
        if (output.length < data.length) {
            throw new Error(`Salsa/ChaCha: output (${output.length}) is shorter than data (${data.length})`);
        }
        const toClean = [];
        let k, sigma;
        // Handle 128 byte keys
        if (key.length === 32) {
            k = key;
            sigma = sigma32_32;
        } else if (key.length === 16 && allow128bitKeys) {
            k = new Uint8Array(32);
            k.set(key);
            k.set(key, 16);
            sigma = sigma16_32;
            toClean.push(k);
        } else throw new Error(`Salsa/ChaCha: invalid 32-byte key, got length=${key.length}`);
        // Handle extended nonce (HChaCha/HSalsa)
        if (extendNonceFn) {
            if (nonce.length <= 16) throw new Error(`Salsa/ChaCha: extended nonce must be bigger than 16 bytes`);
            k = extendNonceFn(sigma, k, nonce.subarray(0, 16), new Uint8Array(32));
            toClean.push(k);
            nonce = nonce.subarray(16);
        }
        // Handle nonce counter
        const nonceLen = 16 - counterLen;
        if (nonce.length !== nonceLen) throw new Error(`Salsa/ChaCha: nonce must be ${nonceLen} or 16 bytes`);
        // Pad counter when nonce is 64 bit
        if (nonceLen !== 12) {
            const nc = new Uint8Array(12);
            nc.set(nonce, counterRight ? 0 : 12 - nonce.length);
            toClean.push(nonce = nc);
        }
        // Counter positions
        const block = new Uint8Array(blockLen);
        // Cast to Uint32Array for speed
        const b32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(block);
        const k32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(k);
        const n32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(nonce);
        // Make sure that buffers aligned to 4 bytes
        const d32 = isAligned32(data) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(data);
        const o32 = isAligned32(output) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(output);
        toClean.push(b32);
        const len = data.length;
        for(let pos = 0, ctr = counter; pos < len; ctr++){
            core(sigma, k32, n32, b32, ctr, rounds);
            if (ctr >= 2 ** 32 - 1) throw new Error('Salsa/ChaCha: counter overflow');
            const take = Math.min(blockLen, len - pos);
            // full block && aligned to 4 bytes
            if (take === blockLen && o32 && d32) {
                const pos32 = pos / 4;
                if (pos % 4 !== 0) throw new Error('Salsa/ChaCha: invalid block position');
                for(let j = 0; j < blockLen32; j++)o32[pos32 + j] = d32[pos32 + j] ^ b32[j];
                pos += blockLen;
                continue;
            }
            for(let j = 0; j < take; j++)output[pos + j] = data[pos + j] ^ block[j];
            pos += take;
        }
        for(let i = 0; i < toClean.length; i++)toClean[i].fill(0);
        return output;
    };
}; //# sourceMappingURL=_salsa.js.map

})()),
"[project]/node_modules/@noble/ciphers/esm/chacha.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "_poly1305_aead": ()=>_poly1305_aead,
    "chacha12": ()=>chacha12,
    "chacha20": ()=>chacha20,
    "chacha20orig": ()=>chacha20orig,
    "chacha20poly1305": ()=>chacha20poly1305,
    "chacha8": ()=>chacha8,
    "hchacha": ()=>hchacha,
    "xchacha20": ()=>xchacha20,
    "xchacha20poly1305": ()=>xchacha20poly1305
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_poly1305$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/_poly1305.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_salsa$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/_salsa.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
// ChaCha20 stream cipher was released in 2008. ChaCha aims to increase
// the diffusion per round, but had slightly less cryptanalysis.
// https://cr.yp.to/chacha.html, http://cr.yp.to/chacha/chacha-20080128.pdf
// Left rotate for uint32
const rotl = (a, b)=>a << b | a >>> 32 - b;
/**
 * ChaCha core function.
 */ // prettier-ignore
function chachaCore(c, k, n, out, cnt, rounds = 20) {
    let y00 = c[0], y01 = c[1], y02 = c[2], y03 = c[3]; // "expa"   "nd 3"  "2-by"  "te k"
    let y04 = k[0], y05 = k[1], y06 = k[2], y07 = k[3]; // Key      Key     Key     Key
    let y08 = k[4], y09 = k[5], y10 = k[6], y11 = k[7]; // Key      Key     Key     Key
    let y12 = cnt, y13 = n[0], y14 = n[1], y15 = n[2]; // Counter  Counter	Nonce   Nonce
    // Save state to temporary variables
    let x00 = y00, x01 = y01, x02 = y02, x03 = y03, x04 = y04, x05 = y05, x06 = y06, x07 = y07, x08 = y08, x09 = y09, x10 = y10, x11 = y11, x12 = y12, x13 = y13, x14 = y14, x15 = y15;
    // Main loop
    for(let i = 0; i < rounds; i += 2){
        x00 = x00 + x04 | 0;
        x12 = rotl(x12 ^ x00, 16);
        x08 = x08 + x12 | 0;
        x04 = rotl(x04 ^ x08, 12);
        x00 = x00 + x04 | 0;
        x12 = rotl(x12 ^ x00, 8);
        x08 = x08 + x12 | 0;
        x04 = rotl(x04 ^ x08, 7);
        x01 = x01 + x05 | 0;
        x13 = rotl(x13 ^ x01, 16);
        x09 = x09 + x13 | 0;
        x05 = rotl(x05 ^ x09, 12);
        x01 = x01 + x05 | 0;
        x13 = rotl(x13 ^ x01, 8);
        x09 = x09 + x13 | 0;
        x05 = rotl(x05 ^ x09, 7);
        x02 = x02 + x06 | 0;
        x14 = rotl(x14 ^ x02, 16);
        x10 = x10 + x14 | 0;
        x06 = rotl(x06 ^ x10, 12);
        x02 = x02 + x06 | 0;
        x14 = rotl(x14 ^ x02, 8);
        x10 = x10 + x14 | 0;
        x06 = rotl(x06 ^ x10, 7);
        x03 = x03 + x07 | 0;
        x15 = rotl(x15 ^ x03, 16);
        x11 = x11 + x15 | 0;
        x07 = rotl(x07 ^ x11, 12);
        x03 = x03 + x07 | 0;
        x15 = rotl(x15 ^ x03, 8);
        x11 = x11 + x15 | 0;
        x07 = rotl(x07 ^ x11, 7);
        x00 = x00 + x05 | 0;
        x15 = rotl(x15 ^ x00, 16);
        x10 = x10 + x15 | 0;
        x05 = rotl(x05 ^ x10, 12);
        x00 = x00 + x05 | 0;
        x15 = rotl(x15 ^ x00, 8);
        x10 = x10 + x15 | 0;
        x05 = rotl(x05 ^ x10, 7);
        x01 = x01 + x06 | 0;
        x12 = rotl(x12 ^ x01, 16);
        x11 = x11 + x12 | 0;
        x06 = rotl(x06 ^ x11, 12);
        x01 = x01 + x06 | 0;
        x12 = rotl(x12 ^ x01, 8);
        x11 = x11 + x12 | 0;
        x06 = rotl(x06 ^ x11, 7);
        x02 = x02 + x07 | 0;
        x13 = rotl(x13 ^ x02, 16);
        x08 = x08 + x13 | 0;
        x07 = rotl(x07 ^ x08, 12);
        x02 = x02 + x07 | 0;
        x13 = rotl(x13 ^ x02, 8);
        x08 = x08 + x13 | 0;
        x07 = rotl(x07 ^ x08, 7);
        x03 = x03 + x04 | 0;
        x14 = rotl(x14 ^ x03, 16);
        x09 = x09 + x14 | 0;
        x04 = rotl(x04 ^ x09, 12);
        x03 = x03 + x04 | 0;
        x14 = rotl(x14 ^ x03, 8);
        x09 = x09 + x14 | 0;
        x04 = rotl(x04 ^ x09, 7);
    }
    // Write output
    let oi = 0;
    out[oi++] = y00 + x00 | 0;
    out[oi++] = y01 + x01 | 0;
    out[oi++] = y02 + x02 | 0;
    out[oi++] = y03 + x03 | 0;
    out[oi++] = y04 + x04 | 0;
    out[oi++] = y05 + x05 | 0;
    out[oi++] = y06 + x06 | 0;
    out[oi++] = y07 + x07 | 0;
    out[oi++] = y08 + x08 | 0;
    out[oi++] = y09 + x09 | 0;
    out[oi++] = y10 + x10 | 0;
    out[oi++] = y11 + x11 | 0;
    out[oi++] = y12 + x12 | 0;
    out[oi++] = y13 + x13 | 0;
    out[oi++] = y14 + x14 | 0;
    out[oi++] = y15 + x15 | 0;
}
function hchacha(c, key, src, out) {
    const k32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(key);
    const i32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(src);
    const o32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["u32"])(out);
    let x00 = c[0], x01 = c[1], x02 = c[2], x03 = c[3];
    let x04 = k32[0], x05 = k32[1], x06 = k32[2], x07 = k32[3];
    let x08 = k32[4], x09 = k32[5], x10 = k32[6], x11 = k32[7];
    let x12 = i32[0], x13 = i32[1], x14 = i32[2], x15 = i32[3];
    for(let i = 0; i < 20; i += 2){
        x00 = x00 + x04 | 0;
        x12 = rotl(x12 ^ x00, 16);
        x08 = x08 + x12 | 0;
        x04 = rotl(x04 ^ x08, 12);
        x00 = x00 + x04 | 0;
        x12 = rotl(x12 ^ x00, 8);
        x08 = x08 + x12 | 0;
        x04 = rotl(x04 ^ x08, 7);
        x01 = x01 + x05 | 0;
        x13 = rotl(x13 ^ x01, 16);
        x09 = x09 + x13 | 0;
        x05 = rotl(x05 ^ x09, 12);
        x01 = x01 + x05 | 0;
        x13 = rotl(x13 ^ x01, 8);
        x09 = x09 + x13 | 0;
        x05 = rotl(x05 ^ x09, 7);
        x02 = x02 + x06 | 0;
        x14 = rotl(x14 ^ x02, 16);
        x10 = x10 + x14 | 0;
        x06 = rotl(x06 ^ x10, 12);
        x02 = x02 + x06 | 0;
        x14 = rotl(x14 ^ x02, 8);
        x10 = x10 + x14 | 0;
        x06 = rotl(x06 ^ x10, 7);
        x03 = x03 + x07 | 0;
        x15 = rotl(x15 ^ x03, 16);
        x11 = x11 + x15 | 0;
        x07 = rotl(x07 ^ x11, 12);
        x03 = x03 + x07 | 0;
        x15 = rotl(x15 ^ x03, 8);
        x11 = x11 + x15 | 0;
        x07 = rotl(x07 ^ x11, 7);
        x00 = x00 + x05 | 0;
        x15 = rotl(x15 ^ x00, 16);
        x10 = x10 + x15 | 0;
        x05 = rotl(x05 ^ x10, 12);
        x00 = x00 + x05 | 0;
        x15 = rotl(x15 ^ x00, 8);
        x10 = x10 + x15 | 0;
        x05 = rotl(x05 ^ x10, 7);
        x01 = x01 + x06 | 0;
        x12 = rotl(x12 ^ x01, 16);
        x11 = x11 + x12 | 0;
        x06 = rotl(x06 ^ x11, 12);
        x01 = x01 + x06 | 0;
        x12 = rotl(x12 ^ x01, 8);
        x11 = x11 + x12 | 0;
        x06 = rotl(x06 ^ x11, 7);
        x02 = x02 + x07 | 0;
        x13 = rotl(x13 ^ x02, 16);
        x08 = x08 + x13 | 0;
        x07 = rotl(x07 ^ x08, 12);
        x02 = x02 + x07 | 0;
        x13 = rotl(x13 ^ x02, 8);
        x08 = x08 + x13 | 0;
        x07 = rotl(x07 ^ x08, 7);
        x03 = x03 + x04 | 0;
        x14 = rotl(x14 ^ x03, 16);
        x09 = x09 + x14 | 0;
        x04 = rotl(x04 ^ x09, 12);
        x03 = x03 + x04 | 0;
        x14 = rotl(x14 ^ x03, 8);
        x09 = x09 + x14 | 0;
        x04 = rotl(x04 ^ x09, 7);
    }
    o32[0] = x00;
    o32[1] = x01;
    o32[2] = x02;
    o32[3] = x03;
    o32[4] = x12;
    o32[5] = x13;
    o32[6] = x14;
    o32[7] = x15;
    return out;
}
const chacha20orig = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_salsa$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["salsaBasic"])({
    core: chachaCore,
    counterRight: false,
    counterLen: 8
});
const chacha20 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_salsa$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["salsaBasic"])({
    core: chachaCore,
    counterRight: false,
    counterLen: 4,
    allow128bitKeys: false
});
const xchacha20 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_salsa$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["salsaBasic"])({
    core: chachaCore,
    counterRight: false,
    counterLen: 8,
    extendNonceFn: hchacha,
    allow128bitKeys: false
});
const chacha8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_salsa$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["salsaBasic"])({
    core: chachaCore,
    counterRight: false,
    counterLen: 4,
    rounds: 8
});
const chacha12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_salsa$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["salsaBasic"])({
    core: chachaCore,
    counterRight: false,
    counterLen: 4,
    rounds: 12
});
const ZERO = /* @__PURE__ */ new Uint8Array(16);
// Pad to digest size with zeros
const updatePadded = (h, msg)=>{
    h.update(msg);
    const left = msg.length % 16;
    if (left) h.update(ZERO.subarray(left));
};
const computeTag = (fn, key, nonce, data, AAD)=>{
    const authKey = fn(key, nonce, new Uint8Array(32));
    const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$_poly1305$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["poly1305"].create(authKey);
    if (AAD) updatePadded(h, AAD);
    updatePadded(h, data);
    const num = new Uint8Array(16);
    const view = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createView"])(num);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 0, BigInt(AAD ? AAD.length : 0), true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setBigUint64"])(view, 8, BigInt(data.length), true);
    h.update(num);
    const res = h.digest();
    authKey.fill(0);
    return res;
};
const _poly1305_aead = (xorStream)=>(key, nonce, AAD)=>{
        const tagLength = 16;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(key, 32);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(nonce);
        return {
            tagLength,
            encrypt: (plaintext, output)=>{
                const plength = plaintext.length;
                const clength = plength + tagLength;
                if (output) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(output, clength);
                } else {
                    output = new Uint8Array(clength);
                }
                xorStream(key, nonce, plaintext, output, 1);
                const tag = computeTag(xorStream, key, nonce, output.subarray(0, -tagLength), AAD);
                output.set(tag, plength); // append tag
                return output;
            },
            decrypt: (ciphertext, output)=>{
                const clength = ciphertext.length;
                const plength = clength - tagLength;
                if (clength < tagLength) throw new Error(`encrypted data must be at least ${tagLength} bytes`);
                if (output) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(output, plength);
                } else {
                    output = new Uint8Array(plength);
                }
                const data = ciphertext.subarray(0, -tagLength);
                const passedTag = ciphertext.subarray(-tagLength);
                const tag = computeTag(xorStream, key, nonce, data, AAD);
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equalBytes"])(passedTag, tag)) throw new Error('invalid tag');
                xorStream(key, nonce, data, output, 1);
                return output;
            }
        };
    };
const chacha20poly1305 = /* @__PURE__ */ _poly1305_aead(chacha20);
const xchacha20poly1305 = /* @__PURE__ */ _poly1305_aead(xchacha20); //# sourceMappingURL=chacha.js.map

})()),
}]);

//# sourceMappingURL=node_modules_228eaf._.js.map
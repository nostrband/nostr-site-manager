(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/node_modules_f6da31._.js", {

"[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/lib/esm/index.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Relay": ()=>Relay,
    "SimplePool": ()=>SimplePool,
    "finalizeEvent": ()=>finalizeEvent,
    "fj": ()=>fakejson_exports,
    "generateSecretKey": ()=>generateSecretKey,
    "getEventHash": ()=>getEventHash,
    "getFilterLimit": ()=>getFilterLimit,
    "getPublicKey": ()=>getPublicKey,
    "kinds": ()=>kinds_exports,
    "matchFilter": ()=>matchFilter,
    "matchFilters": ()=>matchFilters,
    "mergeFilters": ()=>mergeFilters,
    "nip04": ()=>nip04_exports,
    "nip05": ()=>nip05_exports,
    "nip10": ()=>nip10_exports,
    "nip11": ()=>nip11_exports,
    "nip13": ()=>nip13_exports,
    "nip18": ()=>nip18_exports,
    "nip19": ()=>nip19_exports,
    "nip21": ()=>nip21_exports,
    "nip25": ()=>nip25_exports,
    "nip27": ()=>nip27_exports,
    "nip28": ()=>nip28_exports,
    "nip30": ()=>nip30_exports,
    "nip39": ()=>nip39_exports,
    "nip42": ()=>nip42_exports,
    "nip44": ()=>nip44_exports,
    "nip47": ()=>nip47_exports,
    "nip57": ()=>nip57_exports,
    "nip59": ()=>nip59_exports,
    "nip98": ()=>nip98_exports,
    "parseReferences": ()=>parseReferences,
    "serializeEvent": ()=>serializeEvent,
    "sortEvents": ()=>sortEvents,
    "utils": ()=>utils_exports,
    "validateEvent": ()=>validateEvent,
    "verifiedSymbol": ()=>verifiedSymbol,
    "verifyEvent": ()=>verifyEvent
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/node_modules/@noble/hashes/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/node_modules/@noble/hashes/esm/sha256.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/node_modules/@scure/base/lib/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$aes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/aes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$chacha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/chacha.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hkdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/node_modules/@noble/hashes/esm/hkdf.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@nostr-dev-kit/ndk/node_modules/nostr-tools/node_modules/@noble/hashes/esm/hmac.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
var __defProp = Object.defineProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
;
;
// core.ts
var verifiedSymbol = Symbol("verified");
var isRecord = (obj)=>obj instanceof Object;
function validateEvent(event) {
    if (!isRecord(event)) return false;
    if (typeof event.kind !== "number") return false;
    if (typeof event.content !== "string") return false;
    if (typeof event.created_at !== "number") return false;
    if (typeof event.pubkey !== "string") return false;
    if (!event.pubkey.match(/^[a-f0-9]{64}$/)) return false;
    if (!Array.isArray(event.tags)) return false;
    for(let i2 = 0; i2 < event.tags.length; i2++){
        let tag = event.tags[i2];
        if (!Array.isArray(tag)) return false;
        for(let j = 0; j < tag.length; j++){
            if (typeof tag[j] === "object") return false;
        }
    }
    return true;
}
function sortEvents(events) {
    return events.sort((a, b)=>{
        if (a.created_at !== b.created_at) {
            return b.created_at - a.created_at;
        }
        return a.id.localeCompare(b.id);
    });
}
;
// utils.ts
var utils_exports = {};
__export(utils_exports, {
    Queue: ()=>Queue,
    QueueNode: ()=>QueueNode,
    binarySearch: ()=>binarySearch,
    insertEventIntoAscendingList: ()=>insertEventIntoAscendingList,
    insertEventIntoDescendingList: ()=>insertEventIntoDescendingList,
    normalizeURL: ()=>normalizeURL,
    utf8Decoder: ()=>utf8Decoder,
    utf8Encoder: ()=>utf8Encoder
});
var utf8Decoder = new TextDecoder("utf-8");
var utf8Encoder = new TextEncoder();
function normalizeURL(url) {
    if (url.indexOf("://") === -1) url = "wss://" + url;
    let p = new URL(url);
    p.pathname = p.pathname.replace(/\/+/g, "/");
    if (p.pathname.endsWith("/")) p.pathname = p.pathname.slice(0, -1);
    if (p.port === "80" && p.protocol === "ws:" || p.port === "443" && p.protocol === "wss:") p.port = "";
    p.searchParams.sort();
    p.hash = "";
    return p.toString();
}
function insertEventIntoDescendingList(sortedArray, event) {
    const [idx, found] = binarySearch(sortedArray, (b)=>{
        if (event.id === b.id) return 0;
        if (event.created_at === b.created_at) return -1;
        return b.created_at - event.created_at;
    });
    if (!found) {
        sortedArray.splice(idx, 0, event);
    }
    return sortedArray;
}
function insertEventIntoAscendingList(sortedArray, event) {
    const [idx, found] = binarySearch(sortedArray, (b)=>{
        if (event.id === b.id) return 0;
        if (event.created_at === b.created_at) return -1;
        return event.created_at - b.created_at;
    });
    if (!found) {
        sortedArray.splice(idx, 0, event);
    }
    return sortedArray;
}
function binarySearch(arr, compare) {
    let start = 0;
    let end = arr.length - 1;
    while(start <= end){
        const mid = Math.floor((start + end) / 2);
        const cmp = compare(arr[mid]);
        if (cmp === 0) {
            return [
                mid,
                true
            ];
        }
        if (cmp < 0) {
            end = mid - 1;
        } else {
            start = mid + 1;
        }
    }
    return [
        start,
        false
    ];
}
var QueueNode = class {
    value;
    next = null;
    prev = null;
    constructor(message){
        this.value = message;
    }
};
var Queue = class {
    first;
    last;
    constructor(){
        this.first = null;
        this.last = null;
    }
    enqueue(value) {
        const newNode = new QueueNode(value);
        if (!this.last) {
            this.first = newNode;
            this.last = newNode;
        } else if (this.last === this.first) {
            this.last = newNode;
            this.last.prev = this.first;
            this.first.next = newNode;
        } else {
            newNode.prev = this.last;
            this.last.next = newNode;
            this.last = newNode;
        }
        return true;
    }
    dequeue() {
        if (!this.first) return null;
        if (this.first === this.last) {
            const target2 = this.first;
            this.first = null;
            this.last = null;
            return target2.value;
        }
        const target = this.first;
        this.first = target.next;
        return target.value;
    }
};
// pure.ts
var JS = class {
    generateSecretKey() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].utils.randomPrivateKey();
    }
    getPublicKey(secretKey) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].getPublicKey(secretKey));
    }
    finalizeEvent(t, secretKey) {
        const event = t;
        event.pubkey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].getPublicKey(secretKey));
        event.id = getEventHash(event);
        event.sig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].sign(getEventHash(event), secretKey));
        event[verifiedSymbol] = true;
        return event;
    }
    verifyEvent(event) {
        if (typeof event[verifiedSymbol] === "boolean") return event[verifiedSymbol];
        const hash = getEventHash(event);
        if (hash !== event.id) {
            event[verifiedSymbol] = false;
            return false;
        }
        try {
            const valid = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].verify(event.sig, hash, event.pubkey);
            event[verifiedSymbol] = valid;
            return valid;
        } catch (err) {
            event[verifiedSymbol] = false;
            return false;
        }
    }
};
function serializeEvent(evt) {
    if (!validateEvent(evt)) throw new Error("can't serialize event with wrong or missing properties");
    return JSON.stringify([
        0,
        evt.pubkey,
        evt.created_at,
        evt.kind,
        evt.tags,
        evt.content
    ]);
}
function getEventHash(event) {
    let eventHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(utf8Encoder.encode(serializeEvent(event)));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(eventHash);
}
var i = new JS();
var generateSecretKey = i.generateSecretKey;
var getPublicKey = i.getPublicKey;
var finalizeEvent = i.finalizeEvent;
var verifyEvent = i.verifyEvent;
// kinds.ts
var kinds_exports = {};
__export(kinds_exports, {
    Application: ()=>Application,
    BadgeAward: ()=>BadgeAward,
    BadgeDefinition: ()=>BadgeDefinition,
    BlockedRelaysList: ()=>BlockedRelaysList,
    BookmarkList: ()=>BookmarkList,
    Bookmarksets: ()=>Bookmarksets,
    Calendar: ()=>Calendar,
    CalendarEventRSVP: ()=>CalendarEventRSVP,
    ChannelCreation: ()=>ChannelCreation,
    ChannelHideMessage: ()=>ChannelHideMessage,
    ChannelMessage: ()=>ChannelMessage,
    ChannelMetadata: ()=>ChannelMetadata,
    ChannelMuteUser: ()=>ChannelMuteUser,
    ClassifiedListing: ()=>ClassifiedListing,
    ClientAuth: ()=>ClientAuth,
    CommunitiesList: ()=>CommunitiesList,
    CommunityDefinition: ()=>CommunityDefinition,
    CommunityPostApproval: ()=>CommunityPostApproval,
    Contacts: ()=>Contacts,
    CreateOrUpdateProduct: ()=>CreateOrUpdateProduct,
    CreateOrUpdateStall: ()=>CreateOrUpdateStall,
    Curationsets: ()=>Curationsets,
    Date: ()=>Date2,
    DirectMessageRelaysList: ()=>DirectMessageRelaysList,
    DraftClassifiedListing: ()=>DraftClassifiedListing,
    DraftLong: ()=>DraftLong,
    Emojisets: ()=>Emojisets,
    EncryptedDirectMessage: ()=>EncryptedDirectMessage,
    EventDeletion: ()=>EventDeletion,
    FileMetadata: ()=>FileMetadata,
    FileServerPreference: ()=>FileServerPreference,
    Followsets: ()=>Followsets,
    GenericRepost: ()=>GenericRepost,
    Genericlists: ()=>Genericlists,
    GiftWrap: ()=>GiftWrap,
    HTTPAuth: ()=>HTTPAuth,
    Handlerinformation: ()=>Handlerinformation,
    Handlerrecommendation: ()=>Handlerrecommendation,
    Highlights: ()=>Highlights,
    InterestsList: ()=>InterestsList,
    Interestsets: ()=>Interestsets,
    JobFeedback: ()=>JobFeedback,
    JobRequest: ()=>JobRequest,
    JobResult: ()=>JobResult,
    Label: ()=>Label,
    LightningPubRPC: ()=>LightningPubRPC,
    LiveChatMessage: ()=>LiveChatMessage,
    LiveEvent: ()=>LiveEvent,
    LongFormArticle: ()=>LongFormArticle,
    Metadata: ()=>Metadata,
    Mutelist: ()=>Mutelist,
    NWCWalletInfo: ()=>NWCWalletInfo,
    NWCWalletRequest: ()=>NWCWalletRequest,
    NWCWalletResponse: ()=>NWCWalletResponse,
    NostrConnect: ()=>NostrConnect,
    OpenTimestamps: ()=>OpenTimestamps,
    Pinlist: ()=>Pinlist,
    PrivateDirectMessage: ()=>PrivateDirectMessage,
    ProblemTracker: ()=>ProblemTracker,
    ProfileBadges: ()=>ProfileBadges,
    PublicChatsList: ()=>PublicChatsList,
    Reaction: ()=>Reaction,
    RecommendRelay: ()=>RecommendRelay,
    RelayList: ()=>RelayList,
    Relaysets: ()=>Relaysets,
    Report: ()=>Report,
    Reporting: ()=>Reporting,
    Repost: ()=>Repost,
    Seal: ()=>Seal,
    SearchRelaysList: ()=>SearchRelaysList,
    ShortTextNote: ()=>ShortTextNote,
    Time: ()=>Time,
    UserEmojiList: ()=>UserEmojiList,
    UserStatuses: ()=>UserStatuses,
    Zap: ()=>Zap,
    ZapGoal: ()=>ZapGoal,
    ZapRequest: ()=>ZapRequest,
    classifyKind: ()=>classifyKind,
    isEphemeralKind: ()=>isEphemeralKind,
    isKind: ()=>isKind,
    isParameterizedReplaceableKind: ()=>isParameterizedReplaceableKind,
    isRegularKind: ()=>isRegularKind,
    isReplaceableKind: ()=>isReplaceableKind
});
function isRegularKind(kind) {
    return 1e3 <= kind && kind < 1e4 || [
        1,
        2,
        4,
        5,
        6,
        7,
        8,
        16,
        40,
        41,
        42,
        43,
        44
    ].includes(kind);
}
function isReplaceableKind(kind) {
    return [
        0,
        3
    ].includes(kind) || 1e4 <= kind && kind < 2e4;
}
function isEphemeralKind(kind) {
    return 2e4 <= kind && kind < 3e4;
}
function isParameterizedReplaceableKind(kind) {
    return 3e4 <= kind && kind < 4e4;
}
function classifyKind(kind) {
    if (isRegularKind(kind)) return "regular";
    if (isReplaceableKind(kind)) return "replaceable";
    if (isEphemeralKind(kind)) return "ephemeral";
    if (isParameterizedReplaceableKind(kind)) return "parameterized";
    return "unknown";
}
function isKind(event, kind) {
    const kindAsArray = kind instanceof Array ? kind : [
        kind
    ];
    return validateEvent(event) && kindAsArray.includes(event.kind) || false;
}
var Metadata = 0;
var ShortTextNote = 1;
var RecommendRelay = 2;
var Contacts = 3;
var EncryptedDirectMessage = 4;
var EventDeletion = 5;
var Repost = 6;
var Reaction = 7;
var BadgeAward = 8;
var Seal = 13;
var PrivateDirectMessage = 14;
var GenericRepost = 16;
var ChannelCreation = 40;
var ChannelMetadata = 41;
var ChannelMessage = 42;
var ChannelHideMessage = 43;
var ChannelMuteUser = 44;
var OpenTimestamps = 1040;
var GiftWrap = 1059;
var FileMetadata = 1063;
var LiveChatMessage = 1311;
var ProblemTracker = 1971;
var Report = 1984;
var Reporting = 1984;
var Label = 1985;
var CommunityPostApproval = 4550;
var JobRequest = 5999;
var JobResult = 6999;
var JobFeedback = 7e3;
var ZapGoal = 9041;
var ZapRequest = 9734;
var Zap = 9735;
var Highlights = 9802;
var Mutelist = 1e4;
var Pinlist = 10001;
var RelayList = 10002;
var BookmarkList = 10003;
var CommunitiesList = 10004;
var PublicChatsList = 10005;
var BlockedRelaysList = 10006;
var SearchRelaysList = 10007;
var InterestsList = 10015;
var UserEmojiList = 10030;
var DirectMessageRelaysList = 10050;
var FileServerPreference = 10096;
var NWCWalletInfo = 13194;
var LightningPubRPC = 21e3;
var ClientAuth = 22242;
var NWCWalletRequest = 23194;
var NWCWalletResponse = 23195;
var NostrConnect = 24133;
var HTTPAuth = 27235;
var Followsets = 3e4;
var Genericlists = 30001;
var Relaysets = 30002;
var Bookmarksets = 30003;
var Curationsets = 30004;
var ProfileBadges = 30008;
var BadgeDefinition = 30009;
var Interestsets = 30015;
var CreateOrUpdateStall = 30017;
var CreateOrUpdateProduct = 30018;
var LongFormArticle = 30023;
var DraftLong = 30024;
var Emojisets = 30030;
var Application = 30078;
var LiveEvent = 30311;
var UserStatuses = 30315;
var ClassifiedListing = 30402;
var DraftClassifiedListing = 30403;
var Date2 = 31922;
var Time = 31923;
var Calendar = 31924;
var CalendarEventRSVP = 31925;
var Handlerrecommendation = 31989;
var Handlerinformation = 31990;
var CommunityDefinition = 34550;
// filter.ts
function matchFilter(filter, event) {
    if (filter.ids && filter.ids.indexOf(event.id) === -1) {
        return false;
    }
    if (filter.kinds && filter.kinds.indexOf(event.kind) === -1) {
        return false;
    }
    if (filter.authors && filter.authors.indexOf(event.pubkey) === -1) {
        return false;
    }
    for(let f in filter){
        if (f[0] === "#") {
            let tagName = f.slice(1);
            let values = filter[`#${tagName}`];
            if (values && !event.tags.find(([t, v])=>t === f.slice(1) && values.indexOf(v) !== -1)) return false;
        }
    }
    if (filter.since && event.created_at < filter.since) return false;
    if (filter.until && event.created_at > filter.until) return false;
    return true;
}
function matchFilters(filters, event) {
    for(let i2 = 0; i2 < filters.length; i2++){
        if (matchFilter(filters[i2], event)) {
            return true;
        }
    }
    return false;
}
function mergeFilters(...filters) {
    let result = {};
    for(let i2 = 0; i2 < filters.length; i2++){
        let filter = filters[i2];
        Object.entries(filter).forEach(([property, values])=>{
            if (property === "kinds" || property === "ids" || property === "authors" || property[0] === "#") {
                result[property] = result[property] || [];
                for(let v = 0; v < values.length; v++){
                    let value = values[v];
                    if (!result[property].includes(value)) result[property].push(value);
                }
            }
        });
        if (filter.limit && (!result.limit || filter.limit > result.limit)) result.limit = filter.limit;
        if (filter.until && (!result.until || filter.until > result.until)) result.until = filter.until;
        if (filter.since && (!result.since || filter.since < result.since)) result.since = filter.since;
    }
    return result;
}
function getFilterLimit(filter) {
    if (filter.ids && !filter.ids.length) return 0;
    if (filter.kinds && !filter.kinds.length) return 0;
    if (filter.authors && !filter.authors.length) return 0;
    for (const [key, value] of Object.entries(filter)){
        if (key[0] === "#" && Array.isArray(value) && !value.length) return 0;
    }
    return Math.min(Math.max(0, filter.limit ?? Infinity), filter.ids?.length ?? Infinity, filter.authors?.length && filter.kinds?.every((kind)=>isReplaceableKind(kind)) ? filter.authors.length * filter.kinds.length : Infinity, filter.authors?.length && filter.kinds?.every((kind)=>isParameterizedReplaceableKind(kind)) && filter["#d"]?.length ? filter.authors.length * filter.kinds.length * filter["#d"].length : Infinity);
}
// fakejson.ts
var fakejson_exports = {};
__export(fakejson_exports, {
    getHex64: ()=>getHex64,
    getInt: ()=>getInt,
    getSubscriptionId: ()=>getSubscriptionId,
    matchEventId: ()=>matchEventId,
    matchEventKind: ()=>matchEventKind,
    matchEventPubkey: ()=>matchEventPubkey
});
function getHex64(json, field) {
    let len = field.length + 3;
    let idx = json.indexOf(`"${field}":`) + len;
    let s = json.slice(idx).indexOf(`"`) + idx + 1;
    return json.slice(s, s + 64);
}
function getInt(json, field) {
    let len = field.length;
    let idx = json.indexOf(`"${field}":`) + len + 3;
    let sliced = json.slice(idx);
    let end = Math.min(sliced.indexOf(","), sliced.indexOf("}"));
    return parseInt(sliced.slice(0, end), 10);
}
function getSubscriptionId(json) {
    let idx = json.slice(0, 22).indexOf(`"EVENT"`);
    if (idx === -1) return null;
    let pstart = json.slice(idx + 7 + 1).indexOf(`"`);
    if (pstart === -1) return null;
    let start = idx + 7 + 1 + pstart;
    let pend = json.slice(start + 1, 80).indexOf(`"`);
    if (pend === -1) return null;
    let end = start + 1 + pend;
    return json.slice(start + 1, end);
}
function matchEventId(json, id) {
    return id === getHex64(json, "id");
}
function matchEventPubkey(json, pubkey) {
    return pubkey === getHex64(json, "pubkey");
}
function matchEventKind(json, kind) {
    return kind === getInt(json, "kind");
}
// nip42.ts
var nip42_exports = {};
__export(nip42_exports, {
    makeAuthEvent: ()=>makeAuthEvent
});
function makeAuthEvent(relayURL, challenge) {
    return {
        kind: ClientAuth,
        created_at: Math.floor(Date.now() / 1e3),
        tags: [
            [
                "relay",
                relayURL
            ],
            [
                "challenge",
                challenge
            ]
        ],
        content: ""
    };
}
// helpers.ts
async function yieldThread() {
    return new Promise((resolve)=>{
        const ch = new MessageChannel();
        const handler = ()=>{
            ch.port1.removeEventListener("message", handler);
            resolve();
        };
        ch.port1.addEventListener("message", handler);
        ch.port2.postMessage(0);
        ch.port1.start();
    });
}
var alwaysTrue = (t)=>{
    t[verifiedSymbol] = true;
    return true;
};
// abstract-relay.ts
var AbstractRelay = class {
    url;
    _connected = false;
    onclose = null;
    onnotice = (msg)=>console.debug(`NOTICE from ${this.url}: ${msg}`);
    _onauth = null;
    baseEoseTimeout = 4400;
    connectionTimeout = 4400;
    publishTimeout = 4400;
    openSubs = /* @__PURE__ */ new Map();
    connectionTimeoutHandle;
    connectionPromise;
    openCountRequests = /* @__PURE__ */ new Map();
    openEventPublishes = /* @__PURE__ */ new Map();
    ws;
    incomingMessageQueue = new Queue();
    queueRunning = false;
    challenge;
    serial = 0;
    verifyEvent;
    _WebSocket;
    constructor(url, opts){
        this.url = normalizeURL(url);
        this.verifyEvent = opts.verifyEvent;
        this._WebSocket = opts.websocketImplementation || WebSocket;
    }
    static async connect(url, opts) {
        const relay = new AbstractRelay(url, opts);
        await relay.connect();
        return relay;
    }
    closeAllSubscriptions(reason) {
        for (let [_, sub] of this.openSubs){
            sub.close(reason);
        }
        this.openSubs.clear();
        for (let [_, ep] of this.openEventPublishes){
            ep.reject(new Error(reason));
        }
        this.openEventPublishes.clear();
        for (let [_, cr] of this.openCountRequests){
            cr.reject(new Error(reason));
        }
        this.openCountRequests.clear();
    }
    get connected() {
        return this._connected;
    }
    async connect() {
        if (this.connectionPromise) return this.connectionPromise;
        this.challenge = void 0;
        this.connectionPromise = new Promise((resolve, reject)=>{
            this.connectionTimeoutHandle = setTimeout(()=>{
                reject("connection timed out");
                this.connectionPromise = void 0;
                this.onclose?.();
                this.closeAllSubscriptions("relay connection timed out");
            }, this.connectionTimeout);
            try {
                this.ws = new this._WebSocket(this.url);
            } catch (err) {
                reject(err);
                return;
            }
            this.ws.onopen = ()=>{
                clearTimeout(this.connectionTimeoutHandle);
                this._connected = true;
                resolve();
            };
            this.ws.onerror = (ev)=>{
                reject(ev.message || "websocket error");
                if (this._connected) {
                    this._connected = false;
                    this.connectionPromise = void 0;
                    this.onclose?.();
                    this.closeAllSubscriptions("relay connection errored");
                }
            };
            this.ws.onclose = async ()=>{
                if (this._connected) {
                    this._connected = false;
                    this.connectionPromise = void 0;
                    this.onclose?.();
                    this.closeAllSubscriptions("relay connection closed");
                }
            };
            this.ws.onmessage = this._onmessage.bind(this);
        });
        return this.connectionPromise;
    }
    async runQueue() {
        this.queueRunning = true;
        while(true){
            if (false === this.handleNext()) {
                break;
            }
            await yieldThread();
        }
        this.queueRunning = false;
    }
    handleNext() {
        const json = this.incomingMessageQueue.dequeue();
        if (!json) {
            return false;
        }
        const subid = getSubscriptionId(json);
        if (subid) {
            const so = this.openSubs.get(subid);
            if (!so) {
                return;
            }
            const id = getHex64(json, "id");
            const alreadyHave = so.alreadyHaveEvent?.(id);
            so.receivedEvent?.(this, id);
            if (alreadyHave) {
                return;
            }
        }
        try {
            let data = JSON.parse(json);
            switch(data[0]){
                case "EVENT":
                    {
                        const so = this.openSubs.get(data[1]);
                        const event = data[2];
                        if (this.verifyEvent(event) && matchFilters(so.filters, event)) {
                            so.onevent(event);
                        }
                        return;
                    }
                case "COUNT":
                    {
                        const id = data[1];
                        const payload = data[2];
                        const cr = this.openCountRequests.get(id);
                        if (cr) {
                            cr.resolve(payload.count);
                            this.openCountRequests.delete(id);
                        }
                        return;
                    }
                case "EOSE":
                    {
                        const so = this.openSubs.get(data[1]);
                        if (!so) return;
                        so.receivedEose();
                        return;
                    }
                case "OK":
                    {
                        const id = data[1];
                        const ok = data[2];
                        const reason = data[3];
                        const ep = this.openEventPublishes.get(id);
                        if (ep) {
                            if (ok) ep.resolve(reason);
                            else ep.reject(new Error(reason));
                            this.openEventPublishes.delete(id);
                        }
                        return;
                    }
                case "CLOSED":
                    {
                        const id = data[1];
                        const so = this.openSubs.get(id);
                        if (!so) return;
                        so.closed = true;
                        so.close(data[2]);
                        return;
                    }
                case "NOTICE":
                    this.onnotice(data[1]);
                    return;
                case "AUTH":
                    {
                        this.challenge = data[1];
                        this._onauth?.(data[1]);
                        return;
                    }
            }
        } catch (err) {
            return;
        }
    }
    async send(message) {
        if (!this.connectionPromise) throw new Error("sending on closed connection");
        this.connectionPromise.then(()=>{
            this.ws?.send(message);
        });
    }
    async auth(signAuthEvent) {
        if (!this.challenge) throw new Error("can't perform auth, no challenge was received");
        const evt = await signAuthEvent(makeAuthEvent(this.url, this.challenge));
        const ret = new Promise((resolve, reject)=>{
            this.openEventPublishes.set(evt.id, {
                resolve,
                reject
            });
        });
        this.send('["AUTH",' + JSON.stringify(evt) + "]");
        return ret;
    }
    async publish(event) {
        const ret = new Promise((resolve, reject)=>{
            this.openEventPublishes.set(event.id, {
                resolve,
                reject
            });
        });
        this.send('["EVENT",' + JSON.stringify(event) + "]");
        setTimeout(()=>{
            const ep = this.openEventPublishes.get(event.id);
            if (ep) {
                ep.reject(new Error("publish timed out"));
                this.openEventPublishes.delete(event.id);
            }
        }, this.publishTimeout);
        return ret;
    }
    async count(filters, params) {
        this.serial++;
        const id = params?.id || "count:" + this.serial;
        const ret = new Promise((resolve, reject)=>{
            this.openCountRequests.set(id, {
                resolve,
                reject
            });
        });
        this.send('["COUNT","' + id + '",' + JSON.stringify(filters).substring(1));
        return ret;
    }
    subscribe(filters, params) {
        const subscription = this.prepareSubscription(filters, params);
        subscription.fire();
        return subscription;
    }
    prepareSubscription(filters, params) {
        this.serial++;
        const id = params.id || "sub:" + this.serial;
        const subscription = new Subscription(this, id, filters, params);
        this.openSubs.set(id, subscription);
        return subscription;
    }
    close() {
        this.closeAllSubscriptions("relay connection closed by us");
        this._connected = false;
        this.ws?.close();
    }
    _onmessage(ev) {
        this.incomingMessageQueue.enqueue(ev.data);
        if (!this.queueRunning) {
            this.runQueue();
        }
    }
};
var Subscription = class {
    relay;
    id;
    closed = false;
    eosed = false;
    filters;
    alreadyHaveEvent;
    receivedEvent;
    onevent;
    oneose;
    onclose;
    eoseTimeout;
    eoseTimeoutHandle;
    constructor(relay, id, filters, params){
        this.relay = relay;
        this.filters = filters;
        this.id = id;
        this.alreadyHaveEvent = params.alreadyHaveEvent;
        this.receivedEvent = params.receivedEvent;
        this.eoseTimeout = params.eoseTimeout || relay.baseEoseTimeout;
        this.oneose = params.oneose;
        this.onclose = params.onclose;
        this.onevent = params.onevent || ((event)=>{
            console.warn(`onevent() callback not defined for subscription '${this.id}' in relay ${this.relay.url}. event received:`, event);
        });
    }
    fire() {
        this.relay.send('["REQ","' + this.id + '",' + JSON.stringify(this.filters).substring(1));
        this.eoseTimeoutHandle = setTimeout(this.receivedEose.bind(this), this.eoseTimeout);
    }
    receivedEose() {
        if (this.eosed) return;
        clearTimeout(this.eoseTimeoutHandle);
        this.eosed = true;
        this.oneose?.();
    }
    close(reason = "closed by caller") {
        if (!this.closed && this.relay.connected) {
            this.relay.send('["CLOSE",' + JSON.stringify(this.id) + "]");
            this.closed = true;
        }
        this.relay.openSubs.delete(this.id);
        this.onclose?.(reason);
    }
};
// relay.ts
var _WebSocket;
try {
    _WebSocket = WebSocket;
} catch  {}
var Relay = class extends AbstractRelay {
    constructor(url){
        super(url, {
            verifyEvent,
            websocketImplementation: _WebSocket
        });
    }
    static async connect(url) {
        const relay = new Relay(url);
        await relay.connect();
        return relay;
    }
};
// abstract-pool.ts
var AbstractSimplePool = class {
    relays = /* @__PURE__ */ new Map();
    seenOn = /* @__PURE__ */ new Map();
    trackRelays = false;
    verifyEvent;
    trustedRelayURLs = /* @__PURE__ */ new Set();
    _WebSocket;
    constructor(opts){
        this.verifyEvent = opts.verifyEvent;
        this._WebSocket = opts.websocketImplementation;
    }
    async ensureRelay(url, params) {
        url = normalizeURL(url);
        let relay = this.relays.get(url);
        if (!relay) {
            relay = new AbstractRelay(url, {
                verifyEvent: this.trustedRelayURLs.has(url) ? alwaysTrue : this.verifyEvent,
                websocketImplementation: this._WebSocket
            });
            if (params?.connectionTimeout) relay.connectionTimeout = params.connectionTimeout;
            this.relays.set(url, relay);
        }
        await relay.connect();
        return relay;
    }
    close(relays) {
        relays.map(normalizeURL).forEach((url)=>{
            this.relays.get(url)?.close();
        });
    }
    subscribeMany(relays, filters, params) {
        return this.subscribeManyMap(Object.fromEntries(relays.map((url)=>[
                url,
                filters
            ])), params);
    }
    subscribeManyMap(requests, params) {
        if (this.trackRelays) {
            params.receivedEvent = (relay, id)=>{
                let set = this.seenOn.get(id);
                if (!set) {
                    set = /* @__PURE__ */ new Set();
                    this.seenOn.set(id, set);
                }
                set.add(relay);
            };
        }
        const _knownIds = /* @__PURE__ */ new Set();
        const subs = [];
        const relaysLength = Object.keys(requests).length;
        const eosesReceived = [];
        let handleEose = (i2)=>{
            eosesReceived[i2] = true;
            if (eosesReceived.filter((a)=>a).length === relaysLength) {
                params.oneose?.();
                handleEose = ()=>{};
            }
        };
        const closesReceived = [];
        let handleClose = (i2, reason)=>{
            handleEose(i2);
            closesReceived[i2] = reason;
            if (closesReceived.filter((a)=>a).length === relaysLength) {
                params.onclose?.(closesReceived);
                handleClose = ()=>{};
            }
        };
        const localAlreadyHaveEventHandler = (id)=>{
            if (params.alreadyHaveEvent?.(id)) {
                return true;
            }
            const have = _knownIds.has(id);
            _knownIds.add(id);
            return have;
        };
        const allOpened = Promise.all(Object.entries(requests).map(async (req, i2, arr)=>{
            if (arr.indexOf(req) !== i2) {
                handleClose(i2, "duplicate url");
                return;
            }
            let [url, filters] = req;
            url = normalizeURL(url);
            let relay;
            try {
                relay = await this.ensureRelay(url, {
                    connectionTimeout: params.maxWait ? Math.max(params.maxWait * 0.8, params.maxWait - 1e3) : void 0
                });
            } catch (err) {
                handleClose(i2, err?.message || String(err));
                return;
            }
            let subscription = relay.subscribe(filters, {
                ...params,
                oneose: ()=>handleEose(i2),
                onclose: (reason)=>handleClose(i2, reason),
                alreadyHaveEvent: localAlreadyHaveEventHandler,
                eoseTimeout: params.maxWait
            });
            subs.push(subscription);
        }));
        return {
            async close () {
                await allOpened;
                subs.forEach((sub)=>{
                    sub.close();
                });
            }
        };
    }
    subscribeManyEose(relays, filters, params) {
        const subcloser = this.subscribeMany(relays, filters, {
            ...params,
            oneose () {
                subcloser.close();
            }
        });
        return subcloser;
    }
    async querySync(relays, filter, params) {
        return new Promise(async (resolve)=>{
            const events = [];
            this.subscribeManyEose(relays, [
                filter
            ], {
                ...params,
                onevent (event) {
                    events.push(event);
                },
                onclose (_) {
                    resolve(events);
                }
            });
        });
    }
    async get(relays, filter, params) {
        filter.limit = 1;
        const events = await this.querySync(relays, filter, params);
        events.sort((a, b)=>b.created_at - a.created_at);
        return events[0] || null;
    }
    publish(relays, event) {
        return relays.map(normalizeURL).map(async (url, i2, arr)=>{
            if (arr.indexOf(url) !== i2) {
                return Promise.reject("duplicate url");
            }
            let r = await this.ensureRelay(url);
            return r.publish(event).then((reason)=>{
                if (this.trackRelays) {
                    let set = this.seenOn.get(event.id);
                    if (!set) {
                        set = /* @__PURE__ */ new Set();
                        this.seenOn.set(event.id, set);
                    }
                    set.add(r);
                }
                return reason;
            });
        });
    }
    listConnectionStatus() {
        const map = /* @__PURE__ */ new Map();
        this.relays.forEach((relay, url)=>map.set(url, relay.connected));
        return map;
    }
    destroy() {
        this.relays.forEach((conn)=>conn.close());
        this.relays = /* @__PURE__ */ new Map();
    }
};
// pool.ts
var _WebSocket2;
try {
    _WebSocket2 = WebSocket;
} catch  {}
var SimplePool = class extends AbstractSimplePool {
    constructor(){
        super({
            verifyEvent,
            websocketImplementation: _WebSocket2
        });
    }
};
// nip19.ts
var nip19_exports = {};
__export(nip19_exports, {
    BECH32_REGEX: ()=>BECH32_REGEX,
    Bech32MaxSize: ()=>Bech32MaxSize,
    NostrTypeGuard: ()=>NostrTypeGuard,
    decode: ()=>decode,
    encodeBytes: ()=>encodeBytes,
    naddrEncode: ()=>naddrEncode,
    neventEncode: ()=>neventEncode,
    noteEncode: ()=>noteEncode,
    nprofileEncode: ()=>nprofileEncode,
    npubEncode: ()=>npubEncode,
    nsecEncode: ()=>nsecEncode
});
;
;
var NostrTypeGuard = {
    isNProfile: (value)=>/^nprofile1[a-z\d]+$/.test(value || ""),
    isNEvent: (value)=>/^nevent1[a-z\d]+$/.test(value || ""),
    isNAddr: (value)=>/^naddr1[a-z\d]+$/.test(value || ""),
    isNSec: (value)=>/^nsec1[a-z\d]{58}$/.test(value || ""),
    isNPub: (value)=>/^npub1[a-z\d]{58}$/.test(value || ""),
    isNote: (value)=>/^note1[a-z\d]+$/.test(value || ""),
    isNcryptsec: (value)=>/^ncryptsec1[a-z\d]+$/.test(value || "")
};
var Bech32MaxSize = 5e3;
var BECH32_REGEX = /[\x21-\x7E]{1,83}1[023456789acdefghjklmnpqrstuvwxyz]{6,}/;
function integerToUint8Array(number) {
    const uint8Array = new Uint8Array(4);
    uint8Array[0] = number >> 24 & 255;
    uint8Array[1] = number >> 16 & 255;
    uint8Array[2] = number >> 8 & 255;
    uint8Array[3] = number & 255;
    return uint8Array;
}
function decode(nip19) {
    let { prefix, words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].decode(nip19, Bech32MaxSize);
    let data = new Uint8Array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].fromWords(words));
    switch(prefix){
        case "nprofile":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for nprofile");
                if (tlv[0][0].length !== 32) throw new Error("TLV 0 should be 32 bytes");
                return {
                    type: "nprofile",
                    data: {
                        pubkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[0][0]),
                        relays: tlv[1] ? tlv[1].map((d)=>utf8Decoder.decode(d)) : []
                    }
                };
            }
        case "nevent":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for nevent");
                if (tlv[0][0].length !== 32) throw new Error("TLV 0 should be 32 bytes");
                if (tlv[2] && tlv[2][0].length !== 32) throw new Error("TLV 2 should be 32 bytes");
                if (tlv[3] && tlv[3][0].length !== 4) throw new Error("TLV 3 should be 4 bytes");
                return {
                    type: "nevent",
                    data: {
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[0][0]),
                        relays: tlv[1] ? tlv[1].map((d)=>utf8Decoder.decode(d)) : [],
                        author: tlv[2]?.[0] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[2][0]) : void 0,
                        kind: tlv[3]?.[0] ? parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[3][0]), 16) : void 0
                    }
                };
            }
        case "naddr":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for naddr");
                if (!tlv[2]?.[0]) throw new Error("missing TLV 2 for naddr");
                if (tlv[2][0].length !== 32) throw new Error("TLV 2 should be 32 bytes");
                if (!tlv[3]?.[0]) throw new Error("missing TLV 3 for naddr");
                if (tlv[3][0].length !== 4) throw new Error("TLV 3 should be 4 bytes");
                return {
                    type: "naddr",
                    data: {
                        identifier: utf8Decoder.decode(tlv[0][0]),
                        pubkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[2][0]),
                        kind: parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[3][0]), 16),
                        relays: tlv[1] ? tlv[1].map((d)=>utf8Decoder.decode(d)) : []
                    }
                };
            }
        case "nsec":
            return {
                type: prefix,
                data
            };
        case "npub":
        case "note":
            return {
                type: prefix,
                data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(data)
            };
        default:
            throw new Error(`unknown prefix ${prefix}`);
    }
}
function parseTLV(data) {
    let result = {};
    let rest = data;
    while(rest.length > 0){
        let t = rest[0];
        let l = rest[1];
        let v = rest.slice(2, 2 + l);
        rest = rest.slice(2 + l);
        if (v.length < l) throw new Error(`not enough data to read on TLV ${t}`);
        result[t] = result[t] || [];
        result[t].push(v);
    }
    return result;
}
function nsecEncode(key) {
    return encodeBytes("nsec", key);
}
function npubEncode(hex) {
    return encodeBytes("npub", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(hex));
}
function noteEncode(hex) {
    return encodeBytes("note", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(hex));
}
function encodeBech32(prefix, data) {
    let words = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].toWords(data);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].encode(prefix, words, Bech32MaxSize);
}
function encodeBytes(prefix, bytes) {
    return encodeBech32(prefix, bytes);
}
function nprofileEncode(profile) {
    let data = encodeTLV({
        0: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(profile.pubkey)
        ],
        1: (profile.relays || []).map((url)=>utf8Encoder.encode(url))
    });
    return encodeBech32("nprofile", data);
}
function neventEncode(event) {
    let kindArray;
    if (event.kind !== void 0) {
        kindArray = integerToUint8Array(event.kind);
    }
    let data = encodeTLV({
        0: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(event.id)
        ],
        1: (event.relays || []).map((url)=>utf8Encoder.encode(url)),
        2: event.author ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(event.author)
        ] : [],
        3: kindArray ? [
            new Uint8Array(kindArray)
        ] : []
    });
    return encodeBech32("nevent", data);
}
function naddrEncode(addr) {
    let kind = new ArrayBuffer(4);
    new DataView(kind).setUint32(0, addr.kind, false);
    let data = encodeTLV({
        0: [
            utf8Encoder.encode(addr.identifier)
        ],
        1: (addr.relays || []).map((url)=>utf8Encoder.encode(url)),
        2: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(addr.pubkey)
        ],
        3: [
            new Uint8Array(kind)
        ]
    });
    return encodeBech32("naddr", data);
}
function encodeTLV(tlv) {
    let entries = [];
    Object.entries(tlv).reverse().forEach(([t, vs])=>{
        vs.forEach((v)=>{
            let entry = new Uint8Array(v.length + 2);
            entry.set([
                parseInt(t)
            ], 0);
            entry.set([
                v.length
            ], 1);
            entry.set(v, 2);
            entries.push(entry);
        });
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(...entries);
}
// references.ts
var mentionRegex = /\bnostr:((note|npub|naddr|nevent|nprofile)1\w+)\b|#\[(\d+)\]/g;
function parseReferences(evt) {
    let references = [];
    for (let ref of evt.content.matchAll(mentionRegex)){
        if (ref[2]) {
            try {
                let { type, data } = decode(ref[1]);
                switch(type){
                    case "npub":
                        {
                            references.push({
                                text: ref[0],
                                profile: {
                                    pubkey: data,
                                    relays: []
                                }
                            });
                            break;
                        }
                    case "nprofile":
                        {
                            references.push({
                                text: ref[0],
                                profile: data
                            });
                            break;
                        }
                    case "note":
                        {
                            references.push({
                                text: ref[0],
                                event: {
                                    id: data,
                                    relays: []
                                }
                            });
                            break;
                        }
                    case "nevent":
                        {
                            references.push({
                                text: ref[0],
                                event: data
                            });
                            break;
                        }
                    case "naddr":
                        {
                            references.push({
                                text: ref[0],
                                address: data
                            });
                            break;
                        }
                }
            } catch (err) {}
        } else if (ref[3]) {
            let idx = parseInt(ref[3], 10);
            let tag = evt.tags[idx];
            if (!tag) continue;
            switch(tag[0]){
                case "p":
                    {
                        references.push({
                            text: ref[0],
                            profile: {
                                pubkey: tag[1],
                                relays: tag[2] ? [
                                    tag[2]
                                ] : []
                            }
                        });
                        break;
                    }
                case "e":
                    {
                        references.push({
                            text: ref[0],
                            event: {
                                id: tag[1],
                                relays: tag[2] ? [
                                    tag[2]
                                ] : []
                            }
                        });
                        break;
                    }
                case "a":
                    {
                        try {
                            let [kind, pubkey, identifier] = tag[1].split(":");
                            references.push({
                                text: ref[0],
                                address: {
                                    identifier,
                                    pubkey,
                                    kind: parseInt(kind, 10),
                                    relays: tag[2] ? [
                                        tag[2]
                                    ] : []
                                }
                            });
                        } catch (err) {}
                        break;
                    }
            }
        }
    }
    return references;
}
// nip04.ts
var nip04_exports = {};
__export(nip04_exports, {
    decrypt: ()=>decrypt,
    encrypt: ()=>encrypt
});
;
;
;
;
async function encrypt(secretKey, pubkey, text) {
    const privkey = secretKey instanceof Uint8Array ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(secretKey) : secretKey;
    const key = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secp256k1"].getSharedSecret(privkey, "02" + pubkey);
    const normalizedKey = getNormalizedX(key);
    let iv = Uint8Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["randomBytes"])(16));
    let plaintext = utf8Encoder.encode(text);
    let ciphertext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$aes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cbc"])(normalizedKey, iv).encrypt(plaintext);
    let ctb64 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode(new Uint8Array(ciphertext));
    let ivb64 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode(new Uint8Array(iv.buffer));
    return `${ctb64}?iv=${ivb64}`;
}
async function decrypt(secretKey, pubkey, data) {
    const privkey = secretKey instanceof Uint8Array ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(secretKey) : secretKey;
    let [ctb64, ivb64] = data.split("?iv=");
    let key = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secp256k1"].getSharedSecret(privkey, "02" + pubkey);
    let normalizedKey = getNormalizedX(key);
    let iv = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(ivb64);
    let ciphertext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(ctb64);
    let plaintext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$aes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cbc"])(normalizedKey, iv).decrypt(ciphertext);
    return utf8Decoder.decode(plaintext);
}
function getNormalizedX(key) {
    return key.slice(1, 33);
}
// nip05.ts
var nip05_exports = {};
__export(nip05_exports, {
    NIP05_REGEX: ()=>NIP05_REGEX,
    isNip05: ()=>isNip05,
    isValid: ()=>isValid,
    queryProfile: ()=>queryProfile,
    searchDomain: ()=>searchDomain,
    useFetchImplementation: ()=>useFetchImplementation
});
var NIP05_REGEX = /^(?:([\w.+-]+)@)?([\w_-]+(\.[\w_-]+)+)$/;
var isNip05 = (value)=>NIP05_REGEX.test(value || "");
var _fetch;
try {
    _fetch = fetch;
} catch (_) {
    null;
}
function useFetchImplementation(fetchImplementation) {
    _fetch = fetchImplementation;
}
async function searchDomain(domain, query = "") {
    try {
        const url = `https://${domain}/.well-known/nostr.json?name=${query}`;
        const res = await _fetch(url, {
            redirect: "manual"
        });
        if (res.status !== 200) {
            throw Error("Wrong response code");
        }
        const json = await res.json();
        return json.names;
    } catch (_) {
        return {};
    }
}
async function queryProfile(fullname) {
    const match = fullname.match(NIP05_REGEX);
    if (!match) return null;
    const [, name = "_", domain] = match;
    try {
        const url = `https://${domain}/.well-known/nostr.json?name=${name}`;
        const res = await _fetch(url, {
            redirect: "manual"
        });
        if (res.status !== 200) {
            throw Error("Wrong response code");
        }
        const json = await res.json();
        const pubkey = json.names[name];
        return pubkey ? {
            pubkey,
            relays: json.relays?.[pubkey]
        } : null;
    } catch (_e) {
        return null;
    }
}
async function isValid(pubkey, nip05) {
    const res = await queryProfile(nip05);
    return res ? res.pubkey === pubkey : false;
}
// nip10.ts
var nip10_exports = {};
__export(nip10_exports, {
    parse: ()=>parse
});
function parse(event) {
    const result = {
        reply: void 0,
        root: void 0,
        mentions: [],
        profiles: [],
        quotes: []
    };
    let maybeParent;
    let maybeRoot;
    for(let i2 = event.tags.length - 1; i2 >= 0; i2--){
        const tag = event.tags[i2];
        if (tag[0] === "e" && tag[1]) {
            const [_, eTagEventId, eTagRelayUrl, eTagMarker, eTagAuthor] = tag;
            const eventPointer = {
                id: eTagEventId,
                relays: eTagRelayUrl ? [
                    eTagRelayUrl
                ] : [],
                author: eTagAuthor
            };
            if (eTagMarker === "root") {
                result.root = eventPointer;
                continue;
            }
            if (eTagMarker === "reply") {
                result.reply = eventPointer;
                continue;
            }
            if (eTagMarker === "mention") {
                result.mentions.push(eventPointer);
                continue;
            }
            if (!maybeParent) {
                maybeParent = eventPointer;
            } else {
                maybeRoot = eventPointer;
            }
            result.mentions.push(eventPointer);
            continue;
        }
        if (tag[0] === "q" && tag[1]) {
            const [_, eTagEventId, eTagRelayUrl] = tag;
            result.quotes.push({
                id: eTagEventId,
                relays: eTagRelayUrl ? [
                    eTagRelayUrl
                ] : []
            });
        }
        if (tag[0] === "p" && tag[1]) {
            result.profiles.push({
                pubkey: tag[1],
                relays: tag[2] ? [
                    tag[2]
                ] : []
            });
            continue;
        }
    }
    if (!result.root) {
        result.root = maybeRoot || maybeParent || result.reply;
    }
    if (!result.reply) {
        result.reply = maybeParent || result.root;
    }
    ;
    [
        result.reply,
        result.root
    ].forEach((ref)=>{
        if (!ref) return;
        let idx = result.mentions.indexOf(ref);
        if (idx !== -1) {
            result.mentions.splice(idx, 1);
        }
        if (ref.author) {
            let author = result.profiles.find((p)=>p.pubkey === ref.author);
            if (author && author.relays) {
                if (!ref.relays) {
                    ref.relays = [];
                }
                author.relays.forEach((url)=>{
                    if (ref.relays?.indexOf(url) === -1) ref.relays.push(url);
                });
                author.relays = ref.relays;
            }
        }
    });
    result.mentions.forEach((ref)=>{
        if (ref.author) {
            let author = result.profiles.find((p)=>p.pubkey === ref.author);
            if (author && author.relays) {
                if (!ref.relays) {
                    ref.relays = [];
                }
                author.relays.forEach((url)=>{
                    if (ref.relays.indexOf(url) === -1) ref.relays.push(url);
                });
                author.relays = ref.relays;
            }
        }
    });
    return result;
}
// nip11.ts
var nip11_exports = {};
__export(nip11_exports, {
    fetchRelayInformation: ()=>fetchRelayInformation,
    useFetchImplementation: ()=>useFetchImplementation2
});
var _fetch2;
try {
    _fetch2 = fetch;
} catch  {}
function useFetchImplementation2(fetchImplementation) {
    _fetch2 = fetchImplementation;
}
async function fetchRelayInformation(url) {
    return await (await fetch(url.replace("ws://", "http://").replace("wss://", "https://"), {
        headers: {
            Accept: "application/nostr+json"
        }
    })).json();
}
// nip13.ts
var nip13_exports = {};
__export(nip13_exports, {
    fastEventHash: ()=>fastEventHash,
    getPow: ()=>getPow,
    minePow: ()=>minePow
});
;
;
function getPow(hex) {
    let count = 0;
    for(let i2 = 0; i2 < 64; i2 += 8){
        const nibble = parseInt(hex.substring(i2, i2 + 8), 16);
        if (nibble === 0) {
            count += 32;
        } else {
            count += Math.clz32(nibble);
            break;
        }
    }
    return count;
}
function minePow(unsigned, difficulty) {
    let count = 0;
    const event = unsigned;
    const tag = [
        "nonce",
        count.toString(),
        difficulty.toString()
    ];
    event.tags.push(tag);
    while(true){
        const now2 = Math.floor(new Date().getTime() / 1e3);
        if (now2 !== event.created_at) {
            count = 0;
            event.created_at = now2;
        }
        tag[1] = (++count).toString();
        event.id = fastEventHash(event);
        if (getPow(event.id) >= difficulty) {
            break;
        }
    }
    return event;
}
function fastEventHash(evt) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(utf8Encoder.encode(JSON.stringify([
        0,
        evt.pubkey,
        evt.created_at,
        evt.kind,
        evt.tags,
        evt.content
    ]))));
}
// nip18.ts
var nip18_exports = {};
__export(nip18_exports, {
    finishRepostEvent: ()=>finishRepostEvent,
    getRepostedEvent: ()=>getRepostedEvent,
    getRepostedEventPointer: ()=>getRepostedEventPointer
});
function finishRepostEvent(t, reposted, relayUrl, privateKey) {
    return finalizeEvent({
        kind: Repost,
        tags: [
            ...t.tags ?? [],
            [
                "e",
                reposted.id,
                relayUrl
            ],
            [
                "p",
                reposted.pubkey
            ]
        ],
        content: t.content === "" ? "" : JSON.stringify(reposted),
        created_at: t.created_at
    }, privateKey);
}
function getRepostedEventPointer(event) {
    if (event.kind !== Repost) {
        return void 0;
    }
    let lastETag;
    let lastPTag;
    for(let i2 = event.tags.length - 1; i2 >= 0 && (lastETag === void 0 || lastPTag === void 0); i2--){
        const tag = event.tags[i2];
        if (tag.length >= 2) {
            if (tag[0] === "e" && lastETag === void 0) {
                lastETag = tag;
            } else if (tag[0] === "p" && lastPTag === void 0) {
                lastPTag = tag;
            }
        }
    }
    if (lastETag === void 0) {
        return void 0;
    }
    return {
        id: lastETag[1],
        relays: [
            lastETag[2],
            lastPTag?.[2]
        ].filter((x)=>typeof x === "string"),
        author: lastPTag?.[1]
    };
}
function getRepostedEvent(event, { skipVerification } = {}) {
    const pointer = getRepostedEventPointer(event);
    if (pointer === void 0 || event.content === "") {
        return void 0;
    }
    let repostedEvent;
    try {
        repostedEvent = JSON.parse(event.content);
    } catch (error) {
        return void 0;
    }
    if (repostedEvent.id !== pointer.id) {
        return void 0;
    }
    if (!skipVerification && !verifyEvent(repostedEvent)) {
        return void 0;
    }
    return repostedEvent;
}
// nip21.ts
var nip21_exports = {};
__export(nip21_exports, {
    NOSTR_URI_REGEX: ()=>NOSTR_URI_REGEX,
    parse: ()=>parse2,
    test: ()=>test
});
var NOSTR_URI_REGEX = new RegExp(`nostr:(${BECH32_REGEX.source})`);
function test(value) {
    return typeof value === "string" && new RegExp(`^${NOSTR_URI_REGEX.source}$`).test(value);
}
function parse2(uri) {
    const match = uri.match(new RegExp(`^${NOSTR_URI_REGEX.source}$`));
    if (!match) throw new Error(`Invalid Nostr URI: ${uri}`);
    return {
        uri: match[0],
        value: match[1],
        decoded: decode(match[1])
    };
}
// nip25.ts
var nip25_exports = {};
__export(nip25_exports, {
    finishReactionEvent: ()=>finishReactionEvent,
    getReactedEventPointer: ()=>getReactedEventPointer
});
function finishReactionEvent(t, reacted, privateKey) {
    const inheritedTags = reacted.tags.filter((tag)=>tag.length >= 2 && (tag[0] === "e" || tag[0] === "p"));
    return finalizeEvent({
        ...t,
        kind: Reaction,
        tags: [
            ...t.tags ?? [],
            ...inheritedTags,
            [
                "e",
                reacted.id
            ],
            [
                "p",
                reacted.pubkey
            ]
        ],
        content: t.content ?? "+"
    }, privateKey);
}
function getReactedEventPointer(event) {
    if (event.kind !== Reaction) {
        return void 0;
    }
    let lastETag;
    let lastPTag;
    for(let i2 = event.tags.length - 1; i2 >= 0 && (lastETag === void 0 || lastPTag === void 0); i2--){
        const tag = event.tags[i2];
        if (tag.length >= 2) {
            if (tag[0] === "e" && lastETag === void 0) {
                lastETag = tag;
            } else if (tag[0] === "p" && lastPTag === void 0) {
                lastPTag = tag;
            }
        }
    }
    if (lastETag === void 0 || lastPTag === void 0) {
        return void 0;
    }
    return {
        id: lastETag[1],
        relays: [
            lastETag[2],
            lastPTag[2]
        ].filter((x)=>x !== void 0),
        author: lastPTag[1]
    };
}
// nip27.ts
var nip27_exports = {};
__export(nip27_exports, {
    matchAll: ()=>matchAll,
    regex: ()=>regex,
    replaceAll: ()=>replaceAll
});
var regex = ()=>new RegExp(`\\b${NOSTR_URI_REGEX.source}\\b`, "g");
function* matchAll(content) {
    const matches = content.matchAll(regex());
    for (const match of matches){
        try {
            const [uri, value] = match;
            yield {
                uri,
                value,
                decoded: decode(value),
                start: match.index,
                end: match.index + uri.length
            };
        } catch (_e) {}
    }
}
function replaceAll(content, replacer) {
    return content.replaceAll(regex(), (uri, value)=>{
        return replacer({
            uri,
            value,
            decoded: decode(value)
        });
    });
}
// nip28.ts
var nip28_exports = {};
__export(nip28_exports, {
    channelCreateEvent: ()=>channelCreateEvent,
    channelHideMessageEvent: ()=>channelHideMessageEvent,
    channelMessageEvent: ()=>channelMessageEvent,
    channelMetadataEvent: ()=>channelMetadataEvent,
    channelMuteUserEvent: ()=>channelMuteUserEvent
});
var channelCreateEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finalizeEvent({
        kind: ChannelCreation,
        tags: [
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
var channelMetadataEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finalizeEvent({
        kind: ChannelMetadata,
        tags: [
            [
                "e",
                t.channel_create_event_id
            ],
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
var channelMessageEvent = (t, privateKey)=>{
    const tags = [
        [
            "e",
            t.channel_create_event_id,
            t.relay_url,
            "root"
        ]
    ];
    if (t.reply_to_channel_message_event_id) {
        tags.push([
            "e",
            t.reply_to_channel_message_event_id,
            t.relay_url,
            "reply"
        ]);
    }
    return finalizeEvent({
        kind: ChannelMessage,
        tags: [
            ...tags,
            ...t.tags ?? []
        ],
        content: t.content,
        created_at: t.created_at
    }, privateKey);
};
var channelHideMessageEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finalizeEvent({
        kind: ChannelHideMessage,
        tags: [
            [
                "e",
                t.channel_message_event_id
            ],
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
var channelMuteUserEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finalizeEvent({
        kind: ChannelMuteUser,
        tags: [
            [
                "p",
                t.pubkey_to_mute
            ],
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
// nip30.ts
var nip30_exports = {};
__export(nip30_exports, {
    EMOJI_SHORTCODE_REGEX: ()=>EMOJI_SHORTCODE_REGEX,
    matchAll: ()=>matchAll2,
    regex: ()=>regex2,
    replaceAll: ()=>replaceAll2
});
var EMOJI_SHORTCODE_REGEX = /:(\w+):/;
var regex2 = ()=>new RegExp(`\\B${EMOJI_SHORTCODE_REGEX.source}\\B`, "g");
function* matchAll2(content) {
    const matches = content.matchAll(regex2());
    for (const match of matches){
        try {
            const [shortcode, name] = match;
            yield {
                shortcode,
                name,
                start: match.index,
                end: match.index + shortcode.length
            };
        } catch (_e) {}
    }
}
function replaceAll2(content, replacer) {
    return content.replaceAll(regex2(), (shortcode, name)=>{
        return replacer({
            shortcode,
            name
        });
    });
}
// nip39.ts
var nip39_exports = {};
__export(nip39_exports, {
    useFetchImplementation: ()=>useFetchImplementation3,
    validateGithub: ()=>validateGithub
});
var _fetch3;
try {
    _fetch3 = fetch;
} catch  {}
function useFetchImplementation3(fetchImplementation) {
    _fetch3 = fetchImplementation;
}
async function validateGithub(pubkey, username, proof) {
    try {
        let res = await (await _fetch3(`https://gist.github.com/${username}/${proof}/raw`)).text();
        return res === `Verifying that I control the following Nostr public key: ${pubkey}`;
    } catch (_) {
        return false;
    }
}
// nip44.ts
var nip44_exports = {};
__export(nip44_exports, {
    decrypt: ()=>decrypt2,
    encrypt: ()=>encrypt2,
    getConversationKey: ()=>getConversationKey,
    v2: ()=>v2
});
;
;
;
;
;
;
;
;
var minPlaintextSize = 1;
var maxPlaintextSize = 65535;
function getConversationKey(privkeyA, pubkeyB) {
    const sharedX = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secp256k1"].getSharedSecret(privkeyA, "02" + pubkeyB).subarray(1, 33);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hkdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extract"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"], sharedX, "nip44-v2");
}
function getMessageKeys(conversationKey, nonce) {
    const keys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hkdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["expand"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"], conversationKey, nonce, 76);
    return {
        chacha_key: keys.subarray(0, 32),
        chacha_nonce: keys.subarray(32, 44),
        hmac_key: keys.subarray(44, 76)
    };
}
function calcPaddedLen(len) {
    if (!Number.isSafeInteger(len) || len < 1) throw new Error("expected positive integer");
    if (len <= 32) return 32;
    const nextPower = 1 << Math.floor(Math.log2(len - 1)) + 1;
    const chunk = nextPower <= 256 ? 32 : nextPower / 8;
    return chunk * (Math.floor((len - 1) / chunk) + 1);
}
function writeU16BE(num) {
    if (!Number.isSafeInteger(num) || num < minPlaintextSize || num > maxPlaintextSize) throw new Error("invalid plaintext size: must be between 1 and 65535 bytes");
    const arr = new Uint8Array(2);
    new DataView(arr.buffer).setUint16(0, num, false);
    return arr;
}
function pad(plaintext) {
    const unpadded = utf8Encoder.encode(plaintext);
    const unpaddedLen = unpadded.length;
    const prefix = writeU16BE(unpaddedLen);
    const suffix = new Uint8Array(calcPaddedLen(unpaddedLen) - unpaddedLen);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(prefix, unpadded, suffix);
}
function unpad(padded) {
    const unpaddedLen = new DataView(padded.buffer).getUint16(0);
    const unpadded = padded.subarray(2, 2 + unpaddedLen);
    if (unpaddedLen < minPlaintextSize || unpaddedLen > maxPlaintextSize || unpadded.length !== unpaddedLen || padded.length !== 2 + calcPaddedLen(unpaddedLen)) throw new Error("invalid padding");
    return utf8Decoder.decode(unpadded);
}
function hmacAad(key, message, aad) {
    if (aad.length !== 32) throw new Error("AAD associated data must be 32 bytes");
    const combined = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(aad, message);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hmac"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"], key, combined);
}
function decodePayload(payload) {
    if (typeof payload !== "string") throw new Error("payload must be a valid string");
    const plen = payload.length;
    if (plen < 132 || plen > 87472) throw new Error("invalid payload length: " + plen);
    if (payload[0] === "#") throw new Error("unknown encryption version");
    let data;
    try {
        data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(payload);
    } catch (error) {
        throw new Error("invalid base64: " + error.message);
    }
    const dlen = data.length;
    if (dlen < 99 || dlen > 65603) throw new Error("invalid data length: " + dlen);
    const vers = data[0];
    if (vers !== 2) throw new Error("unknown encryption version " + vers);
    return {
        nonce: data.subarray(1, 33),
        ciphertext: data.subarray(33, -32),
        mac: data.subarray(-32)
    };
}
function encrypt2(plaintext, conversationKey, nonce = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["randomBytes"])(32)) {
    const { chacha_key, chacha_nonce, hmac_key } = getMessageKeys(conversationKey, nonce);
    const padded = pad(plaintext);
    const ciphertext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$chacha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chacha20"])(chacha_key, chacha_nonce, padded);
    const mac = hmacAad(hmac_key, ciphertext, nonce);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(new Uint8Array([
        2
    ]), nonce, ciphertext, mac));
}
function decrypt2(payload, conversationKey) {
    const { nonce, ciphertext, mac } = decodePayload(payload);
    const { chacha_key, chacha_nonce, hmac_key } = getMessageKeys(conversationKey, nonce);
    const calculatedMac = hmacAad(hmac_key, ciphertext, nonce);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equalBytes"])(calculatedMac, mac)) throw new Error("invalid MAC");
    const padded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$chacha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chacha20"])(chacha_key, chacha_nonce, ciphertext);
    return unpad(padded);
}
var v2 = {
    utils: {
        getConversationKey,
        calcPaddedLen
    },
    encrypt: encrypt2,
    decrypt: decrypt2
};
// nip47.ts
var nip47_exports = {};
__export(nip47_exports, {
    makeNwcRequestEvent: ()=>makeNwcRequestEvent,
    parseConnectionString: ()=>parseConnectionString
});
function parseConnectionString(connectionString) {
    const { pathname, searchParams } = new URL(connectionString);
    const pubkey = pathname;
    const relay = searchParams.get("relay");
    const secret = searchParams.get("secret");
    if (!pubkey || !relay || !secret) {
        throw new Error("invalid connection string");
    }
    return {
        pubkey,
        relay,
        secret
    };
}
async function makeNwcRequestEvent(pubkey, secretKey, invoice) {
    const content = {
        method: "pay_invoice",
        params: {
            invoice
        }
    };
    const encryptedContent = await encrypt(secretKey, pubkey, JSON.stringify(content));
    const eventTemplate = {
        kind: NWCWalletRequest,
        created_at: Math.round(Date.now() / 1e3),
        content: encryptedContent,
        tags: [
            [
                "p",
                pubkey
            ]
        ]
    };
    return finalizeEvent(eventTemplate, secretKey);
}
// nip57.ts
var nip57_exports = {};
__export(nip57_exports, {
    getZapEndpoint: ()=>getZapEndpoint,
    makeZapReceipt: ()=>makeZapReceipt,
    makeZapRequest: ()=>makeZapRequest,
    useFetchImplementation: ()=>useFetchImplementation4,
    validateZapRequest: ()=>validateZapRequest
});
;
var _fetch4;
try {
    _fetch4 = fetch;
} catch  {}
function useFetchImplementation4(fetchImplementation) {
    _fetch4 = fetchImplementation;
}
async function getZapEndpoint(metadata) {
    try {
        let lnurl = "";
        let { lud06, lud16 } = JSON.parse(metadata.content);
        if (lud06) {
            let { words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].decode(lud06, 1e3);
            let data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].fromWords(words);
            lnurl = utf8Decoder.decode(data);
        } else if (lud16) {
            let [name, domain] = lud16.split("@");
            lnurl = new URL(`/.well-known/lnurlp/${name}`, `https://${domain}`).toString();
        } else {
            return null;
        }
        let res = await _fetch4(lnurl);
        let body = await res.json();
        if (body.allowsNostr && body.nostrPubkey) {
            return body.callback;
        }
    } catch (err) {}
    return null;
}
function makeZapRequest({ profile, event, amount, relays, comment = "" }) {
    if (!amount) throw new Error("amount not given");
    if (!profile) throw new Error("profile not given");
    let zr = {
        kind: 9734,
        created_at: Math.round(Date.now() / 1e3),
        content: comment,
        tags: [
            [
                "p",
                profile
            ],
            [
                "amount",
                amount.toString()
            ],
            [
                "relays",
                ...relays
            ]
        ]
    };
    if (event) {
        zr.tags.push([
            "e",
            event
        ]);
    }
    return zr;
}
function validateZapRequest(zapRequestString) {
    let zapRequest;
    try {
        zapRequest = JSON.parse(zapRequestString);
    } catch (err) {
        return "Invalid zap request JSON.";
    }
    if (!validateEvent(zapRequest)) return "Zap request is not a valid Nostr event.";
    if (!verifyEvent(zapRequest)) return "Invalid signature on zap request.";
    let p = zapRequest.tags.find(([t, v])=>t === "p" && v);
    if (!p) return "Zap request doesn't have a 'p' tag.";
    if (!p[1].match(/^[a-f0-9]{64}$/)) return "Zap request 'p' tag is not valid hex.";
    let e = zapRequest.tags.find(([t, v])=>t === "e" && v);
    if (e && !e[1].match(/^[a-f0-9]{64}$/)) return "Zap request 'e' tag is not valid hex.";
    let relays = zapRequest.tags.find(([t, v])=>t === "relays" && v);
    if (!relays) return "Zap request doesn't have a 'relays' tag.";
    return null;
}
function makeZapReceipt({ zapRequest, preimage, bolt11, paidAt }) {
    let zr = JSON.parse(zapRequest);
    let tagsFromZapRequest = zr.tags.filter(([t])=>t === "e" || t === "p" || t === "a");
    let zap = {
        kind: 9735,
        created_at: Math.round(paidAt.getTime() / 1e3),
        content: "",
        tags: [
            ...tagsFromZapRequest,
            [
                "P",
                zr.pubkey
            ],
            [
                "bolt11",
                bolt11
            ],
            [
                "description",
                zapRequest
            ]
        ]
    };
    if (preimage) {
        zap.tags.push([
            "preimage",
            preimage
        ]);
    }
    return zap;
}
// nip59.ts
var nip59_exports = {};
__export(nip59_exports, {
    createRumor: ()=>createRumor,
    createSeal: ()=>createSeal,
    createWrap: ()=>createWrap,
    unwrapEvent: ()=>unwrapEvent,
    unwrapManyEvents: ()=>unwrapManyEvents,
    wrapEvent: ()=>wrapEvent,
    wrapManyEvents: ()=>wrapManyEvents
});
var TWO_DAYS = 2 * 24 * 60 * 60;
var now = ()=>Math.round(Date.now() / 1e3);
var randomNow = ()=>Math.round(now() - Math.random() * TWO_DAYS);
var nip44ConversationKey = (privateKey, publicKey)=>getConversationKey(privateKey, publicKey);
var nip44Encrypt = (data, privateKey, publicKey)=>encrypt2(JSON.stringify(data), nip44ConversationKey(privateKey, publicKey));
var nip44Decrypt = (data, privateKey)=>JSON.parse(decrypt2(data.content, nip44ConversationKey(privateKey, data.pubkey)));
function createRumor(event, privateKey) {
    const rumor = {
        created_at: now(),
        content: "",
        tags: [],
        ...event,
        pubkey: getPublicKey(privateKey)
    };
    rumor.id = getEventHash(rumor);
    return rumor;
}
function createSeal(rumor, privateKey, recipientPublicKey) {
    return finalizeEvent({
        kind: Seal,
        content: nip44Encrypt(rumor, privateKey, recipientPublicKey),
        created_at: randomNow(),
        tags: []
    }, privateKey);
}
function createWrap(seal, recipientPublicKey) {
    const randomKey = generateSecretKey();
    return finalizeEvent({
        kind: GiftWrap,
        content: nip44Encrypt(seal, randomKey, recipientPublicKey),
        created_at: randomNow(),
        tags: [
            [
                "p",
                recipientPublicKey
            ]
        ]
    }, randomKey);
}
function wrapEvent(event, senderPrivateKey, recipientPublicKey) {
    const rumor = createRumor(event, senderPrivateKey);
    const seal = createSeal(rumor, senderPrivateKey, recipientPublicKey);
    return createWrap(seal, recipientPublicKey);
}
function wrapManyEvents(event, senderPrivateKey, recipientsPublicKeys) {
    if (!recipientsPublicKeys || recipientsPublicKeys.length === 0) {
        throw new Error("At least one recipient is required.");
    }
    const senderPublicKey = getPublicKey(senderPrivateKey);
    const wrappeds = [
        wrapEvent(event, senderPrivateKey, senderPublicKey)
    ];
    recipientsPublicKeys.forEach((recipientPublicKey)=>{
        wrappeds.push(wrapEvent(event, senderPrivateKey, recipientPublicKey));
    });
    return wrappeds;
}
function unwrapEvent(wrap, recipientPrivateKey) {
    const unwrappedSeal = nip44Decrypt(wrap, recipientPrivateKey);
    return nip44Decrypt(unwrappedSeal, recipientPrivateKey);
}
function unwrapManyEvents(wrappedEvents, recipientPrivateKey) {
    let unwrappedEvents = [];
    wrappedEvents.forEach((e)=>{
        unwrappedEvents.push(unwrapEvent(e, recipientPrivateKey));
    });
    unwrappedEvents.sort((a, b)=>a.created_at - b.created_at);
    return unwrappedEvents;
}
// nip98.ts
var nip98_exports = {};
__export(nip98_exports, {
    getToken: ()=>getToken,
    hashPayload: ()=>hashPayload,
    unpackEventFromToken: ()=>unpackEventFromToken,
    validateEvent: ()=>validateEvent2,
    validateEventKind: ()=>validateEventKind,
    validateEventMethodTag: ()=>validateEventMethodTag,
    validateEventPayloadTag: ()=>validateEventPayloadTag,
    validateEventTimestamp: ()=>validateEventTimestamp,
    validateEventUrlTag: ()=>validateEventUrlTag,
    validateToken: ()=>validateToken
});
;
;
;
var _authorizationScheme = "Nostr ";
async function getToken(loginUrl, httpMethod, sign, includeAuthorizationScheme = false, payload) {
    const event = {
        kind: HTTPAuth,
        tags: [
            [
                "u",
                loginUrl
            ],
            [
                "method",
                httpMethod
            ]
        ],
        created_at: Math.round(new Date().getTime() / 1e3),
        content: ""
    };
    if (payload) {
        event.tags.push([
            "payload",
            hashPayload(payload)
        ]);
    }
    const signedEvent = await sign(event);
    const authorizationScheme = includeAuthorizationScheme ? _authorizationScheme : "";
    return authorizationScheme + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode(utf8Encoder.encode(JSON.stringify(signedEvent)));
}
async function validateToken(token, url, method) {
    const event = await unpackEventFromToken(token).catch((error)=>{
        throw error;
    });
    const valid = await validateEvent2(event, url, method).catch((error)=>{
        throw error;
    });
    return valid;
}
async function unpackEventFromToken(token) {
    if (!token) {
        throw new Error("Missing token");
    }
    token = token.replace(_authorizationScheme, "");
    const eventB64 = utf8Decoder.decode(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(token));
    if (!eventB64 || eventB64.length === 0 || !eventB64.startsWith("{")) {
        throw new Error("Invalid token");
    }
    const event = JSON.parse(eventB64);
    return event;
}
function validateEventTimestamp(event) {
    if (!event.created_at) {
        return false;
    }
    return Math.round(new Date().getTime() / 1e3) - event.created_at < 60;
}
function validateEventKind(event) {
    return event.kind === HTTPAuth;
}
function validateEventUrlTag(event, url) {
    const urlTag = event.tags.find((t)=>t[0] === "u");
    if (!urlTag) {
        return false;
    }
    return urlTag.length > 0 && urlTag[1] === url;
}
function validateEventMethodTag(event, method) {
    const methodTag = event.tags.find((t)=>t[0] === "method");
    if (!methodTag) {
        return false;
    }
    return methodTag.length > 0 && methodTag[1].toLowerCase() === method.toLowerCase();
}
function hashPayload(payload) {
    const hash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(utf8Encoder.encode(JSON.stringify(payload)));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nostr$2d$dev$2d$kit$2f$ndk$2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(hash);
}
function validateEventPayloadTag(event, payload) {
    const payloadTag = event.tags.find((t)=>t[0] === "payload");
    if (!payloadTag) {
        return false;
    }
    const payloadHash = hashPayload(payload);
    return payloadTag.length > 0 && payloadTag[1] === payloadHash;
}
async function validateEvent2(event, url, method, body) {
    if (!verifyEvent(event)) {
        throw new Error("Invalid nostr event, signature invalid");
    }
    if (!validateEventKind(event)) {
        throw new Error("Invalid nostr event, kind invalid");
    }
    if (!validateEventTimestamp(event)) {
        throw new Error("Invalid nostr event, created_at timestamp invalid");
    }
    if (!validateEventUrlTag(event, url)) {
        throw new Error("Invalid nostr event, url tag invalid");
    }
    if (!validateEventMethodTag(event, method)) {
        throw new Error("Invalid nostr event, method tag invalid");
    }
    if (Boolean(body) && typeof body === "object" && Object.keys(body).length > 0) {
        if (!validateEventPayloadTag(event, body)) {
            throw new Error("Invalid nostr event, payload tag does not match request body hash");
        }
    }
    return true;
}
;

})()),
"[project]/node_modules/nostr-tools/lib/esm/index.js [app-client] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, k: __turbopack_refresh__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Kind": ()=>Kind,
    "SimplePool": ()=>SimplePool,
    "eventsGenerator": ()=>eventsGenerator,
    "finishEvent": ()=>finishEvent,
    "fj": ()=>fakejson_exports,
    "generatePrivateKey": ()=>generatePrivateKey,
    "getBlankEvent": ()=>getBlankEvent,
    "getEventHash": ()=>getEventHash,
    "getPublicKey": ()=>getPublicKey,
    "getSignature": ()=>getSignature,
    "matchFilter": ()=>matchFilter,
    "matchFilters": ()=>matchFilters,
    "mergeFilters": ()=>mergeFilters,
    "nip04": ()=>nip04_exports,
    "nip05": ()=>nip05_exports,
    "nip06": ()=>nip06_exports,
    "nip10": ()=>nip10_exports,
    "nip13": ()=>nip13_exports,
    "nip18": ()=>nip18_exports,
    "nip19": ()=>nip19_exports,
    "nip21": ()=>nip21_exports,
    "nip25": ()=>nip25_exports,
    "nip26": ()=>nip26_exports,
    "nip27": ()=>nip27_exports,
    "nip28": ()=>nip28_exports,
    "nip39": ()=>nip39_exports,
    "nip42": ()=>nip42_exports,
    "nip44": ()=>nip44_exports,
    "nip47": ()=>nip47_exports,
    "nip57": ()=>nip57_exports,
    "nip98": ()=>nip98_exports,
    "parseReferences": ()=>parseReferences,
    "relayInit": ()=>relayInit,
    "serializeEvent": ()=>serializeEvent,
    "signEvent": ()=>signEvent,
    "utils": ()=>utils_exports,
    "validateEvent": ()=>validateEvent,
    "verifiedSymbol": ()=>verifiedSymbol,
    "verifySignature": ()=>verifySignature
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/node_modules/@noble/hashes/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/node_modules/@noble/hashes/esm/sha256.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/node_modules/@scure/base/lib/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$wordlists$2f$english$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@scure/bip39/esm/wordlists/english.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@scure/bip39/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip32$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@scure/bip32/lib/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$chacha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/chacha.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@noble/ciphers/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hkdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/node_modules/@noble/hashes/esm/hkdf.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/nostr-tools/node_modules/@noble/hashes/esm/hmac.js [app-client] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
var __defProp = Object.defineProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
;
;
function generatePrivateKey() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].utils.randomPrivateKey());
}
function getPublicKey(privateKey) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].getPublicKey(privateKey));
}
;
;
;
// utils.ts
var utils_exports = {};
__export(utils_exports, {
    MessageNode: ()=>MessageNode,
    MessageQueue: ()=>MessageQueue,
    insertEventIntoAscendingList: ()=>insertEventIntoAscendingList,
    insertEventIntoDescendingList: ()=>insertEventIntoDescendingList,
    normalizeURL: ()=>normalizeURL,
    utf8Decoder: ()=>utf8Decoder,
    utf8Encoder: ()=>utf8Encoder
});
var utf8Decoder = new TextDecoder("utf-8");
var utf8Encoder = new TextEncoder();
function normalizeURL(url) {
    let p = new URL(url);
    p.pathname = p.pathname.replace(/\/+/g, "/");
    if (p.pathname.endsWith("/")) p.pathname = p.pathname.slice(0, -1);
    if (p.port === "80" && p.protocol === "ws:" || p.port === "443" && p.protocol === "wss:") p.port = "";
    p.searchParams.sort();
    p.hash = "";
    return p.toString();
}
function insertEventIntoDescendingList(sortedArray, event) {
    let start = 0;
    let end = sortedArray.length - 1;
    let midPoint;
    let position = start;
    if (end < 0) {
        position = 0;
    } else if (event.created_at < sortedArray[end].created_at) {
        position = end + 1;
    } else if (event.created_at >= sortedArray[start].created_at) {
        position = start;
    } else while(true){
        if (end <= start + 1) {
            position = end;
            break;
        }
        midPoint = Math.floor(start + (end - start) / 2);
        if (sortedArray[midPoint].created_at > event.created_at) {
            start = midPoint;
        } else if (sortedArray[midPoint].created_at < event.created_at) {
            end = midPoint;
        } else {
            position = midPoint;
            break;
        }
    }
    if (sortedArray[position]?.id !== event.id) {
        return [
            ...sortedArray.slice(0, position),
            event,
            ...sortedArray.slice(position)
        ];
    }
    return sortedArray;
}
function insertEventIntoAscendingList(sortedArray, event) {
    let start = 0;
    let end = sortedArray.length - 1;
    let midPoint;
    let position = start;
    if (end < 0) {
        position = 0;
    } else if (event.created_at > sortedArray[end].created_at) {
        position = end + 1;
    } else if (event.created_at <= sortedArray[start].created_at) {
        position = start;
    } else while(true){
        if (end <= start + 1) {
            position = end;
            break;
        }
        midPoint = Math.floor(start + (end - start) / 2);
        if (sortedArray[midPoint].created_at < event.created_at) {
            start = midPoint;
        } else if (sortedArray[midPoint].created_at > event.created_at) {
            end = midPoint;
        } else {
            position = midPoint;
            break;
        }
    }
    if (sortedArray[position]?.id !== event.id) {
        return [
            ...sortedArray.slice(0, position),
            event,
            ...sortedArray.slice(position)
        ];
    }
    return sortedArray;
}
var MessageNode = class {
    _value;
    _next;
    get value() {
        return this._value;
    }
    set value(message) {
        this._value = message;
    }
    get next() {
        return this._next;
    }
    set next(node) {
        this._next = node;
    }
    constructor(message){
        this._value = message;
        this._next = null;
    }
};
var MessageQueue = class {
    _first;
    _last;
    get first() {
        return this._first;
    }
    set first(messageNode) {
        this._first = messageNode;
    }
    get last() {
        return this._last;
    }
    set last(messageNode) {
        this._last = messageNode;
    }
    _size;
    get size() {
        return this._size;
    }
    set size(v) {
        this._size = v;
    }
    constructor(){
        this._first = null;
        this._last = null;
        this._size = 0;
    }
    enqueue(message) {
        const newNode = new MessageNode(message);
        if (this._size === 0 || !this._last) {
            this._first = newNode;
            this._last = newNode;
        } else {
            this._last.next = newNode;
            this._last = newNode;
        }
        this._size++;
        return true;
    }
    dequeue() {
        if (this._size === 0 || !this._first) return null;
        let prev = this._first;
        this._first = prev.next;
        prev.next = null;
        this._size--;
        return prev.value;
    }
};
// event.ts
var verifiedSymbol = Symbol("verified");
var Kind = /* @__PURE__ */ ((Kind3)=>{
    Kind3[Kind3["Metadata"] = 0] = "Metadata";
    Kind3[Kind3["Text"] = 1] = "Text";
    Kind3[Kind3["RecommendRelay"] = 2] = "RecommendRelay";
    Kind3[Kind3["Contacts"] = 3] = "Contacts";
    Kind3[Kind3["EncryptedDirectMessage"] = 4] = "EncryptedDirectMessage";
    Kind3[Kind3["EventDeletion"] = 5] = "EventDeletion";
    Kind3[Kind3["Repost"] = 6] = "Repost";
    Kind3[Kind3["Reaction"] = 7] = "Reaction";
    Kind3[Kind3["BadgeAward"] = 8] = "BadgeAward";
    Kind3[Kind3["ChannelCreation"] = 40] = "ChannelCreation";
    Kind3[Kind3["ChannelMetadata"] = 41] = "ChannelMetadata";
    Kind3[Kind3["ChannelMessage"] = 42] = "ChannelMessage";
    Kind3[Kind3["ChannelHideMessage"] = 43] = "ChannelHideMessage";
    Kind3[Kind3["ChannelMuteUser"] = 44] = "ChannelMuteUser";
    Kind3[Kind3["Blank"] = 255] = "Blank";
    Kind3[Kind3["Report"] = 1984] = "Report";
    Kind3[Kind3["ZapRequest"] = 9734] = "ZapRequest";
    Kind3[Kind3["Zap"] = 9735] = "Zap";
    Kind3[Kind3["RelayList"] = 10002] = "RelayList";
    Kind3[Kind3["ClientAuth"] = 22242] = "ClientAuth";
    Kind3[Kind3["NwcRequest"] = 23194] = "NwcRequest";
    Kind3[Kind3["HttpAuth"] = 27235] = "HttpAuth";
    Kind3[Kind3["ProfileBadge"] = 30008] = "ProfileBadge";
    Kind3[Kind3["BadgeDefinition"] = 30009] = "BadgeDefinition";
    Kind3[Kind3["Article"] = 30023] = "Article";
    Kind3[Kind3["FileMetadata"] = 1063] = "FileMetadata";
    return Kind3;
})(Kind || {});
function getBlankEvent(kind = 255 /* Blank */ ) {
    return {
        kind,
        content: "",
        tags: [],
        created_at: 0
    };
}
function finishEvent(t, privateKey) {
    const event = t;
    event.pubkey = getPublicKey(privateKey);
    event.id = getEventHash(event);
    event.sig = getSignature(event, privateKey);
    event[verifiedSymbol] = true;
    return event;
}
function serializeEvent(evt) {
    if (!validateEvent(evt)) throw new Error("can't serialize event with wrong or missing properties");
    return JSON.stringify([
        0,
        evt.pubkey,
        evt.created_at,
        evt.kind,
        evt.tags,
        evt.content
    ]);
}
function getEventHash(event) {
    let eventHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(utf8Encoder.encode(serializeEvent(event)));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(eventHash);
}
var isRecord = (obj)=>obj instanceof Object;
function validateEvent(event) {
    if (!isRecord(event)) return false;
    if (typeof event.kind !== "number") return false;
    if (typeof event.content !== "string") return false;
    if (typeof event.created_at !== "number") return false;
    if (typeof event.pubkey !== "string") return false;
    if (!event.pubkey.match(/^[a-f0-9]{64}$/)) return false;
    if (!Array.isArray(event.tags)) return false;
    for(let i = 0; i < event.tags.length; i++){
        let tag = event.tags[i];
        if (!Array.isArray(tag)) return false;
        for(let j = 0; j < tag.length; j++){
            if (typeof tag[j] === "object") return false;
        }
    }
    return true;
}
function verifySignature(event) {
    if (typeof event[verifiedSymbol] === "boolean") return event[verifiedSymbol];
    const hash = getEventHash(event);
    if (hash !== event.id) {
        return event[verifiedSymbol] = false;
    }
    try {
        return event[verifiedSymbol] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].verify(event.sig, hash, event.pubkey);
    } catch (err) {
        return event[verifiedSymbol] = false;
    }
}
function signEvent(event, key) {
    console.warn("nostr-tools: `signEvent` is deprecated and will be removed or changed in the future. Please use `getSignature` instead.");
    return getSignature(event, key);
}
function getSignature(event, key) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].sign(getEventHash(event), key));
}
// filter.ts
function matchFilter(filter, event) {
    if (filter.ids && filter.ids.indexOf(event.id) === -1) {
        if (!filter.ids.some((prefix)=>event.id.startsWith(prefix))) {
            return false;
        }
    }
    if (filter.kinds && filter.kinds.indexOf(event.kind) === -1) return false;
    if (filter.authors && filter.authors.indexOf(event.pubkey) === -1) {
        if (!filter.authors.some((prefix)=>event.pubkey.startsWith(prefix))) {
            return false;
        }
    }
    for(let f in filter){
        if (f[0] === "#") {
            let tagName = f.slice(1);
            let values = filter[`#${tagName}`];
            if (values && !event.tags.find(([t, v])=>t === f.slice(1) && values.indexOf(v) !== -1)) return false;
        }
    }
    if (filter.since && event.created_at < filter.since) return false;
    if (filter.until && event.created_at > filter.until) return false;
    return true;
}
function matchFilters(filters, event) {
    for(let i = 0; i < filters.length; i++){
        if (matchFilter(filters[i], event)) return true;
    }
    return false;
}
function mergeFilters(...filters) {
    let result = {};
    for(let i = 0; i < filters.length; i++){
        let filter = filters[i];
        Object.entries(filter).forEach(([property, values])=>{
            if (property === "kinds" || property === "ids" || property === "authors" || property[0] === "#") {
                result[property] = result[property] || [];
                for(let v = 0; v < values.length; v++){
                    let value = values[v];
                    if (!result[property].includes(value)) result[property].push(value);
                }
            }
        });
        if (filter.limit && (!result.limit || filter.limit > result.limit)) result.limit = filter.limit;
        if (filter.until && (!result.until || filter.until > result.until)) result.until = filter.until;
        if (filter.since && (!result.since || filter.since < result.since)) result.since = filter.since;
    }
    return result;
}
// fakejson.ts
var fakejson_exports = {};
__export(fakejson_exports, {
    getHex64: ()=>getHex64,
    getInt: ()=>getInt,
    getSubscriptionId: ()=>getSubscriptionId,
    matchEventId: ()=>matchEventId,
    matchEventKind: ()=>matchEventKind,
    matchEventPubkey: ()=>matchEventPubkey
});
function getHex64(json, field) {
    let len = field.length + 3;
    let idx = json.indexOf(`"${field}":`) + len;
    let s = json.slice(idx).indexOf(`"`) + idx + 1;
    return json.slice(s, s + 64);
}
function getInt(json, field) {
    let len = field.length;
    let idx = json.indexOf(`"${field}":`) + len + 3;
    let sliced = json.slice(idx);
    let end = Math.min(sliced.indexOf(","), sliced.indexOf("}"));
    return parseInt(sliced.slice(0, end), 10);
}
function getSubscriptionId(json) {
    let idx = json.slice(0, 22).indexOf(`"EVENT"`);
    if (idx === -1) return null;
    let pstart = json.slice(idx + 7 + 1).indexOf(`"`);
    if (pstart === -1) return null;
    let start = idx + 7 + 1 + pstart;
    let pend = json.slice(start + 1, 80).indexOf(`"`);
    if (pend === -1) return null;
    let end = start + 1 + pend;
    return json.slice(start + 1, end);
}
function matchEventId(json, id) {
    return id === getHex64(json, "id");
}
function matchEventPubkey(json, pubkey) {
    return pubkey === getHex64(json, "pubkey");
}
function matchEventKind(json, kind) {
    return kind === getInt(json, "kind");
}
// relay.ts
var newListeners = ()=>({
        connect: [],
        disconnect: [],
        error: [],
        notice: [],
        auth: []
    });
function relayInit(url, options = {}) {
    let { listTimeout = 3e3, getTimeout = 3e3, countTimeout = 3e3 } = options;
    var ws;
    var openSubs = {};
    var listeners = newListeners();
    var subListeners = {};
    var pubListeners = {};
    var connectionPromise;
    async function connectRelay() {
        if (connectionPromise) return connectionPromise;
        connectionPromise = new Promise((resolve, reject)=>{
            try {
                ws = new WebSocket(url);
            } catch (err) {
                reject(err);
            }
            ws.onopen = ()=>{
                listeners.connect.forEach((cb)=>cb());
                resolve();
            };
            ws.onerror = ()=>{
                connectionPromise = void 0;
                listeners.error.forEach((cb)=>cb());
                reject();
            };
            ws.onclose = async ()=>{
                connectionPromise = void 0;
                listeners.disconnect.forEach((cb)=>cb());
            };
            let incomingMessageQueue = new MessageQueue();
            let handleNextInterval;
            ws.onmessage = (e)=>{
                incomingMessageQueue.enqueue(e.data);
                if (!handleNextInterval) {
                    handleNextInterval = setInterval(handleNext, 0);
                }
            };
            function handleNext() {
                if (incomingMessageQueue.size === 0) {
                    clearInterval(handleNextInterval);
                    handleNextInterval = null;
                    return;
                }
                var json = incomingMessageQueue.dequeue();
                if (!json) return;
                let subid = getSubscriptionId(json);
                if (subid) {
                    let so = openSubs[subid];
                    if (so && so.alreadyHaveEvent && so.alreadyHaveEvent(getHex64(json, "id"), url)) {
                        return;
                    }
                }
                try {
                    let data = JSON.parse(json);
                    switch(data[0]){
                        case "EVENT":
                            {
                                let id2 = data[1];
                                let event = data[2];
                                if (validateEvent(event) && openSubs[id2] && (openSubs[id2].skipVerification || verifySignature(event)) && matchFilters(openSubs[id2].filters, event)) {
                                    openSubs[id2];
                                    (subListeners[id2]?.event || []).forEach((cb)=>cb(event));
                                }
                                return;
                            }
                        case "COUNT":
                            let id = data[1];
                            let payload = data[2];
                            if (openSubs[id]) {
                                ;
                                (subListeners[id]?.count || []).forEach((cb)=>cb(payload));
                            }
                            return;
                        case "EOSE":
                            {
                                let id2 = data[1];
                                if (id2 in subListeners) {
                                    subListeners[id2].eose.forEach((cb)=>cb());
                                    subListeners[id2].eose = [];
                                }
                                return;
                            }
                        case "OK":
                            {
                                let id2 = data[1];
                                let ok = data[2];
                                let reason = data[3] || "";
                                if (id2 in pubListeners) {
                                    let { resolve: resolve2, reject: reject2 } = pubListeners[id2];
                                    if (ok) resolve2(null);
                                    else reject2(new Error(reason));
                                }
                                return;
                            }
                        case "NOTICE":
                            let notice = data[1];
                            listeners.notice.forEach((cb)=>cb(notice));
                            return;
                        case "AUTH":
                            {
                                let challenge = data[1];
                                listeners.auth?.forEach((cb)=>cb(challenge));
                                return;
                            }
                    }
                } catch (err) {
                    return;
                }
            }
        });
        return connectionPromise;
    }
    function connected() {
        return ws?.readyState === 1;
    }
    async function connect() {
        if (connected()) return;
        await connectRelay();
    }
    async function trySend(params) {
        let msg = JSON.stringify(params);
        if (!connected()) {
            await new Promise((resolve)=>setTimeout(resolve, 1e3));
            if (!connected()) {
                return;
            }
        }
        try {
            ws.send(msg);
        } catch (err) {
            console.log(err);
        }
    }
    const sub = (filters, { verb = "REQ", skipVerification = false, alreadyHaveEvent = null, id = Math.random().toString().slice(2) } = {})=>{
        let subid = id;
        openSubs[subid] = {
            id: subid,
            filters,
            skipVerification,
            alreadyHaveEvent
        };
        trySend([
            verb,
            subid,
            ...filters
        ]);
        let subscription = {
            sub: (newFilters, newOpts = {})=>sub(newFilters || filters, {
                    skipVerification: newOpts.skipVerification || skipVerification,
                    alreadyHaveEvent: newOpts.alreadyHaveEvent || alreadyHaveEvent,
                    id: subid
                }),
            unsub: ()=>{
                delete openSubs[subid];
                delete subListeners[subid];
                trySend([
                    "CLOSE",
                    subid
                ]);
            },
            on: (type, cb)=>{
                subListeners[subid] = subListeners[subid] || {
                    event: [],
                    count: [],
                    eose: []
                };
                subListeners[subid][type].push(cb);
            },
            off: (type, cb)=>{
                let listeners2 = subListeners[subid];
                let idx = listeners2[type].indexOf(cb);
                if (idx >= 0) listeners2[type].splice(idx, 1);
            },
            get events () {
                return eventsGenerator(subscription);
            }
        };
        return subscription;
    };
    function _publishEvent(event, type) {
        return new Promise((resolve, reject)=>{
            if (!event.id) {
                reject(new Error(`event ${event} has no id`));
                return;
            }
            let id = event.id;
            trySend([
                type,
                event
            ]);
            pubListeners[id] = {
                resolve,
                reject
            };
        });
    }
    return {
        url,
        sub,
        on: (type, cb)=>{
            listeners[type].push(cb);
            if (type === "connect" && ws?.readyState === 1) {
                ;
                cb();
            }
        },
        off: (type, cb)=>{
            let index = listeners[type].indexOf(cb);
            if (index !== -1) listeners[type].splice(index, 1);
        },
        list: (filters, opts)=>new Promise((resolve)=>{
                let s = sub(filters, opts);
                let events = [];
                let timeout = setTimeout(()=>{
                    s.unsub();
                    resolve(events);
                }, listTimeout);
                s.on("eose", ()=>{
                    s.unsub();
                    clearTimeout(timeout);
                    resolve(events);
                });
                s.on("event", (event)=>{
                    events.push(event);
                });
            }),
        get: (filter, opts)=>new Promise((resolve)=>{
                let s = sub([
                    filter
                ], opts);
                let timeout = setTimeout(()=>{
                    s.unsub();
                    resolve(null);
                }, getTimeout);
                s.on("event", (event)=>{
                    s.unsub();
                    clearTimeout(timeout);
                    resolve(event);
                });
            }),
        count: (filters)=>new Promise((resolve)=>{
                let s = sub(filters, {
                    ...sub,
                    verb: "COUNT"
                });
                let timeout = setTimeout(()=>{
                    s.unsub();
                    resolve(null);
                }, countTimeout);
                s.on("count", (event)=>{
                    s.unsub();
                    clearTimeout(timeout);
                    resolve(event);
                });
            }),
        async publish (event) {
            await _publishEvent(event, "EVENT");
        },
        async auth (event) {
            await _publishEvent(event, "AUTH");
        },
        connect,
        close () {
            listeners = newListeners();
            subListeners = {};
            pubListeners = {};
            if (ws?.readyState === WebSocket.OPEN) {
                ws.close();
            }
        },
        get status () {
            return ws?.readyState ?? 3;
        }
    };
}
async function* eventsGenerator(sub) {
    let nextResolve;
    const eventQueue = [];
    const pushToQueue = (event)=>{
        if (nextResolve) {
            nextResolve(event);
            nextResolve = void 0;
        } else {
            eventQueue.push(event);
        }
    };
    sub.on("event", pushToQueue);
    try {
        while(true){
            if (eventQueue.length > 0) {
                yield eventQueue.shift();
            } else {
                const event = await new Promise((resolve)=>{
                    nextResolve = resolve;
                });
                yield event;
            }
        }
    } finally{
        sub.off("event", pushToQueue);
    }
}
// pool.ts
var SimplePool = class {
    _conn;
    _seenOn = {};
    batchedByKey = {};
    eoseSubTimeout;
    getTimeout;
    seenOnEnabled = true;
    batchInterval = 100;
    constructor(options = {}){
        this._conn = {};
        this.eoseSubTimeout = options.eoseSubTimeout || 3400;
        this.getTimeout = options.getTimeout || 3400;
        this.seenOnEnabled = options.seenOnEnabled !== false;
        this.batchInterval = options.batchInterval || 100;
    }
    close(relays) {
        relays.forEach((url)=>{
            let relay = this._conn[normalizeURL(url)];
            if (relay) relay.close();
        });
    }
    async ensureRelay(url) {
        const nm = normalizeURL(url);
        if (!this._conn[nm]) {
            this._conn[nm] = relayInit(nm, {
                getTimeout: this.getTimeout * 0.9,
                listTimeout: this.getTimeout * 0.9
            });
        }
        const relay = this._conn[nm];
        await relay.connect();
        return relay;
    }
    sub(relays, filters, opts) {
        let _knownIds = /* @__PURE__ */ new Set();
        let modifiedOpts = {
            ...opts || {}
        };
        modifiedOpts.alreadyHaveEvent = (id, url)=>{
            if (opts?.alreadyHaveEvent?.(id, url)) {
                return true;
            }
            if (this.seenOnEnabled) {
                let set = this._seenOn[id] || /* @__PURE__ */ new Set();
                set.add(url);
                this._seenOn[id] = set;
            }
            return _knownIds.has(id);
        };
        let subs = [];
        let eventListeners = /* @__PURE__ */ new Set();
        let eoseListeners = /* @__PURE__ */ new Set();
        let eosesMissing = relays.length;
        let eoseSent = false;
        let eoseTimeout = setTimeout(()=>{
            eoseSent = true;
            for (let cb of eoseListeners.values())cb();
        }, opts?.eoseSubTimeout || this.eoseSubTimeout);
        relays.filter((r, i, a)=>a.indexOf(r) === i).forEach(async (relay)=>{
            let r;
            try {
                r = await this.ensureRelay(relay);
            } catch (err) {
                handleEose();
                return;
            }
            if (!r) return;
            let s = r.sub(filters, modifiedOpts);
            s.on("event", (event)=>{
                _knownIds.add(event.id);
                for (let cb of eventListeners.values())cb(event);
            });
            s.on("eose", ()=>{
                if (eoseSent) return;
                handleEose();
            });
            subs.push(s);
            function handleEose() {
                eosesMissing--;
                if (eosesMissing === 0) {
                    clearTimeout(eoseTimeout);
                    for (let cb of eoseListeners.values())cb();
                }
            }
        });
        let greaterSub = {
            sub (filters2, opts2) {
                subs.forEach((sub)=>sub.sub(filters2, opts2));
                return greaterSub;
            },
            unsub () {
                subs.forEach((sub)=>sub.unsub());
            },
            on (type, cb) {
                if (type === "event") {
                    eventListeners.add(cb);
                } else if (type === "eose") {
                    eoseListeners.add(cb);
                }
            },
            off (type, cb) {
                if (type === "event") {
                    eventListeners.delete(cb);
                } else if (type === "eose") eoseListeners.delete(cb);
            },
            get events () {
                return eventsGenerator(greaterSub);
            }
        };
        return greaterSub;
    }
    get(relays, filter, opts) {
        return new Promise((resolve)=>{
            let sub = this.sub(relays, [
                filter
            ], opts);
            let timeout = setTimeout(()=>{
                sub.unsub();
                resolve(null);
            }, this.getTimeout);
            sub.on("event", (event)=>{
                resolve(event);
                clearTimeout(timeout);
                sub.unsub();
            });
        });
    }
    list(relays, filters, opts) {
        return new Promise((resolve)=>{
            let events = [];
            let sub = this.sub(relays, filters, opts);
            sub.on("event", (event)=>{
                events.push(event);
            });
            sub.on("eose", ()=>{
                sub.unsub();
                resolve(events);
            });
        });
    }
    batchedList(batchKey, relays, filters) {
        return new Promise((resolve)=>{
            if (!this.batchedByKey[batchKey]) {
                this.batchedByKey[batchKey] = [
                    {
                        filters,
                        relays,
                        resolve,
                        events: []
                    }
                ];
                setTimeout(()=>{
                    Object.keys(this.batchedByKey).forEach(async (batchKey2)=>{
                        const batchedRequests = this.batchedByKey[batchKey2];
                        const filters2 = [];
                        const relays2 = [];
                        batchedRequests.forEach((br)=>{
                            filters2.push(...br.filters);
                            relays2.push(...br.relays);
                        });
                        const sub = this.sub(relays2, [
                            mergeFilters(...filters2)
                        ]);
                        sub.on("event", (event)=>{
                            batchedRequests.forEach((br)=>matchFilters(br.filters, event) && br.events.push(event));
                        });
                        sub.on("eose", ()=>{
                            sub.unsub();
                            batchedRequests.forEach((br)=>br.resolve(br.events));
                        });
                        delete this.batchedByKey[batchKey2];
                    });
                }, this.batchInterval);
            } else {
                this.batchedByKey[batchKey].push({
                    filters,
                    relays,
                    resolve,
                    events: []
                });
            }
        });
    }
    publish(relays, event) {
        return relays.map(async (relay)=>{
            let r = await this.ensureRelay(relay);
            return r.publish(event);
        });
    }
    seenOn(id) {
        return Array.from(this._seenOn[id]?.values?.() || []);
    }
};
// nip19.ts
var nip19_exports = {};
__export(nip19_exports, {
    BECH32_REGEX: ()=>BECH32_REGEX,
    decode: ()=>decode,
    naddrEncode: ()=>naddrEncode,
    neventEncode: ()=>neventEncode,
    noteEncode: ()=>noteEncode,
    nprofileEncode: ()=>nprofileEncode,
    npubEncode: ()=>npubEncode,
    nrelayEncode: ()=>nrelayEncode,
    nsecEncode: ()=>nsecEncode
});
;
;
var Bech32MaxSize = 5e3;
var BECH32_REGEX = /[\x21-\x7E]{1,83}1[023456789acdefghjklmnpqrstuvwxyz]{6,}/;
function integerToUint8Array(number) {
    const uint8Array = new Uint8Array(4);
    uint8Array[0] = number >> 24 & 255;
    uint8Array[1] = number >> 16 & 255;
    uint8Array[2] = number >> 8 & 255;
    uint8Array[3] = number & 255;
    return uint8Array;
}
function decode(nip19) {
    let { prefix, words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].decode(nip19, Bech32MaxSize);
    let data = new Uint8Array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].fromWords(words));
    switch(prefix){
        case "nprofile":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for nprofile");
                if (tlv[0][0].length !== 32) throw new Error("TLV 0 should be 32 bytes");
                return {
                    type: "nprofile",
                    data: {
                        pubkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[0][0]),
                        relays: tlv[1] ? tlv[1].map((d)=>utf8Decoder.decode(d)) : []
                    }
                };
            }
        case "nevent":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for nevent");
                if (tlv[0][0].length !== 32) throw new Error("TLV 0 should be 32 bytes");
                if (tlv[2] && tlv[2][0].length !== 32) throw new Error("TLV 2 should be 32 bytes");
                if (tlv[3] && tlv[3][0].length !== 4) throw new Error("TLV 3 should be 4 bytes");
                return {
                    type: "nevent",
                    data: {
                        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[0][0]),
                        relays: tlv[1] ? tlv[1].map((d)=>utf8Decoder.decode(d)) : [],
                        author: tlv[2]?.[0] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[2][0]) : void 0,
                        kind: tlv[3]?.[0] ? parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[3][0]), 16) : void 0
                    }
                };
            }
        case "naddr":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for naddr");
                if (!tlv[2]?.[0]) throw new Error("missing TLV 2 for naddr");
                if (tlv[2][0].length !== 32) throw new Error("TLV 2 should be 32 bytes");
                if (!tlv[3]?.[0]) throw new Error("missing TLV 3 for naddr");
                if (tlv[3][0].length !== 4) throw new Error("TLV 3 should be 4 bytes");
                return {
                    type: "naddr",
                    data: {
                        identifier: utf8Decoder.decode(tlv[0][0]),
                        pubkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[2][0]),
                        kind: parseInt((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(tlv[3][0]), 16),
                        relays: tlv[1] ? tlv[1].map((d)=>utf8Decoder.decode(d)) : []
                    }
                };
            }
        case "nrelay":
            {
                let tlv = parseTLV(data);
                if (!tlv[0]?.[0]) throw new Error("missing TLV 0 for nrelay");
                return {
                    type: "nrelay",
                    data: utf8Decoder.decode(tlv[0][0])
                };
            }
        case "nsec":
        case "npub":
        case "note":
            return {
                type: prefix,
                data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(data)
            };
        default:
            throw new Error(`unknown prefix ${prefix}`);
    }
}
function parseTLV(data) {
    let result = {};
    let rest = data;
    while(rest.length > 0){
        let t = rest[0];
        let l = rest[1];
        if (!l) throw new Error(`malformed TLV ${t}`);
        let v = rest.slice(2, 2 + l);
        rest = rest.slice(2 + l);
        if (v.length < l) throw new Error(`not enough data to read on TLV ${t}`);
        result[t] = result[t] || [];
        result[t].push(v);
    }
    return result;
}
function nsecEncode(hex) {
    return encodeBytes("nsec", hex);
}
function npubEncode(hex) {
    return encodeBytes("npub", hex);
}
function noteEncode(hex) {
    return encodeBytes("note", hex);
}
function encodeBech32(prefix, data) {
    let words = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].toWords(data);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].encode(prefix, words, Bech32MaxSize);
}
function encodeBytes(prefix, hex) {
    let data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(hex);
    return encodeBech32(prefix, data);
}
function nprofileEncode(profile) {
    let data = encodeTLV({
        0: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(profile.pubkey)
        ],
        1: (profile.relays || []).map((url)=>utf8Encoder.encode(url))
    });
    return encodeBech32("nprofile", data);
}
function neventEncode(event) {
    let kindArray;
    if (event.kind != void 0) {
        kindArray = integerToUint8Array(event.kind);
    }
    let data = encodeTLV({
        0: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(event.id)
        ],
        1: (event.relays || []).map((url)=>utf8Encoder.encode(url)),
        2: event.author ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(event.author)
        ] : [],
        3: kindArray ? [
            new Uint8Array(kindArray)
        ] : []
    });
    return encodeBech32("nevent", data);
}
function naddrEncode(addr) {
    let kind = new ArrayBuffer(4);
    new DataView(kind).setUint32(0, addr.kind, false);
    let data = encodeTLV({
        0: [
            utf8Encoder.encode(addr.identifier)
        ],
        1: (addr.relays || []).map((url)=>utf8Encoder.encode(url)),
        2: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToBytes"])(addr.pubkey)
        ],
        3: [
            new Uint8Array(kind)
        ]
    });
    return encodeBech32("naddr", data);
}
function nrelayEncode(url) {
    let data = encodeTLV({
        0: [
            utf8Encoder.encode(url)
        ]
    });
    return encodeBech32("nrelay", data);
}
function encodeTLV(tlv) {
    let entries = [];
    Object.entries(tlv).forEach(([t, vs])=>{
        vs.forEach((v)=>{
            let entry = new Uint8Array(v.length + 2);
            entry.set([
                parseInt(t)
            ], 0);
            entry.set([
                v.length
            ], 1);
            entry.set(v, 2);
            entries.push(entry);
        });
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(...entries);
}
// references.ts
var mentionRegex = /\bnostr:((note|npub|naddr|nevent|nprofile)1\w+)\b|#\[(\d+)\]/g;
function parseReferences(evt) {
    let references = [];
    for (let ref of evt.content.matchAll(mentionRegex)){
        if (ref[2]) {
            try {
                let { type, data } = decode(ref[1]);
                switch(type){
                    case "npub":
                        {
                            references.push({
                                text: ref[0],
                                profile: {
                                    pubkey: data,
                                    relays: []
                                }
                            });
                            break;
                        }
                    case "nprofile":
                        {
                            references.push({
                                text: ref[0],
                                profile: data
                            });
                            break;
                        }
                    case "note":
                        {
                            references.push({
                                text: ref[0],
                                event: {
                                    id: data,
                                    relays: []
                                }
                            });
                            break;
                        }
                    case "nevent":
                        {
                            references.push({
                                text: ref[0],
                                event: data
                            });
                            break;
                        }
                    case "naddr":
                        {
                            references.push({
                                text: ref[0],
                                address: data
                            });
                            break;
                        }
                }
            } catch (err) {}
        } else if (ref[3]) {
            let idx = parseInt(ref[3], 10);
            let tag = evt.tags[idx];
            if (!tag) continue;
            switch(tag[0]){
                case "p":
                    {
                        references.push({
                            text: ref[0],
                            profile: {
                                pubkey: tag[1],
                                relays: tag[2] ? [
                                    tag[2]
                                ] : []
                            }
                        });
                        break;
                    }
                case "e":
                    {
                        references.push({
                            text: ref[0],
                            event: {
                                id: tag[1],
                                relays: tag[2] ? [
                                    tag[2]
                                ] : []
                            }
                        });
                        break;
                    }
                case "a":
                    {
                        try {
                            let [kind, pubkey, identifier] = tag[1].split(":");
                            references.push({
                                text: ref[0],
                                address: {
                                    identifier,
                                    pubkey,
                                    kind: parseInt(kind, 10),
                                    relays: tag[2] ? [
                                        tag[2]
                                    ] : []
                                }
                            });
                        } catch (err) {}
                        break;
                    }
            }
        }
    }
    return references;
}
// nip04.ts
var nip04_exports = {};
__export(nip04_exports, {
    decrypt: ()=>decrypt,
    encrypt: ()=>encrypt
});
;
;
;
if (typeof crypto !== "undefined" && !crypto.subtle && crypto.webcrypto) {
    crypto.subtle = crypto.webcrypto.subtle;
}
async function encrypt(privkey, pubkey, text) {
    const key = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secp256k1"].getSharedSecret(privkey, "02" + pubkey);
    const normalizedKey = getNormalizedX(key);
    let iv = Uint8Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["randomBytes"])(16));
    let plaintext = utf8Encoder.encode(text);
    let cryptoKey = await crypto.subtle.importKey("raw", normalizedKey, {
        name: "AES-CBC"
    }, false, [
        "encrypt"
    ]);
    let ciphertext = await crypto.subtle.encrypt({
        name: "AES-CBC",
        iv
    }, cryptoKey, plaintext);
    let ctb64 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode(new Uint8Array(ciphertext));
    let ivb64 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode(new Uint8Array(iv.buffer));
    return `${ctb64}?iv=${ivb64}`;
}
async function decrypt(privkey, pubkey, data) {
    let [ctb64, ivb64] = data.split("?iv=");
    let key = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secp256k1"].getSharedSecret(privkey, "02" + pubkey);
    let normalizedKey = getNormalizedX(key);
    let cryptoKey = await crypto.subtle.importKey("raw", normalizedKey, {
        name: "AES-CBC"
    }, false, [
        "decrypt"
    ]);
    let ciphertext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(ctb64);
    let iv = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(ivb64);
    let plaintext = await crypto.subtle.decrypt({
        name: "AES-CBC",
        iv
    }, cryptoKey, ciphertext);
    let text = utf8Decoder.decode(plaintext);
    return text;
}
function getNormalizedX(key) {
    return key.slice(1, 33);
}
// nip05.ts
var nip05_exports = {};
__export(nip05_exports, {
    NIP05_REGEX: ()=>NIP05_REGEX,
    queryProfile: ()=>queryProfile,
    searchDomain: ()=>searchDomain,
    useFetchImplementation: ()=>useFetchImplementation
});
var NIP05_REGEX = /^(?:([\w.+-]+)@)?([\w.-]+)$/;
var _fetch;
try {
    _fetch = fetch;
} catch  {}
function useFetchImplementation(fetchImplementation) {
    _fetch = fetchImplementation;
}
async function searchDomain(domain, query = "") {
    try {
        let res = await (await _fetch(`https://${domain}/.well-known/nostr.json?name=${query}`)).json();
        return res.names;
    } catch (_) {
        return {};
    }
}
async function queryProfile(fullname) {
    const match = fullname.match(NIP05_REGEX);
    if (!match) return null;
    const [_, name = "_", domain] = match;
    try {
        const res = await _fetch(`https://${domain}/.well-known/nostr.json?name=${name}`);
        const { names, relays } = parseNIP05Result(await res.json());
        const pubkey = names[name];
        return pubkey ? {
            pubkey,
            relays: relays?.[pubkey]
        } : null;
    } catch (_e) {
        return null;
    }
}
function parseNIP05Result(json) {
    const result = {
        names: {}
    };
    for (const [name, pubkey] of Object.entries(json.names)){
        if (typeof name === "string" && typeof pubkey === "string") {
            result.names[name] = pubkey;
        }
    }
    if (json.relays) {
        result.relays = {};
        for (const [pubkey, relays] of Object.entries(json.relays)){
            if (typeof pubkey === "string" && Array.isArray(relays)) {
                result.relays[pubkey] = relays.filter((relay)=>typeof relay === "string");
            }
        }
    }
    return result;
}
// nip06.ts
var nip06_exports = {};
__export(nip06_exports, {
    generateSeedWords: ()=>generateSeedWords,
    privateKeyFromSeedWords: ()=>privateKeyFromSeedWords,
    validateWords: ()=>validateWords
});
;
;
;
;
function privateKeyFromSeedWords(mnemonic, passphrase) {
    let root = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip32$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HDKey"].fromMasterSeed((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mnemonicToSeedSync"])(mnemonic, passphrase));
    let privateKey = root.derive(`m/44'/1237'/0'/0/0`).privateKey;
    if (!privateKey) throw new Error("could not derive private key");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(privateKey);
}
function generateSeedWords() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateMnemonic"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$wordlists$2f$english$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wordlist"]);
}
function validateWords(words) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateMnemonic"])(words, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$bip39$2f$esm$2f$wordlists$2f$english$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wordlist"]);
}
// nip10.ts
var nip10_exports = {};
__export(nip10_exports, {
    parse: ()=>parse
});
function parse(event) {
    const result = {
        reply: void 0,
        root: void 0,
        mentions: [],
        profiles: []
    };
    const eTags = [];
    for (const tag of event.tags){
        if (tag[0] === "e" && tag[1]) {
            eTags.push(tag);
        }
        if (tag[0] === "p" && tag[1]) {
            result.profiles.push({
                pubkey: tag[1],
                relays: tag[2] ? [
                    tag[2]
                ] : []
            });
        }
    }
    for(let eTagIndex = 0; eTagIndex < eTags.length; eTagIndex++){
        const eTag = eTags[eTagIndex];
        const [_, eTagEventId, eTagRelayUrl, eTagMarker] = eTag;
        const eventPointer = {
            id: eTagEventId,
            relays: eTagRelayUrl ? [
                eTagRelayUrl
            ] : []
        };
        const isFirstETag = eTagIndex === 0;
        const isLastETag = eTagIndex === eTags.length - 1;
        if (eTagMarker === "root") {
            result.root = eventPointer;
            continue;
        }
        if (eTagMarker === "reply") {
            result.reply = eventPointer;
            continue;
        }
        if (eTagMarker === "mention") {
            result.mentions.push(eventPointer);
            continue;
        }
        if (isFirstETag) {
            result.root = eventPointer;
            continue;
        }
        if (isLastETag) {
            result.reply = eventPointer;
            continue;
        }
        result.mentions.push(eventPointer);
    }
    return result;
}
// nip13.ts
var nip13_exports = {};
__export(nip13_exports, {
    getPow: ()=>getPow,
    minePow: ()=>minePow
});
function getPow(hex) {
    let count = 0;
    for(let i = 0; i < hex.length; i++){
        const nibble = parseInt(hex[i], 16);
        if (nibble === 0) {
            count += 4;
        } else {
            count += Math.clz32(nibble) - 28;
            break;
        }
    }
    return count;
}
function minePow(unsigned, difficulty) {
    let count = 0;
    const event = unsigned;
    const tag = [
        "nonce",
        count.toString(),
        difficulty.toString()
    ];
    event.tags.push(tag);
    while(true){
        const now = Math.floor(new Date().getTime() / 1e3);
        if (now !== event.created_at) {
            count = 0;
            event.created_at = now;
        }
        tag[1] = (++count).toString();
        event.id = getEventHash(event);
        if (getPow(event.id) >= difficulty) {
            break;
        }
    }
    return event;
}
// nip18.ts
var nip18_exports = {};
__export(nip18_exports, {
    finishRepostEvent: ()=>finishRepostEvent,
    getRepostedEvent: ()=>getRepostedEvent,
    getRepostedEventPointer: ()=>getRepostedEventPointer
});
function finishRepostEvent(t, reposted, relayUrl, privateKey) {
    return finishEvent({
        kind: 6 /* Repost */ ,
        tags: [
            ...t.tags ?? [],
            [
                "e",
                reposted.id,
                relayUrl
            ],
            [
                "p",
                reposted.pubkey
            ]
        ],
        content: t.content === "" ? "" : JSON.stringify(reposted),
        created_at: t.created_at
    }, privateKey);
}
function getRepostedEventPointer(event) {
    if (event.kind !== 6 /* Repost */ ) {
        return void 0;
    }
    let lastETag;
    let lastPTag;
    for(let i = event.tags.length - 1; i >= 0 && (lastETag === void 0 || lastPTag === void 0); i--){
        const tag = event.tags[i];
        if (tag.length >= 2) {
            if (tag[0] === "e" && lastETag === void 0) {
                lastETag = tag;
            } else if (tag[0] === "p" && lastPTag === void 0) {
                lastPTag = tag;
            }
        }
    }
    if (lastETag === void 0) {
        return void 0;
    }
    return {
        id: lastETag[1],
        relays: [
            lastETag[2],
            lastPTag?.[2]
        ].filter((x)=>typeof x === "string"),
        author: lastPTag?.[1]
    };
}
function getRepostedEvent(event, { skipVerification } = {}) {
    const pointer = getRepostedEventPointer(event);
    if (pointer === void 0 || event.content === "") {
        return void 0;
    }
    let repostedEvent;
    try {
        repostedEvent = JSON.parse(event.content);
    } catch (error) {
        return void 0;
    }
    if (repostedEvent.id !== pointer.id) {
        return void 0;
    }
    if (!skipVerification && !verifySignature(repostedEvent)) {
        return void 0;
    }
    return repostedEvent;
}
// nip21.ts
var nip21_exports = {};
__export(nip21_exports, {
    NOSTR_URI_REGEX: ()=>NOSTR_URI_REGEX,
    parse: ()=>parse2,
    test: ()=>test
});
var NOSTR_URI_REGEX = new RegExp(`nostr:(${BECH32_REGEX.source})`);
function test(value) {
    return typeof value === "string" && new RegExp(`^${NOSTR_URI_REGEX.source}$`).test(value);
}
function parse2(uri) {
    const match = uri.match(new RegExp(`^${NOSTR_URI_REGEX.source}$`));
    if (!match) throw new Error(`Invalid Nostr URI: ${uri}`);
    return {
        uri: match[0],
        value: match[1],
        decoded: decode(match[1])
    };
}
// nip25.ts
var nip25_exports = {};
__export(nip25_exports, {
    finishReactionEvent: ()=>finishReactionEvent,
    getReactedEventPointer: ()=>getReactedEventPointer
});
function finishReactionEvent(t, reacted, privateKey) {
    const inheritedTags = reacted.tags.filter((tag)=>tag.length >= 2 && (tag[0] === "e" || tag[0] === "p"));
    return finishEvent({
        ...t,
        kind: 7 /* Reaction */ ,
        tags: [
            ...t.tags ?? [],
            ...inheritedTags,
            [
                "e",
                reacted.id
            ],
            [
                "p",
                reacted.pubkey
            ]
        ],
        content: t.content ?? "+"
    }, privateKey);
}
function getReactedEventPointer(event) {
    if (event.kind !== 7 /* Reaction */ ) {
        return void 0;
    }
    let lastETag;
    let lastPTag;
    for(let i = event.tags.length - 1; i >= 0 && (lastETag === void 0 || lastPTag === void 0); i--){
        const tag = event.tags[i];
        if (tag.length >= 2) {
            if (tag[0] === "e" && lastETag === void 0) {
                lastETag = tag;
            } else if (tag[0] === "p" && lastPTag === void 0) {
                lastPTag = tag;
            }
        }
    }
    if (lastETag === void 0 || lastPTag === void 0) {
        return void 0;
    }
    return {
        id: lastETag[1],
        relays: [
            lastETag[2],
            lastPTag[2]
        ].filter((x)=>x !== void 0),
        author: lastPTag[1]
    };
}
// nip26.ts
var nip26_exports = {};
__export(nip26_exports, {
    createDelegation: ()=>createDelegation,
    getDelegator: ()=>getDelegator
});
;
;
;
function createDelegation(privateKey, parameters) {
    let conditions = [];
    if ((parameters.kind || -1) >= 0) conditions.push(`kind=${parameters.kind}`);
    if (parameters.until) conditions.push(`created_at<${parameters.until}`);
    if (parameters.since) conditions.push(`created_at>${parameters.since}`);
    let cond = conditions.join("&");
    if (cond === "") throw new Error("refusing to create a delegation without any conditions");
    let sighash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(utf8Encoder.encode(`nostr:delegation:${parameters.pubkey}:${cond}`));
    let sig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesToHex"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].sign(sighash, privateKey));
    return {
        from: getPublicKey(privateKey),
        to: parameters.pubkey,
        cond,
        sig
    };
}
function getDelegator(event) {
    let tag = event.tags.find((tag2)=>tag2[0] === "delegation" && tag2.length >= 4);
    if (!tag) return null;
    let pubkey = tag[1];
    let cond = tag[2];
    let sig = tag[3];
    let conditions = cond.split("&");
    for(let i = 0; i < conditions.length; i++){
        let [key, operator, value] = conditions[i].split(/\b/);
        if (key === "kind" && operator === "=" && event.kind === parseInt(value)) continue;
        else if (key === "created_at" && operator === "<" && event.created_at < parseInt(value)) continue;
        else if (key === "created_at" && operator === ">" && event.created_at > parseInt(value)) continue;
        else return null;
    }
    let sighash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(utf8Encoder.encode(`nostr:delegation:${event.pubkey}:${cond}`));
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["schnorr"].verify(sig, sighash, pubkey)) return null;
    return pubkey;
}
// nip27.ts
var nip27_exports = {};
__export(nip27_exports, {
    matchAll: ()=>matchAll,
    regex: ()=>regex,
    replaceAll: ()=>replaceAll
});
var regex = ()=>new RegExp(`\\b${NOSTR_URI_REGEX.source}\\b`, "g");
function* matchAll(content) {
    const matches = content.matchAll(regex());
    for (const match of matches){
        try {
            const [uri, value] = match;
            yield {
                uri,
                value,
                decoded: decode(value),
                start: match.index,
                end: match.index + uri.length
            };
        } catch (_e) {}
    }
}
function replaceAll(content, replacer) {
    return content.replaceAll(regex(), (uri, value)=>{
        return replacer({
            uri,
            value,
            decoded: decode(value)
        });
    });
}
// nip28.ts
var nip28_exports = {};
__export(nip28_exports, {
    channelCreateEvent: ()=>channelCreateEvent,
    channelHideMessageEvent: ()=>channelHideMessageEvent,
    channelMessageEvent: ()=>channelMessageEvent,
    channelMetadataEvent: ()=>channelMetadataEvent,
    channelMuteUserEvent: ()=>channelMuteUserEvent
});
var channelCreateEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finishEvent({
        kind: 40 /* ChannelCreation */ ,
        tags: [
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
var channelMetadataEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finishEvent({
        kind: 41 /* ChannelMetadata */ ,
        tags: [
            [
                "e",
                t.channel_create_event_id
            ],
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
var channelMessageEvent = (t, privateKey)=>{
    const tags = [
        [
            "e",
            t.channel_create_event_id,
            t.relay_url,
            "root"
        ]
    ];
    if (t.reply_to_channel_message_event_id) {
        tags.push([
            "e",
            t.reply_to_channel_message_event_id,
            t.relay_url,
            "reply"
        ]);
    }
    return finishEvent({
        kind: 42 /* ChannelMessage */ ,
        tags: [
            ...tags,
            ...t.tags ?? []
        ],
        content: t.content,
        created_at: t.created_at
    }, privateKey);
};
var channelHideMessageEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finishEvent({
        kind: 43 /* ChannelHideMessage */ ,
        tags: [
            [
                "e",
                t.channel_message_event_id
            ],
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
var channelMuteUserEvent = (t, privateKey)=>{
    let content;
    if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
    } else if (typeof t.content === "string") {
        content = t.content;
    } else {
        return void 0;
    }
    return finishEvent({
        kind: 44 /* ChannelMuteUser */ ,
        tags: [
            [
                "p",
                t.pubkey_to_mute
            ],
            ...t.tags ?? []
        ],
        content,
        created_at: t.created_at
    }, privateKey);
};
// nip39.ts
var nip39_exports = {};
__export(nip39_exports, {
    useFetchImplementation: ()=>useFetchImplementation2,
    validateGithub: ()=>validateGithub
});
var _fetch2;
try {
    _fetch2 = fetch;
} catch  {}
function useFetchImplementation2(fetchImplementation) {
    _fetch2 = fetchImplementation;
}
async function validateGithub(pubkey, username, proof) {
    try {
        let res = await (await _fetch2(`https://gist.github.com/${username}/${proof}/raw`)).text();
        return res === `Verifying that I control the following Nostr public key: ${pubkey}`;
    } catch (_) {
        return false;
    }
}
// nip42.ts
var nip42_exports = {};
__export(nip42_exports, {
    authenticate: ()=>authenticate
});
var authenticate = async ({ challenge, relay, sign })=>{
    const e = {
        kind: 22242 /* ClientAuth */ ,
        created_at: Math.floor(Date.now() / 1e3),
        tags: [
            [
                "relay",
                relay.url
            ],
            [
                "challenge",
                challenge
            ]
        ],
        content: ""
    };
    return relay.auth(await sign(e));
};
// nip44.ts
var nip44_exports = {};
__export(nip44_exports, {
    decrypt: ()=>decrypt2,
    encrypt: ()=>encrypt2,
    utils: ()=>utils
});
;
;
;
;
;
;
;
;
var utils = {
    v2: {
        maxPlaintextSize: 65536 - 128,
        minCiphertextSize: 100,
        maxCiphertextSize: 102400,
        getConversationKey (privkeyA, pubkeyB) {
            const key = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$curves$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secp256k1"].getSharedSecret(privkeyA, "02" + pubkeyB);
            return key.subarray(1, 33);
        },
        getMessageKeys (conversationKey, salt) {
            const keys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hkdf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hkdf"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"], conversationKey, salt, "nip44-v2", 76);
            return {
                encryption: keys.subarray(0, 32),
                nonce: keys.subarray(32, 44),
                auth: keys.subarray(44, 76)
            };
        },
        calcPadding (len) {
            if (!Number.isSafeInteger(len) || len < 0) throw new Error("expected positive integer");
            if (len <= 32) return 32;
            const nextpower = 1 << Math.floor(Math.log2(len - 1)) + 1;
            const chunk = nextpower <= 256 ? 32 : nextpower / 8;
            return chunk * (Math.floor((len - 1) / chunk) + 1);
        },
        pad (unpadded) {
            const unpaddedB = utf8Encoder.encode(unpadded);
            const len = unpaddedB.length;
            if (len < 1 || len >= utils.v2.maxPlaintextSize) throw new Error("invalid plaintext length: must be between 1b and 64KB");
            const paddedLen = utils.v2.calcPadding(len);
            const zeros = new Uint8Array(paddedLen - len);
            const lenBuf = new Uint8Array(2);
            new DataView(lenBuf.buffer).setUint16(0, len);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(lenBuf, unpaddedB, zeros);
        },
        unpad (padded) {
            const unpaddedLen = new DataView(padded.buffer).getUint16(0);
            const unpadded = padded.subarray(2, 2 + unpaddedLen);
            if (unpaddedLen === 0 || unpadded.length !== unpaddedLen || padded.length !== 2 + utils.v2.calcPadding(unpaddedLen)) throw new Error("invalid padding");
            return utf8Decoder.decode(unpadded);
        }
    }
};
function encrypt2(key, plaintext, options = {}) {
    const version = options.version ?? 2;
    if (version !== 2) throw new Error("unknown encryption version " + version);
    const salt = options.salt ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["randomBytes"])(32);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(salt, 32);
    const keys = utils.v2.getMessageKeys(key, salt);
    const padded = utils.v2.pad(plaintext);
    const ciphertext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$chacha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chacha20"])(keys.encryption, keys.nonce, padded);
    const mac = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hmac"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"], keys.auth, ciphertext);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatBytes"])(new Uint8Array([
        version
    ]), salt, ciphertext, mac));
}
function decrypt2(key, ciphertext) {
    const u = utils.v2;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBytes"])(key, 32);
    const clen = ciphertext.length;
    if (clen < u.minCiphertextSize || clen >= u.maxCiphertextSize) throw new Error("invalid ciphertext length: " + clen);
    if (ciphertext[0] === "#") throw new Error("unknown encryption version");
    let data;
    try {
        data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(ciphertext);
    } catch (error) {
        throw new Error("invalid base64: " + error.message);
    }
    const vers = data.subarray(0, 1)[0];
    if (vers !== 2) throw new Error("unknown encryption version " + vers);
    const salt = data.subarray(1, 33);
    const ciphertext_ = data.subarray(33, -32);
    const mac = data.subarray(-32);
    const keys = u.getMessageKeys(key, salt);
    const calculatedMac = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hmac"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"], keys.auth, ciphertext_);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equalBytes"])(calculatedMac, mac)) throw new Error("invalid MAC");
    const padded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$ciphers$2f$esm$2f$chacha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chacha20"])(keys.encryption, keys.nonce, ciphertext_);
    return u.unpad(padded);
}
// nip47.ts
var nip47_exports = {};
__export(nip47_exports, {
    makeNwcRequestEvent: ()=>makeNwcRequestEvent,
    parseConnectionString: ()=>parseConnectionString
});
function parseConnectionString(connectionString) {
    const { pathname, searchParams } = new URL(connectionString);
    const pubkey = pathname;
    const relay = searchParams.get("relay");
    const secret = searchParams.get("secret");
    if (!pubkey || !relay || !secret) {
        throw new Error("invalid connection string");
    }
    return {
        pubkey,
        relay,
        secret
    };
}
async function makeNwcRequestEvent({ pubkey, secret, invoice }) {
    const content = {
        method: "pay_invoice",
        params: {
            invoice
        }
    };
    const encryptedContent = await encrypt(secret, pubkey, JSON.stringify(content));
    const eventTemplate = {
        kind: 23194 /* NwcRequest */ ,
        created_at: Math.round(Date.now() / 1e3),
        content: encryptedContent,
        tags: [
            [
                "p",
                pubkey
            ]
        ]
    };
    return finishEvent(eventTemplate, secret);
}
// nip57.ts
var nip57_exports = {};
__export(nip57_exports, {
    getZapEndpoint: ()=>getZapEndpoint,
    makeZapReceipt: ()=>makeZapReceipt,
    makeZapRequest: ()=>makeZapRequest,
    useFetchImplementation: ()=>useFetchImplementation3,
    validateZapRequest: ()=>validateZapRequest
});
;
var _fetch3;
try {
    _fetch3 = fetch;
} catch  {}
function useFetchImplementation3(fetchImplementation) {
    _fetch3 = fetchImplementation;
}
async function getZapEndpoint(metadata) {
    try {
        let lnurl = "";
        let { lud06, lud16 } = JSON.parse(metadata.content);
        if (lud06) {
            let { words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].decode(lud06, 1e3);
            let data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bech32"].fromWords(words);
            lnurl = utf8Decoder.decode(data);
        } else if (lud16) {
            let [name, domain] = lud16.split("@");
            lnurl = `https://${domain}/.well-known/lnurlp/${name}`;
        } else {
            return null;
        }
        let res = await _fetch3(lnurl);
        let body = await res.json();
        if (body.allowsNostr && body.nostrPubkey) {
            return body.callback;
        }
    } catch (err) {}
    return null;
}
function makeZapRequest({ profile, event, amount, relays, comment = "" }) {
    if (!amount) throw new Error("amount not given");
    if (!profile) throw new Error("profile not given");
    let zr = {
        kind: 9734,
        created_at: Math.round(Date.now() / 1e3),
        content: comment,
        tags: [
            [
                "p",
                profile
            ],
            [
                "amount",
                amount.toString()
            ],
            [
                "relays",
                ...relays
            ]
        ]
    };
    if (event) {
        zr.tags.push([
            "e",
            event
        ]);
    }
    return zr;
}
function validateZapRequest(zapRequestString) {
    let zapRequest;
    try {
        zapRequest = JSON.parse(zapRequestString);
    } catch (err) {
        return "Invalid zap request JSON.";
    }
    if (!validateEvent(zapRequest)) return "Zap request is not a valid Nostr event.";
    if (!verifySignature(zapRequest)) return "Invalid signature on zap request.";
    let p = zapRequest.tags.find(([t, v])=>t === "p" && v);
    if (!p) return "Zap request doesn't have a 'p' tag.";
    if (!p[1].match(/^[a-f0-9]{64}$/)) return "Zap request 'p' tag is not valid hex.";
    let e = zapRequest.tags.find(([t, v])=>t === "e" && v);
    if (e && !e[1].match(/^[a-f0-9]{64}$/)) return "Zap request 'e' tag is not valid hex.";
    let relays = zapRequest.tags.find(([t, v])=>t === "relays" && v);
    if (!relays) return "Zap request doesn't have a 'relays' tag.";
    return null;
}
function makeZapReceipt({ zapRequest, preimage, bolt11, paidAt }) {
    let zr = JSON.parse(zapRequest);
    let tagsFromZapRequest = zr.tags.filter(([t])=>t === "e" || t === "p" || t === "a");
    let zap = {
        kind: 9735,
        created_at: Math.round(paidAt.getTime() / 1e3),
        content: "",
        tags: [
            ...tagsFromZapRequest,
            [
                "bolt11",
                bolt11
            ],
            [
                "description",
                zapRequest
            ]
        ]
    };
    if (preimage) {
        zap.tags.push([
            "preimage",
            preimage
        ]);
    }
    return zap;
}
// nip98.ts
var nip98_exports = {};
__export(nip98_exports, {
    getToken: ()=>getToken,
    unpackEventFromToken: ()=>unpackEventFromToken,
    validateEvent: ()=>validateEvent2,
    validateToken: ()=>validateToken
});
;
var _authorizationScheme = "Nostr ";
async function getToken(loginUrl, httpMethod, sign, includeAuthorizationScheme = false) {
    if (!loginUrl || !httpMethod) throw new Error("Missing loginUrl or httpMethod");
    const event = getBlankEvent(27235 /* HttpAuth */ );
    event.tags = [
        [
            "u",
            loginUrl
        ],
        [
            "method",
            httpMethod
        ]
    ];
    event.created_at = Math.round(new Date().getTime() / 1e3);
    const signedEvent = await sign(event);
    const authorizationScheme = includeAuthorizationScheme ? _authorizationScheme : "";
    return authorizationScheme + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].encode(utf8Encoder.encode(JSON.stringify(signedEvent)));
}
async function validateToken(token, url, method) {
    const event = await unpackEventFromToken(token).catch((error)=>{
        throw error;
    });
    const valid = await validateEvent2(event, url, method).catch((error)=>{
        throw error;
    });
    return valid;
}
async function unpackEventFromToken(token) {
    if (!token) {
        throw new Error("Missing token");
    }
    token = token.replace(_authorizationScheme, "");
    const eventB64 = utf8Decoder.decode(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nostr$2d$tools$2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"].decode(token));
    if (!eventB64 || eventB64.length === 0 || !eventB64.startsWith("{")) {
        throw new Error("Invalid token");
    }
    const event = JSON.parse(eventB64);
    return event;
}
async function validateEvent2(event, url, method) {
    if (!event) {
        throw new Error("Invalid nostr event");
    }
    if (!verifySignature(event)) {
        throw new Error("Invalid nostr event, signature invalid");
    }
    if (event.kind !== 27235 /* HttpAuth */ ) {
        throw new Error("Invalid nostr event, kind invalid");
    }
    if (!event.created_at) {
        throw new Error("Invalid nostr event, created_at invalid");
    }
    if (Math.round(new Date().getTime() / 1e3) - event.created_at > 60) {
        throw new Error("Invalid nostr event, expired");
    }
    const urlTag = event.tags.find((t)=>t[0] === "u");
    if (urlTag?.length !== 1 && urlTag?.[1] !== url) {
        throw new Error("Invalid nostr event, url tag invalid");
    }
    const methodTag = event.tags.find((t)=>t[0] === "method");
    if (methodTag?.length !== 1 && methodTag?.[1].toLowerCase() !== method.toLowerCase()) {
        throw new Error("Invalid nostr event, method tag invalid");
    }
    return true;
}
;

})()),
}]);

//# sourceMappingURL=node_modules_f6da31._.js.map
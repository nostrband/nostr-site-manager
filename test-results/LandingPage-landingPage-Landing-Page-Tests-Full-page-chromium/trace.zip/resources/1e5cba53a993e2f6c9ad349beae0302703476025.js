(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_Pages_Landing_index_tsx_2e76f0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_Pages_Landing_index_tsx_2e76f0._.js",
  "chunks": [
    "static/chunks/_9150b5._.js",
    "static/chunks/node_modules_fa81bb._.js"
  ],
  "source": "dynamic"
});

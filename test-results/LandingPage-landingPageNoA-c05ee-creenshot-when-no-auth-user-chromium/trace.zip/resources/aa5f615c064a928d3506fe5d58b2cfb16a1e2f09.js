(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_d7e47f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_d7e47f._.js",
  "chunks": [
    "static/chunks/_11ccc0._.js",
    "static/chunks/src_components_Pages_Landing_index_tsx_20f368._.js"
  ],
  "source": "dynamic"
});

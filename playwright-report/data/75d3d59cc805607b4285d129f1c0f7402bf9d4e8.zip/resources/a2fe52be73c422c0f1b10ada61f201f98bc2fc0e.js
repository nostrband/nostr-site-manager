(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_e06604._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_e06604._.js",
  "chunks": [
    "static/chunks/_a69081._.js",
    "static/chunks/node_modules_next_51ff6e._.js",
    "static/chunks/node_modules_@mui_system_esm_0d2ace._.js",
    "static/chunks/node_modules_@mui_material_fbab62._.js",
    "static/chunks/node_modules_cba898._.js",
    "static/chunks/node_modules_aa843b._.js",
    "static/chunks/node_modules_f2d8f5._.js",
    "static/chunks/node_modules_228eaf._.js",
    "static/chunks/node_modules_f6da31._.js",
    "static/chunks/node_modules_@nostr-dev-kit_ndk_dist_index_mjs_ee4b16._.js",
    "static/chunks/node_modules_lodash-es_86528e._.js",
    "static/chunks/node_modules_dexie_0b45c6._.js",
    "static/chunks/node_modules_libnostrsite_dist_index_8edd20.js",
    "static/chunks/node_modules_830e98._.js",
    "static/chunks/src_mui_570fda._.css"
  ],
  "source": "dynamic"
});
